using System;
using System.IO;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media.Imaging;

namespace IntuneWinDownloader.WinUI.Converters;

public sealed class StringToImageSourceConverter : IValueConverter
{
    public object? Convert(object value, Type targetType, object parameter, string language)
    {
        var text = value as string;
        if (string.IsNullOrWhiteSpace(text)) return null;

        try
        {
            if (Uri.TryCreate(text, UriKind.Absolute, out var uri))
            {
                return new BitmapImage(uri);
            }

            if (File.Exists(text))
            {
                return new BitmapImage(new Uri(text));
            }
        }
        catch
        {
            return null;
        }

        return null;
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        throw new NotSupportedException();
    }
}
