namespace IntuneWinDownloader.WinUI.Models;

public sealed class InstallMetadata
{
    public string AppName { get; set; } = string.Empty;
    public string WorkingDirectory { get; set; } = string.Empty;
    public string ExtractedFolder { get; set; } = string.Empty;
    public string MetadataFolder { get; set; } = string.Empty;
    public string SetupFile { get; set; } = string.Empty;
    public string Command { get; set; } = string.Empty;
    public string InstallCommand { get; set; } = string.Empty;
    public string UninstallCommand { get; set; } = string.Empty;
    public string PackageCommand { get; set; } = string.Empty;
    public string PackageInstallCommand { get; set; } = string.Empty;
    public string PackageUninstallCommand { get; set; } = string.Empty;
    public string PolicyInstallCommand { get; set; } = string.Empty;
    public string PolicyUninstallCommand { get; set; } = string.Empty;
    public string PolicyCommandSource { get; set; } = string.Empty;
    public string InstallBehavior { get; set; } = string.Empty;
    public string Source { get; set; } = string.Empty;
    public string CommandSource { get; set; } = string.Empty;
    public string LogPath { get; set; } = string.Empty;
    public string InstallScriptId { get; set; } = string.Empty;
    public string UninstallScriptId { get; set; } = string.Empty;
    public string InstallScriptCommand { get; set; } = string.Empty;
    public string UninstallScriptCommand { get; set; } = string.Empty;
    public bool HasPowerShellScriptInstaller { get; set; }
    public string PolicyNote { get; set; } = string.Empty;
}
