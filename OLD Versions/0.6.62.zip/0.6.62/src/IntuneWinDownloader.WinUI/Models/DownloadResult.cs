namespace IntuneWinDownloader.WinUI.Models;

public sealed class DownloadResult
{
    public string AppId { get; set; } = string.Empty;
    public string ApplicationId { get; set; } = string.Empty;
    public string ApplicationVersion { get; set; } = "1";
    public string CommittedContentVersion { get; set; } = "1";
    public string AppName { get; set; } = string.Empty;
    public string WorkFolder { get; set; } = string.Empty;
    public string BinFile { get; set; } = string.Empty;
    public string DecodedZip { get; set; } = string.Empty;
    public string ExtractedFolder { get; set; } = string.Empty;
    public string MetadataFolder { get; set; } = string.Empty;
    public string ProfileIdentifier { get; set; } = string.Empty;
}
