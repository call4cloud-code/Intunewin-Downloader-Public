using System.ComponentModel;
using System.Runtime.CompilerServices;
using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace IntuneWinDownloader.WinUI.Models;

public sealed class AppRow : INotifyPropertyChanged
{
    private bool _isChecked;
    private bool _isDownloaded;
    private string _version = string.Empty;
    private string _contentVersionStatus = "Unknown";
    private bool _contentVersionResolved;

    public event PropertyChangedEventHandler? PropertyChanged;

    public bool IsChecked
    {
        get => _isChecked;
        set
        {
            if (_isChecked == value) return;
            _isChecked = value;
            OnPropertyChanged();
            RefreshSelectionVisuals();
        }
    }

    public bool IsDownloaded
    {
        get => _isDownloaded;
        set
        {
            if (_isDownloaded == value) return;
            _isDownloaded = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(TestInstallState));
            OnPropertyChanged(nameof(TestInstallStateVisibility));
            OnPropertyChanged(nameof(TestInstallStateBrush));
            OnPropertyChanged(nameof(TestInstallGlyph));
        }
    }

    public string Name { get; set; } = string.Empty;
    public string Id { get; set; } = string.Empty;

    public string Version
    {
        get => _version;
        set
        {
            var clean = string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
            if (_version == clean) return;
            _version = clean;
            OnPropertyChanged();
            OnPropertyChanged(nameof(ContentVersionDisplay));
        }
    }

    public string Source { get; set; } = string.Empty;
    public string Details { get; set; } = string.Empty;
    public string DisplayVersion { get; set; } = string.Empty;
    public string PackageSize { get; set; } = string.Empty;
    public long PackageSizeBytes { get; set; }
    public string Publisher { get; set; } = string.Empty;
    public string DatePublished { get; set; } = string.Empty;
    public string Status { get; set; } = "Available";
    public string IconPath { get; set; } = string.Empty;

    public bool ContentVersionResolved
    {
        get => _contentVersionResolved;
        set
        {
            if (_contentVersionResolved == value) return;
            _contentVersionResolved = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(ContentVersionDisplay));
        }
    }

    public string ContentVersionStatus
    {
        get => _contentVersionStatus;
        set
        {
            var clean = string.IsNullOrWhiteSpace(value) ? "Unknown" : value.Trim();
            if (_contentVersionStatus == clean) return;
            _contentVersionStatus = clean;
            OnPropertyChanged();
        }
    }

    public string DisplayVersionOrFallback => string.IsNullOrWhiteSpace(DisplayVersion) ? "No App Version" : DisplayVersion;
    public string PackageSizeOrUnknown => string.IsNullOrWhiteSpace(PackageSize) ? "Unknown" : PackageSize;
    public string PublisherOrUnknown => string.IsNullOrWhiteSpace(Publisher) ? "Unknown" : Publisher;
    public string ContentVersionDisplay => ContentVersionResolved ? Version : "Auto";

    public Brush RowBackground => IsChecked ? ResourceBrush("AppSelectedRowBackgroundBrush", Color.FromArgb(255, 232, 244, 255)) : new SolidColorBrush(Colors.Transparent);
    public Brush RowBorderBrush => IsChecked ? ResourceBrush("AppSelectedRowBorderBrush", Color.FromArgb(255, 169, 211, 248)) : new SolidColorBrush(Colors.Transparent);
    public Visibility SelectedMarkerVisibility => IsChecked ? Visibility.Visible : Visibility.Collapsed;
    public Windows.UI.Text.FontWeight RowFontWeight => new() { Weight = IsChecked ? (ushort)600 : (ushort)400 };
    public string SelectionGlyph => IsChecked ? "✓" : string.Empty;
    public Brush SelectionBoxBackground => IsChecked ? ResourceBrush("AppSelectionBoxCheckedBackgroundBrush", Color.FromArgb(255, 0, 120, 212)) : ResourceBrush("AppSelectionBoxBackgroundBrush", Colors.White);
    public Brush SelectionBoxBorderBrush => IsChecked ? ResourceBrush("AppSelectionBoxCheckedBackgroundBrush", Color.FromArgb(255, 0, 120, 212)) : ResourceBrush("AppSelectionBoxBorderBrush", Color.FromArgb(255, 122, 138, 153));
    public Brush SelectionGlyphForeground => IsChecked ? ResourceBrush("AppSelectionGlyphCheckedBrush", Colors.White) : ResourceBrush("AppSelectionGlyphBrush", Color.FromArgb(255, 0, 120, 212));
    public string TestInstallState => IsDownloaded ? "Ready" : "Download first";
    public Visibility TestInstallStateVisibility => Visibility.Visible;
    public Brush TestInstallStateBrush => IsDownloaded ? ResourceBrush("AppSuccessBrush", Color.FromArgb(255, 16, 124, 16)) : ResourceBrush("AppMutedBrush", Color.FromArgb(255, 96, 104, 112));
    public string TestInstallGlyph => IsDownloaded ? "✓" : string.Empty;

    public string Initials
    {
        get
        {
            var source = string.IsNullOrWhiteSpace(Name) ? "App" : Name.Trim();
            var parts = source.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (parts.Length >= 2)
            {
                return string.Concat(parts[0][0], parts[1][0]).ToUpperInvariant();
            }
            return source.Length >= 2 ? source[..2].ToUpperInvariant() : source[..1].ToUpperInvariant();
        }
    }

    public void MarkContentVersionResolved(string version, string status)
    {
        Version = string.IsNullOrWhiteSpace(version) ? string.Empty : version.Trim();
        ContentVersionStatus = status;
        ContentVersionResolved = true;
    }

    public void MarkContentVersionUnresolved(string status)
    {
        ContentVersionStatus = status;
        ContentVersionResolved = false;
        OnPropertyChanged(nameof(ContentVersionDisplay));
    }

    public void RefreshThemeBrushes()
    {
        RefreshSelectionVisuals();
        OnPropertyChanged(nameof(TestInstallStateBrush));
    }

    private void RefreshSelectionVisuals()
    {
        OnPropertyChanged(nameof(RowBackground));
        OnPropertyChanged(nameof(RowBorderBrush));
        OnPropertyChanged(nameof(SelectedMarkerVisibility));
        OnPropertyChanged(nameof(RowFontWeight));
        OnPropertyChanged(nameof(SelectionGlyph));
        OnPropertyChanged(nameof(SelectionBoxBackground));
        OnPropertyChanged(nameof(SelectionBoxBorderBrush));
        OnPropertyChanged(nameof(SelectionGlyphForeground));
    }

    private static Brush ResourceBrush(string key, Color fallback)
    {
        try
        {
            if (Application.Current?.Resources.ContainsKey(key) == true && Application.Current.Resources[key] is Brush brush)
            {
                return brush;
            }
        }
        catch
        {
            // Fall back to a local brush when the application resource dictionary is not ready yet.
        }

        return new SolidColorBrush(fallback);
    }

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
