namespace IntuneWinDownloader.WinUI.Models;

public sealed record ContentVersionResolveResult(
    string Version,
    bool Resolved,
    string Message,
    string Log);
