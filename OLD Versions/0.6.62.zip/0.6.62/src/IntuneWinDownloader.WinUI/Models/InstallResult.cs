namespace IntuneWinDownloader.WinUI.Models;

public sealed class InstallResult
{
    public int ExitCode { get; set; }
    public string MappedResult { get; set; } = string.Empty;
    public string ExecutionContext { get; set; } = string.Empty;
    public string WrapperPath { get; set; } = string.Empty;
    public string StdOutPath { get; set; } = string.Empty;
    public string StdErrPath { get; set; } = string.Empty;
    public string ExitCodePath { get; set; } = string.Empty;
}
