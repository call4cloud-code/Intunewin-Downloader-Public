using System.Collections.Concurrent;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security.Principal;
using IntuneWinDownloader.WinUI.Models;
using IntuneWinDownloader.WinUI.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Windows.Storage.Pickers;

namespace IntuneWinDownloader.WinUI;

public sealed partial class MainWindow : Window
{
    private const int MaxParallelDownloads = 5;
    private readonly NativeIntuneBackendService _backend = new();
    private readonly MetadataService _metadataService = new();
    private readonly List<AppRow> _allApps = new();
    private readonly Dictionary<string, DownloadResult> _downloadResults = new(StringComparer.OrdinalIgnoreCase);
    private AppRow? _selectedApp;
    private DownloadResult? _lastDownload;
    private int _batchTotal = 1;
    private int _batchIndex;
    private bool _logVisible = true;
    private bool _startupStarted;
    private bool _busy;
    private bool _uiReady;
    private int _selectionResolveStamp;
    private readonly HashSet<string> _versionResolveInFlight = new(StringComparer.OrdinalIgnoreCase);

    public ObservableCollection<AppRow> FilteredApps { get; } = new();

    private static string GetDisplayVersion()
    {
        var assembly = typeof(MainWindow).Assembly;
        var informationalVersion = assembly
            .GetCustomAttribute<AssemblyInformationalVersionAttribute>()?
            .InformationalVersion;

        var version = string.IsNullOrWhiteSpace(informationalVersion)
            ? assembly.GetName().Version?.ToString() ?? "0.0.0"
            : informationalVersion.Trim();

        var metadataIndex = version.IndexOf('+');
        if (metadataIndex > 0)
        {
            version = version[..metadataIndex];
        }

        var labelIndex = version.IndexOf('-');
        if (labelIndex > 0)
        {
            version = version[..labelIndex];
        }

        return $"v{version}";
    }

    public MainWindow()
    {
        InitializeComponent();
        _uiReady = true;
        _backend.ProgressChanged += Backend_ProgressChanged;
        var appVersion = GetDisplayVersion();
        AppVersionBadge.Text = appVersion;
        AppTitleText.Text = $"IntuneWin Downloader {appVersion}";
        AppSubtitleText.Text = $"Download and extract app packages, then test the install command locally • {appVersion}";
        Title = $"IntuneWin Downloader {appVersion}";
        AdminBadge.Text = IsAdmin() ? "Running as admin" : "Not running as admin";
        RootGrid.Loaded += MainWindow_Loaded;
        RootGrid.ActualThemeChanged += RootGrid_ActualThemeChanged;
        UpdateVersionInputState();
        AppendLog("Ready.");
        UpdateActionState();
    }

    private void RootGrid_ActualThemeChanged(FrameworkElement sender, object args)
    {
        foreach (var app in _allApps)
        {
            app.RefreshThemeBrushes();
        }
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        if (_startupStarted) return;
        _startupStarted = true;
        await RunStartupAsync();
    }

    private async Task RunStartupAsync()
    {
        StartupOverlay.Visibility = Visibility.Visible;
        StartupRing.IsActive = true;
        StartupProgress.IsIndeterminate = true;
        StartupTitle.Text = "Preparing IntuneWin Downloader";

        SetBusy(true, "Preparing the app list...");
        try
        {
            StartupMessage.Text = "Checking access...";
            var initResult = await _backend.InitializeAsync();
            AppendLog(initResult.Log);

            StartupMessage.Text = "Loading apps...";
            var appsResult = await _backend.LoadAppsAsync();
            AppendLog(appsResult.Log);

            _allApps.Clear();
            _allApps.AddRange(appsResult.Apps);
            ApplyFilter();

            StartupProgress.IsIndeterminate = false;
            StartupProgress.Value = 100;
            StartupMessage.Text = $"Loaded {FilteredApps.Count} apps.";
            StatusInfo.Message = $"Loaded {FilteredApps.Count} apps.";
            StatusInfo.Severity = InfoBarSeverity.Success;
            await Task.Delay(450);
            StartupOverlay.Visibility = Visibility.Collapsed;
        }
        catch (Exception ex)
        {
            StartupProgress.IsIndeterminate = false;
            StartupProgress.Value = 0;
            StartupMessage.Text = "Could not load the app list automatically. You can still use Initialize and Load apps manually.";
            StatusInfo.Message = ex.Message;
            StatusInfo.Severity = InfoBarSeverity.Error;
            AppendLog("ERROR: " + ex.Message);
            await Task.Delay(900);
            StartupOverlay.Visibility = Visibility.Collapsed;
        }
        finally
        {
            StartupRing.IsActive = false;
            SetBusy(false, string.Empty);
        }
    }

    private async void Initialize_Click(object sender, RoutedEventArgs e)
    {
        await RunUiActionAsync("Preparing...", async () =>
        {
            var result = await _backend.InitializeAsync();
            AppendLog(result.Log);
            StatusInfo.Message = "Ready. click Load apps.";
            StatusInfo.Severity = InfoBarSeverity.Success;
        });
    }

    private async void LoadApps_Click(object sender, RoutedEventArgs e)
    {
        await RunUiActionAsync("Loading apps...", async () =>
        {
            var result = await _backend.LoadAppsAsync();
            AppendLog(result.Log);
            _allApps.Clear();
            _allApps.AddRange(result.Apps);
            _downloadResults.Clear();
            _lastDownload = null;
            ApplyFilter();
            UpdateCheckedState();
            UpdateActionState();
            StatusInfo.Message = $"Loaded {FilteredApps.Count} apps.";
            StatusInfo.Severity = InfoBarSeverity.Success;
        });
    }

    private async void Download_Click(object sender, RoutedEventArgs e)
    {
        await DownloadCurrentSelectionAsync();
    }

    private async void DownloadSelected_Click(object sender, RoutedEventArgs e)
    {
        await DownloadCurrentSelectionAsync();
    }

    private List<AppRow> GetDownloadSelection()
    {
        var checkedApps = _allApps
            .Where(a => a.IsChecked)
            .ToList();

        if (checkedApps.Count == 0 && _selectedApp is not null)
        {
            checkedApps.Add(_selectedApp);
        }

        return checkedApps
            .Where(a => !string.IsNullOrWhiteSpace(a.Id))
            .GroupBy(a => a.Id, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .ToList();
    }

    private async Task DownloadCurrentSelectionAsync()
    {
        var apps = GetDownloadSelection();
        if (apps.Count == 0)
        {
            StatusInfo.Message = "Select one or more apps first.";
            StatusInfo.Severity = InfoBarSeverity.Warning;
            return;
        }

        await DownloadAppsAsync(apps);
    }

    private async Task DownloadAppsAsync(IEnumerable<AppRow> appsToDownload)
    {
        var apps = appsToDownload
            .Where(a => !string.IsNullOrWhiteSpace(a.Id))
            .GroupBy(a => a.Id, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .ToList();

        if (apps.Count == 0)
        {
            StatusInfo.Message = "Select one or more apps first.";
            StatusInfo.Severity = InfoBarSeverity.Warning;
            return;
        }

        Interlocked.Increment(ref _selectionResolveStamp);

        if (apps.Count == 1)
        {
            await DownloadSingleAppAsync(apps[0], OutputFolderBox.Text.Trim());
            return;
        }

        await DownloadAppsInParallelAsync(apps, OutputFolderBox.Text.Trim());
    }

    private async Task DownloadSingleAppAsync(AppRow app, string outputRoot)
    {
        SetBusy(true, "Downloading app package...");
        _batchTotal = 1;
        _batchIndex = 0;

        try
        {
            _selectedApp = app;
            AppsList.SelectedItem = app;

            var version = await GetVersionForDownloadAsync(app);
            AppendLog($"Starting download: {app.Name} [{app.Id}] content version [{version}]");
            StatusInfo.Message = $"Downloading {app.Name}...";
            StatusInfo.Severity = InfoBarSeverity.Informational;

            var result = await _backend.DownloadAsync(app, version, outputRoot);
            AppendLog(result.Log);
            _lastDownload = result.Result;
            _downloadResults[app.Id] = result.Result;
            app.IsDownloaded = true;
            app.IsChecked = false;

            UpdateCheckedState();
            UpdateActionState();

            StatusInfo.Message = "Download complete. Folder opened.";
            StatusInfo.Severity = InfoBarSeverity.Success;
            OpenFolder(result.Result.WorkFolder);
        }
        catch (Exception ex)
        {
            StatusInfo.Message = "Download failed. Check details below.";
            StatusInfo.Severity = InfoBarSeverity.Error;
            AppendLog($"ERROR: Download failed for {app.Name}: {ex.Message}");
        }
        finally
        {
            _batchTotal = 1;
            _batchIndex = 0;
            SetBusy(false, string.Empty);
            UpdateActionState();
        }
    }

    private async Task DownloadAppsInParallelAsync(List<AppRow> apps, string outputRoot)
    {
        var maxParallel = Math.Min(MaxParallelDownloads, apps.Count);
        SetBusy(true, AutoVersionBox.IsChecked == true ? $"Resolving content versions for {apps.Count} apps..." : $"Preparing {apps.Count} selected apps...");
        await ResolveContentVersionsForDownloadAsync(apps);
        var versionFallback = AutoVersionBox.IsChecked == true ? string.Empty : (VersionBox.Text?.Trim() ?? string.Empty);
        var requests = apps.Select((app, index) => new DownloadRequest(app, string.IsNullOrWhiteSpace(versionFallback) ? (app.ContentVersionResolved ? app.Version : "auto") : versionFallback, index + 1)).ToList();
        var progressByApp = new ConcurrentDictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var results = new ConcurrentBag<ParallelDownloadResult>();
        using var gate = new SemaphoreSlim(maxParallel, maxParallel);
        var completed = 0;

        SetBusy(true, $"Downloading {apps.Count} selected apps...");
        ActionProgress.IsIndeterminate = false;
        ActionProgress.Value = 0;
        ActionProgressText.Text = $"0%  (0/{apps.Count})";
        _batchTotal = apps.Count;
        _batchIndex = 0;

        try
        {
            AppendLog($"Starting download batch. Apps: {apps.Count}. Parallel workers: {maxParallel}.");
            StatusInfo.Message = $"Downloading {apps.Count} selected apps...";
            StatusInfo.Severity = InfoBarSeverity.Informational;

            var tasks = requests.Select(async request =>
            {
                await gate.WaitAsync();
                try
                {
                    await DownloadOneAppInParallelAsync(request, outputRoot, progressByApp, results, apps.Count, () => Volatile.Read(ref completed));
                    Interlocked.Increment(ref completed);
                    progressByApp[request.App.Id] = 100;
                    UpdateParallelBatchProgress(progressByApp, apps.Count, Volatile.Read(ref completed), request.App.Name, "completed");
                }
                finally
                {
                    gate.Release();
                }
            }).ToList();

            await Task.WhenAll(tasks);

            var orderedResults = results.OrderBy(r => r.Index).ToList();
            foreach (var item in orderedResults)
            {
                if (!string.IsNullOrWhiteSpace(item.Log))
                {
                    AppendLog(item.Log);
                }

                if (item.Error is null && item.Result is not null)
                {
                    _downloadResults[item.App.Id] = item.Result;
                    _lastDownload = item.Result;
                    item.App.IsDownloaded = true;
                    item.App.IsChecked = false;
                    AppendLog($"Parallel download completed: {item.App.Name}");
                }
                else
                {
                    AppendLog($"ERROR: Parallel download failed for {item.App.Name}: {item.Error}");
                }
            }

            var successCount = orderedResults.Count(r => r.Error is null && r.Result is not null);
            var failureCount = orderedResults.Count - successCount;

            UpdateCheckedState();
            UpdateActionState();

            if (successCount > 0)
            {
                StatusInfo.Message = failureCount == 0
                    ? $"Downloaded {successCount} apps in batch. Output folder opened."
                    : $"Downloaded {successCount} apps in batch. {failureCount} failed. Check details below.";
                StatusInfo.Severity = failureCount == 0 ? InfoBarSeverity.Success : InfoBarSeverity.Warning;
                if (Directory.Exists(outputRoot))
                {
                    OpenFolder(outputRoot);
                }
            }
            else
            {
                StatusInfo.Message = $"All {failureCount} downloads failed. Check details below.";
                StatusInfo.Severity = InfoBarSeverity.Error;
            }
        }
        finally
        {
            _batchTotal = 1;
            _batchIndex = 0;
            SetBusy(false, string.Empty);
            UpdateActionState();
        }
    }

    private async Task DownloadOneAppInParallelAsync(
        DownloadRequest request,
        string outputRoot,
        ConcurrentDictionary<string, int> progressByApp,
        ConcurrentBag<ParallelDownloadResult> results,
        int totalApps,
        Func<int> getCompletedCount)
    {
        var app = request.App;
        progressByApp[app.Id] = 0;
        var backend = _backend.CreateParallelDownloadChild();
        backend.ProgressChanged += (percent, message) =>
        {
            progressByApp[app.Id] = percent;
            UpdateParallelBatchProgress(progressByApp, totalApps, getCompletedCount(), app.Name, message);
        };

        try
        {
            DispatcherQueue.TryEnqueue(() => AppendLog($"Parallel worker started {request.Index}/{totalApps}: {app.Name} [{app.Id}] content version [{request.Version}]"));
            var result = await backend.DownloadAsync(app, request.Version, outputRoot);
            results.Add(new ParallelDownloadResult(request.Index, app, result.Result, result.Log, null));
        }
        catch (Exception ex)
        {
            results.Add(new ParallelDownloadResult(request.Index, app, null, string.Empty, ex.Message));
        }
    }

    private void UpdateParallelBatchProgress(ConcurrentDictionary<string, int> progressByApp, int totalApps, int completedCount, string appName, string message)
    {
        var progressValues = progressByApp.Values.ToList();
        var inFlightProgress = progressValues.Sum();
        var aggregate = Math.Clamp((int)Math.Round(inFlightProgress / (double)Math.Max(1, totalApps)), 0, 100);
        var safeCompleted = Math.Clamp(completedCount, 0, totalApps);
        var status = string.IsNullOrWhiteSpace(message) ? appName : $"{appName}: {message}";

        DispatcherQueue.TryEnqueue(() =>
        {
            if (!_busy) return;
            ActionProgress.Visibility = Visibility.Visible;
            ActionProgress.IsIndeterminate = false;
            ActionProgress.Value = aggregate;
            ActionProgressText.Text = $"{aggregate}%  ({safeCompleted}/{totalApps} completed)";
            StatusInfo.Message = status;
            StatusInfo.Severity = InfoBarSeverity.Informational;
        });
    }

    private sealed record DownloadRequest(AppRow App, string Version, int Index);

    private sealed record ParallelDownloadResult(int Index, AppRow App, DownloadResult? Result, string Log, string? Error);

    private void TestInstall_Click(object sender, RoutedEventArgs e)
    {
        var download = GetDownloadForSelectedApp() ?? _lastDownload;
        if (download is null)
        {
            StatusInfo.Message = "Download an app first.";
            StatusInfo.Severity = InfoBarSeverity.Warning;
            return;
        }

        try
        {
            var metadata = _metadataService.LoadInstallMetadata(download);
            var window = new InstallTestWindow(metadata, _metadataService);
            window.Activate();
        }
        catch (Exception ex)
        {
            StatusInfo.Message = ex.Message;
            StatusInfo.Severity = InfoBarSeverity.Error;
            AppendLog("ERROR: " + ex.Message);
        }
    }

    private void ExportLogs_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var zipPath = InstallLogExporter.ExportShownLogs(OutputFolderBox?.Text ?? string.Empty, LogText?.Text ?? string.Empty);

            StatusInfo.Message = "Shown logs exported: " + zipPath;
            StatusInfo.Severity = InfoBarSeverity.Success;
            AppendLog("Shown logs exported: " + zipPath);

            var folder = Path.GetDirectoryName(zipPath);
            if (!string.IsNullOrWhiteSpace(folder)) OpenFolder(folder);
        }
        catch (Exception ex)
        {
            StatusInfo.Message = "Log export failed: " + ex.Message;
            StatusInfo.Severity = InfoBarSeverity.Error;
            AppendLog("ERROR: Log export failed: " + ex.Message);
        }
    }

    private void ClearLogs_Click(object sender, RoutedEventArgs e)
    {
        if (LogText is not null)
        {
            LogText.Text = string.Empty;
        }

        ClearDefaultShownLogFile();

        StatusInfo.Message = "Shown logs cleared.";
        StatusInfo.Severity = InfoBarSeverity.Informational;
        UpdateActionState();
    }

    private async void BrowseOutput_Click(object sender, RoutedEventArgs e)
    {
        var picker = new FolderPicker();
        picker.FileTypeFilter.Add("*");
        var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
        WinRT.Interop.InitializeWithWindow.Initialize(picker, hwnd);
        var folder = await picker.PickSingleFolderAsync();
        if (folder is not null)
        {
            OutputFolderBox.Text = folder.Path;
        }
    }

    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (!_uiReady) return;
        ApplyFilter();
    }

    private void SortCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_uiReady) return;
        ApplyFilter();
    }

    private void AppsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        _selectedApp = AppsList.SelectedItem as AppRow;
        UpdateSelectedAppDetails();
        UpdateVersionBoxFromSelection();
        UpdateActionState();
        _ = ResolveSelectedContentVersionIfNeededAsync(_selectedApp);
    }

    private void UpdateSelectedAppDetails()
    {
        if (_selectedApp is null)
        {
            SelectedNameText.Text = "None";
            SelectedDetailsText.Text = string.Empty;
            return;
        }

        SelectedNameText.Text = _selectedApp.Name;
        SelectedDetailsText.Text =
            $"App version: {_selectedApp.DisplayVersionOrFallback}\n" +
            $"Package size: {_selectedApp.PackageSizeOrUnknown}\n" +
            $"Content version: {_selectedApp.ContentVersionDisplay}\n" +
            $"Content status: {_selectedApp.ContentVersionStatus}\n" +
            $"Publisher: {_selectedApp.PublisherOrUnknown}\n" +
            $"Status: {_selectedApp.Status}\n" +
            $"Source: {_selectedApp.Source}\n" +
            $"App ID: {_selectedApp.Id}\n" +
            _selectedApp.Details;
    }

    private void AutoVersionBox_Changed(object sender, RoutedEventArgs e)
    {
        UpdateVersionInputState();
        UpdateVersionBoxFromSelection();
        if (AutoVersionBox.IsChecked == true && _selectedApp is not null)
        {
            _ = ResolveSelectedContentVersionIfNeededAsync(_selectedApp);
        }
    }

    private void UpdateVersionInputState()
    {
        if (VersionBox is null || AutoVersionBox is null) return;
        VersionBox.IsEnabled = AutoVersionBox.IsChecked != true;
    }

    private void UpdateVersionBoxFromSelection()
    {
        if (VersionBox is null) return;
        if (AutoVersionBox?.IsChecked == true)
        {
            VersionBox.Text = _selectedApp is null ? "Auto" : _selectedApp.ContentVersionDisplay;
            return;
        }

        if (_selectedApp is not null && !string.IsNullOrWhiteSpace(_selectedApp.Version))
        {
            VersionBox.Text = _selectedApp.Version;
        }
    }

    private async Task ResolveSelectedContentVersionIfNeededAsync(AppRow? app)
    {
        if (app is null || AutoVersionBox?.IsChecked != true) return;
        if (_busy) return;
        if (string.IsNullOrWhiteSpace(app.Id)) return;
        if (app.ContentVersionResolved)
        {
            UpdateVersionBoxFromSelection();
            return;
        }
        if (!_versionResolveInFlight.Add(app.Id))
        {
            VersionBox.Text = app.ContentVersionDisplay;
            return;
        }

        var stamp = Interlocked.Increment(ref _selectionResolveStamp);
        app.MarkContentVersionUnresolved("Resolving...");
        if (_selectedApp == app)
        {
            VersionBox.Text = "Resolving...";
            UpdateSelectedAppDetails();
        }

        try
        {
            var result = await _backend.ResolveContentVersionAsync(app);
            if (_busy || stamp != _selectionResolveStamp || _selectedApp != app)
            {
                return;
            }

            AppendLog(result.Log);
            if (result.Resolved && !string.IsNullOrWhiteSpace(result.Version))
            {
                app.MarkContentVersionResolved(result.Version, result.Message);
            }
            else
            {
                app.MarkContentVersionUnresolved(result.Message);
            }

            if (stamp == _selectionResolveStamp && _selectedApp == app)
            {
                VersionBox.Text = app.ContentVersionResolved ? app.Version : "Auto";
                UpdateSelectedAppDetails();
            }
        }
        catch (Exception ex)
        {
            app.MarkContentVersionUnresolved("Resolve failed. No version guessed.");
            AppendLog($"ERROR: Content version resolve failed for {app.Name}: {ex.Message}");
            if (stamp == _selectionResolveStamp && _selectedApp == app)
            {
                VersionBox.Text = "Auto";
                UpdateSelectedAppDetails();
            }
        }
        finally
        {
            _versionResolveInFlight.Remove(app.Id);
        }
    }

    private async Task ResolveContentVersionsForDownloadAsync(List<AppRow> apps)
    {
        if (AutoVersionBox?.IsChecked != true) return;

        foreach (var app in apps)
        {
            if (app.ContentVersionResolved) continue;
            if (!_versionResolveInFlight.Add(app.Id)) continue;
            StatusInfo.Message = $"Resolving content version for {app.Name}...";
            StatusInfo.Severity = InfoBarSeverity.Informational;

            try
            {
                var result = await _backend.ResolveContentVersionAsync(app);
                AppendLog(result.Log);
                if (result.Resolved && !string.IsNullOrWhiteSpace(result.Version))
                {
                    app.MarkContentVersionResolved(result.Version, result.Message);
                }
                else
                {
                    app.MarkContentVersionUnresolved(result.Message);
                }
            }
            catch (Exception ex)
            {
                app.MarkContentVersionUnresolved("Resolve failed. No version guessed.");
                AppendLog($"ERROR: Content version resolve failed for {app.Name}: {ex.Message}");
            }
            finally
            {
                _versionResolveInFlight.Remove(app.Id);
            }
        }

        UpdateVersionBoxFromSelection();
        UpdateSelectedAppDetails();
    }

    private async Task<string> GetVersionForDownloadAsync(AppRow app)
    {
        if (AutoVersionBox?.IsChecked == true)
        {
            if (!app.ContentVersionResolved)
            {
                await ResolveContentVersionsForDownloadAsync(new List<AppRow> { app });
            }

            return app.ContentVersionResolved && !string.IsNullOrWhiteSpace(app.Version) ? app.Version.Trim() : "auto";
        }

        var manual = VersionBox.Text?.Trim();
        return string.IsNullOrWhiteSpace(manual) ? "1" : manual;
    }

    private void RowCheckBox_CheckChanged(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        UpdateCheckedState();
        UpdateActionState();
    }

    private void RowCheckBox_Tapped(object sender, TappedRoutedEventArgs e)
    {
        if (!_busy && (sender as FrameworkElement)?.DataContext is AppRow app)
        {
            app.IsChecked = !app.IsChecked;
            AppsList.SelectedItem = app;
            _selectedApp = app;
            UpdateSelectedAppDetails();
            UpdateVersionBoxFromSelection();
            _ = ResolveSelectedContentVersionIfNeededAsync(_selectedApp);
            UpdateCheckedState();
            UpdateActionState();
        }

        e.Handled = true;
    }

    private void AppRow_Tapped(object sender, TappedRoutedEventArgs e)
    {
        if (_busy) return;
        if ((sender as FrameworkElement)?.DataContext is not AppRow app) return;

        app.IsChecked = !app.IsChecked;
        AppsList.SelectedItem = app;
        _selectedApp = app;
        UpdateSelectedAppDetails();
        UpdateVersionBoxFromSelection();
        _ = ResolveSelectedContentVersionIfNeededAsync(_selectedApp);
        UpdateCheckedState();
        UpdateActionState();
        e.Handled = true;
    }

    private void SelectAllBox_Checked(object sender, RoutedEventArgs e)
    {
        if (_busy || SelectAllBox.IsChecked != true) return;
        foreach (var app in FilteredApps)
        {
            app.IsChecked = true;
        }
        UpdateCheckedState();
        UpdateActionState();
    }

    private void SelectAllBox_Unchecked(object sender, RoutedEventArgs e)
    {
        if (_busy || SelectAllBox.IsChecked != false) return;
        foreach (var app in FilteredApps)
        {
            app.IsChecked = false;
        }
        UpdateCheckedState();
        UpdateActionState();
    }

    private void UpdateCheckedState()
    {
        var checkedCount = _allApps.Count(a => a.IsChecked);
        var visibleCheckedCount = FilteredApps.Count(a => a.IsChecked);
        var totalCount = FilteredApps.Count;

        if (SelectedCountText is not null)
        {
            SelectedCountText.Text = checkedCount > 0
                ? (checkedCount == 1 ? "1 app selected" : $"{checkedCount} apps selected")
                : string.Empty;
        }

        if (SelectedCountChip is not null)
        {
            SelectedCountChip.Visibility = checkedCount > 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        if (DownloadSelectedText is not null)
        {
            DownloadSelectedText.Text = checkedCount > 0
                ? (checkedCount == 1 ? "Download selected app" : $"Download {checkedCount} selected")
                : "Download selected";
        }

        if (SelectAllBox is not null)
        {
            SelectAllBox.Checked -= SelectAllBox_Checked;
            SelectAllBox.Unchecked -= SelectAllBox_Unchecked;
            SelectAllBox.IsChecked = totalCount > 0 && visibleCheckedCount == totalCount;
            SelectAllBox.Checked += SelectAllBox_Checked;
            SelectAllBox.Unchecked += SelectAllBox_Unchecked;
        }
    }

    private void UpdateActionState()
    {
        if (DownloadButton is null || DownloadSelectedButton is null || TestInstallButton is null || ExportLogsButton is null || ClearLogsButton is null) return;
        DownloadButton.IsEnabled = !_busy && _selectedApp is not null;
        var hasDownloadSelection = _allApps.Any(a => a.IsChecked) || _selectedApp is not null;
        DownloadSelectedButton.IsEnabled = !_busy && hasDownloadSelection;
        TestInstallButton.IsEnabled = !_busy && (GetDownloadForSelectedApp() is not null || _lastDownload is not null);
        ExportLogsButton.IsEnabled = !_busy;
        ClearLogsButton.IsEnabled = !_busy && !string.IsNullOrWhiteSpace(LogText?.Text);
    }

    private DownloadResult? GetDownloadForSelectedApp()
    {
        if (_selectedApp is null || string.IsNullOrWhiteSpace(_selectedApp.Id)) return null;
        return _downloadResults.TryGetValue(_selectedApp.Id, out var result) ? result : null;
    }

    private async Task RunUiActionAsync(string status, Func<Task> action)
    {
        SetBusy(true, status);
        try
        {
            await action();
        }
        catch (Exception ex)
        {
            StatusInfo.Message = ex.Message;
            StatusInfo.Severity = InfoBarSeverity.Error;
            AppendLog("ERROR: " + ex.Message);
        }
        finally
        {
            SetBusy(false, string.Empty);
        }
    }

    private void SetBusy(bool busy, string status)
    {
        _busy = busy;
        BusyRing.IsActive = busy;
        BusyRing.Visibility = busy ? Visibility.Visible : Visibility.Collapsed;
        InitializeButton.IsEnabled = !busy;
        LoadAppsButton.IsEnabled = !busy;
        DownloadButton.IsEnabled = !busy;
        DownloadSelectedButton.IsEnabled = !busy;
        UpdateActionState();

        if (busy)
        {
            ActionProgress.Visibility = Visibility.Visible;
            ActionProgress.IsIndeterminate = true;
            ActionProgress.Value = 0;
            ActionProgressText.Text = string.Empty;
        }
        else
        {
            ActionProgress.IsIndeterminate = false;
            ActionProgress.Value = 0;
            ActionProgress.Visibility = Visibility.Collapsed;
            ActionProgressText.Text = string.Empty;
        }

        if (!string.IsNullOrWhiteSpace(status))
        {
            StatusInfo.Message = status;
            StatusInfo.Severity = InfoBarSeverity.Informational;
        }
    }

    private void Backend_ProgressChanged(int percent, string message)
    {
        DispatcherQueue.TryEnqueue(() =>
        {
            if (!_busy && StartupOverlay.Visibility != Visibility.Visible) return;
            var clamped = Math.Clamp(percent, 0, 100);
            var displayPercent = clamped;
            var displayMessage = message;
            if (_batchTotal > 1)
            {
                displayPercent = Math.Clamp((int)Math.Round(((_batchIndex * 100d) + clamped) / _batchTotal), 0, 100);
                displayMessage = string.IsNullOrWhiteSpace(message)
                    ? $"Downloading {_batchIndex + 1} of {_batchTotal}..."
                    : $"{_batchIndex + 1}/{_batchTotal}: {message}";
            }

            ActionProgress.Visibility = Visibility.Visible;
            ActionProgress.IsIndeterminate = false;
            ActionProgress.Value = displayPercent;
            ActionProgressText.Text = _batchTotal > 1 ? $"{displayPercent}%  ({_batchIndex + 1}/{_batchTotal})" : displayPercent + "%";

            if (StartupOverlay.Visibility == Visibility.Visible)
            {
                StartupProgress.IsIndeterminate = false;
                StartupProgress.Value = displayPercent;
                if (!string.IsNullOrWhiteSpace(displayMessage))
                {
                    StartupMessage.Text = displayMessage;
                }
            }

            if (!string.IsNullOrWhiteSpace(displayMessage))
            {
                StatusInfo.Message = displayMessage;
                StatusInfo.Severity = InfoBarSeverity.Informational;
            }
        });
    }

    private void ApplyFilter()
    {
        if (!_uiReady || SearchBox is null || SortCombo is null) return;

        var query = SearchBox.Text?.Trim() ?? string.Empty;
        IEnumerable<AppRow> items = string.IsNullOrWhiteSpace(query)
            ? _allApps
            : _allApps.Where(a =>
                a.Name.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                a.Id.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                a.Publisher.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                a.PackageSize.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                a.Details.Contains(query, StringComparison.OrdinalIgnoreCase));

        items = (SortCombo.SelectedIndex) switch
        {
            1 => items.OrderByDescending(a => a.Name).ThenBy(a => a.Publisher),
            2 => items.OrderBy(a => a.Publisher).ThenBy(a => a.Name),
            3 => items.OrderBy(a => a.DisplayVersion).ThenBy(a => a.Name),
            4 => items.OrderByDescending(a => a.PackageSizeBytes).ThenBy(a => a.Name),
            _ => items.OrderBy(a => a.Name).ThenBy(a => a.Publisher)
        };

        FilteredApps.Clear();
        foreach (var item in items)
        {
            FilteredApps.Add(item);
        }

        UpdateCheckedState();
        UpdateActionState();
    }

    private void OpenOutputFolder_Click(object sender, RoutedEventArgs e)
    {
        var selectedDownload = GetDownloadForSelectedApp();
        if (selectedDownload is not null && Directory.Exists(selectedDownload.WorkFolder))
        {
            OpenFolder(selectedDownload.WorkFolder);
            return;
        }

        if (_lastDownload is not null && Directory.Exists(_lastDownload.WorkFolder))
        {
            OpenFolder(_lastDownload.WorkFolder);
            return;
        }

        var output = OutputFolderBox.Text.Trim();
        if (Directory.Exists(output))
        {
            OpenFolder(output);
        }
    }

    private void ShowLog_Click(object sender, RoutedEventArgs e)
    {
        _logVisible = !_logVisible;
        LogPanel.Visibility = _logVisible ? Visibility.Visible : Visibility.Collapsed;
    }

    private void AppendLog(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return;
        var cleanText = text.TrimEnd();
        LogText.Text += cleanText + Environment.NewLine;
        WriteDefaultShownLogFile(cleanText);
        LogScroller.ChangeView(null, LogScroller.ScrollableHeight, null);
        UpdateActionState();
    }

    private string GetDefaultShownLogPath()
    {
        var baseFolder = OutputFolderBox?.Text?.Trim();
        if (string.IsNullOrWhiteSpace(baseFolder))
        {
            baseFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "IntuneWinDownloader");
        }

        var logFolder = Path.Combine(baseFolder, "ToolLogs");
        Directory.CreateDirectory(logFolder);
        return Path.Combine(logFolder, "IntuneWinDownloader_CurrentToolLog.txt");
    }

    private void WriteDefaultShownLogFile(string text)
    {
        try
        {
            var path = GetDefaultShownLogPath();
            File.AppendAllText(path, text + Environment.NewLine);
        }
        catch
        {
            // The UI log is the source of truth. File mirroring must never break the app flow.
        }
    }

    private void ClearDefaultShownLogFile()
    {
        try
        {
            var path = GetDefaultShownLogPath();
            File.WriteAllText(path, string.Empty);
        }
        catch
        {
            // Ignore mirror cleanup failures. The shown log was already cleared.
        }
    }

    private static bool IsAdmin()
    {
        using var identity = WindowsIdentity.GetCurrent();
        var principal = new WindowsPrincipal(identity);
        return principal.IsInRole(WindowsBuiltInRole.Administrator);
    }

    private static void OpenFolder(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path)) return;
        Process.Start(new ProcessStartInfo("explorer.exe", Quote(path)) { UseShellExecute = true });
    }

    private static string Quote(string value) => "\"" + value.Replace("\"", "\\\"") + "\"";
}
