using System.Diagnostics;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using IntuneWinDownloader.WinUI.Models;
using IntuneWinDownloader.WinUI.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace IntuneWinDownloader.WinUI;

public sealed partial class InstallTestWindow : Window
{
    private readonly InstallMetadata _metadata;
    private readonly MetadataService _metadataService;
    private readonly InstallRunner _runner = new();
    private string _currentOriginalCommand = string.Empty;
    private string _currentCommandSourceLabel = string.Empty;
    private InstallResult? _lastResult;

    public InstallTestWindow(InstallMetadata metadata, MetadataService metadataService)
    {
        InitializeComponent();
        _metadata = metadata;
        _metadataService = metadataService;

        TitleText.Text = "Install test: " + metadata.AppName;
        SubtitleText.Text = $"This runs the selected command from the extracted app folder. Policy commands are preferred when a SideCar app policy payload returned a matching app. Suggested run mode: {metadata.InstallBehavior}";
        WorkingDirectoryBox.Text = metadata.WorkingDirectory;

        if (metadata.InstallBehavior.Equals("System", StringComparison.OrdinalIgnoreCase))
        {
            RunModeBox.SelectedIndex = 1;
        }

        CommandSourceBox.SelectedIndex = 0;
        CommandSelectionBox.SelectedIndex = 0;
        RefreshSelectedCommand();
    }

    private void CommandSelectionBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_metadata is null) return;
        RefreshSelectedCommand();
    }

    private void CommandSourceBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_metadata is null) return;
        RefreshSelectedCommand(false);
    }

    private void RemoveSilentCheck_Changed(object sender, RoutedEventArgs e)
    {
        if (_metadata is null) return;
        AggressiveCheck.IsEnabled = RemoveSilentCheck.IsChecked == true;
        RefreshEditableCommand();
    }

    private void RefreshSelectedCommand(bool refreshSourceOptions = true)
    {
        RefreshCommandTypeOptions();
        var uninstallSelected = CommandSelectionBox.SelectedIndex == 1;
        if (refreshSourceOptions)
        {
            RefreshCommandSourceOptions(uninstallSelected);
        }

        var selected = ResolveSelectedCommand(uninstallSelected);
        _currentOriginalCommand = selected.Command;
        _currentCommandSourceLabel = selected.SourceLabel;

        OriginalCommandBox.Text = _currentOriginalCommand;
        RunButton.Content = uninstallSelected ? "Run uninstall command" : "Run install command";
        CommandSourceText.Text = BuildCommandSourceText(uninstallSelected, selected);
        RefreshEditableCommand();
    }

    private void RefreshCommandTypeOptions()
    {
        if (CommandSelectionBox.Items.Count > 1 && CommandSelectionBox.Items[1] is ComboBoxItem uninstallItem)
        {
            uninstallItem.IsEnabled = !string.IsNullOrWhiteSpace(GetAutoCommand(true));
            if (!uninstallItem.IsEnabled && CommandSelectionBox.SelectedIndex == 1)
            {
                CommandSelectionBox.SelectedIndex = 0;
            }
        }
    }

    private void RefreshCommandSourceOptions(bool uninstallSelected)
    {
        var selectedIndex = CommandSourceBox.SelectedIndex < 0 ? 0 : CommandSourceBox.SelectedIndex;

        SetCommandSourceItemEnabled(0, !string.IsNullOrWhiteSpace(GetAutoCommand(uninstallSelected)));
        SetCommandSourceItemEnabled(1, !string.IsNullOrWhiteSpace(GetPolicyCommand(uninstallSelected)));
        SetCommandSourceItemEnabled(2, !string.IsNullOrWhiteSpace(GetPackageCommand(uninstallSelected)));

        if (!IsCommandSourceItemEnabled(selectedIndex))
        {
            selectedIndex = 0;
        }

        CommandSourceBox.SelectedIndex = selectedIndex;
    }

    private void SetCommandSourceItemEnabled(int index, bool isEnabled)
    {
        if (CommandSourceBox.Items.Count > index && CommandSourceBox.Items[index] is ComboBoxItem item)
        {
            item.IsEnabled = isEnabled;
        }
    }

    private bool IsCommandSourceItemEnabled(int index)
    {
        return CommandSourceBox.Items.Count > index && CommandSourceBox.Items[index] is ComboBoxItem item && item.IsEnabled;
    }

    private CommandChoice ResolveSelectedCommand(bool uninstallSelected)
    {
        return CommandSourceBox.SelectedIndex switch
        {
            1 => new CommandChoice(GetPolicyCommand(uninstallSelected), "IME policy command", true, false),
            2 => new CommandChoice(GetPackageCommand(uninstallSelected), "Package metadata command", false, true),
            _ => ResolveAutoCommand(uninstallSelected)
        };
    }

    private CommandChoice ResolveAutoCommand(bool uninstallSelected)
    {
        var policy = GetPolicyCommand(uninstallSelected);
        var package = GetPackageCommand(uninstallSelected);

        if (!uninstallSelected && LooksLikePatchMyPcScriptRunner(policy) && !string.IsNullOrWhiteSpace(package))
        {
            return new CommandChoice(package, "Auto preferred: package metadata command", false, true);
        }

        if (!string.IsNullOrWhiteSpace(policy)) return new CommandChoice(policy, "Auto preferred: IME policy command", true, false);

        if (!string.IsNullOrWhiteSpace(package)) return new CommandChoice(package, "Auto preferred: package metadata command", false, true);

        var fallback = uninstallSelected ? _metadata.UninstallCommand : FirstNotEmpty(_metadata.InstallCommand, _metadata.Command, _metadata.PackageCommand);
        return new CommandChoice(fallback, "Auto preferred command", false, false);
    }

    private string GetAutoCommand(bool uninstallSelected) => ResolveAutoCommand(uninstallSelected).Command;

    private string GetPolicyCommand(bool uninstallSelected)
    {
        if (uninstallSelected)
        {
            return FirstNotEmpty(_metadata.UninstallScriptCommand, _metadata.PolicyUninstallCommand);
        }

        return FirstNotEmpty(_metadata.InstallScriptCommand, _metadata.PolicyInstallCommand);
    }

    private string GetPackageCommand(bool uninstallSelected)
    {
        if (uninstallSelected)
        {
            return FirstNotEmpty(_metadata.PackageUninstallCommand);
        }

        return FirstNotEmpty(_metadata.PackageInstallCommand, _metadata.PackageCommand);
    }

    private void RefreshEditableCommand()
    {
        if (RemoveSilentCheck.IsChecked == true)
        {
            EditableCommandBox.Text = _metadataService.RemoveSilentSwitches(_currentOriginalCommand, AggressiveCheck.IsChecked == true);
            RunModeBox.SelectedIndex = 0;
            RunModeBox.IsEnabled = false;
            WarningInfo.IsOpen = true;
        }
        else
        {
            EditableCommandBox.Text = _currentOriginalCommand;
            RunModeBox.IsEnabled = true;
            WarningInfo.IsOpen = false;
        }
    }

    private static bool LooksLikePatchMyPcScriptRunner(string? command)
    {
        if (string.IsNullOrWhiteSpace(command)) return false;
        return command.Contains("PatchMyPC-ScriptRunner.exe", StringComparison.OrdinalIgnoreCase)
               && command.Contains("/InstallPackage", StringComparison.OrdinalIgnoreCase);
    }

    private string BuildCommandSourceText(bool uninstallSelected, CommandChoice selected)
    {
        var parts = new List<string> { "Selected source: " + selected.SourceLabel };

        if (selected.UsesPolicy)
        {
            parts.Add("Policy file: 10_policy_commands.json");
            var source = FirstNotEmpty(_metadata.PolicyCommandSource, _metadata.CommandSource, "IME SideCar app policy");
            parts.Add("Policy source: " + source);

            if (_metadata.HasPowerShellScriptInstaller)
            {
                var scriptId = uninstallSelected ? _metadata.UninstallScriptId : _metadata.InstallScriptId;
                if (!string.IsNullOrWhiteSpace(scriptId)) parts.Add("Script id: " + scriptId);
            }

            if (!string.IsNullOrWhiteSpace(_metadata.PolicyNote)) parts.Add(_metadata.PolicyNote);
        }
        else if (selected.UsesPackageMetadata)
        {
            parts.Add("Package source: extracted Package.xml or 06_package_metadata.json. This is the rebuilt local test command, not the IME policy command.");
        }
        else
        {
            parts.Add("The tool picked the first available command for this action.");
        }

        if (!uninstallSelected && !string.IsNullOrWhiteSpace(GetPolicyCommand(false)) && !string.IsNullOrWhiteSpace(GetPackageCommand(false)) && !GetPolicyCommand(false).Equals(GetPackageCommand(false), StringComparison.OrdinalIgnoreCase))
        {
            parts.Add("Both IME policy and package metadata commands are available for comparison.");
        }

        return string.Join(" ", parts);
    }

    private async void Run_Click(object sender, RoutedEventArgs e)
    {
        RunButton.IsEnabled = false;
        InstallStatusPanel.Visibility = Visibility.Visible;
        InstallProgress.Visibility = Visibility.Visible;
        InstallRing.IsActive = true;
        InstallStatusTitle.Text = "Selected command is running";
        InstallStatusText.Text = "Silent installs can take a while. You can keep this window open while the command finishes.";

        try
        {
            var runAsSystem = RunModeBox.SelectedIndex == 1;
            if (RemoveSilentCheck.IsChecked == true && runAsSystem)
            {
                throw new InvalidOperationException("Visible installer mode cannot run as SYSTEM.");
            }

            var result = await _runner.RunAsync(EditableCommandBox.Text.Trim(), WorkingDirectoryBox.Text.Trim(), runAsSystem);
            _lastResult = result;
            InstallStatusTitle.Text = result.ExitCode == 0 ? "Command finished" : "Command finished with an error code";
            InstallStatusText.Text =
                $"Exit code: {result.ExitCode}\n" +
                $"Result: {result.MappedResult}\n" +
                $"Run mode: {result.ExecutionContext}\n" +
                $"Command file: {result.WrapperPath}\n" +
                $"Output log: {result.StdOutPath}\n" +
                $"Error log: {result.StdErrPath}";
        }
        catch (Exception ex)
        {
            InstallStatusTitle.Text = "Command failed";
            InstallStatusText.Text = ex.Message;
        }
        finally
        {
            InstallProgress.Visibility = Visibility.Collapsed;
            InstallRing.IsActive = false;
            RunButton.IsEnabled = true;
        }
    }

    private void ExportLogs_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var zipPath = ExportLogs();
            InstallStatusPanel.Visibility = Visibility.Visible;
            InstallProgress.Visibility = Visibility.Collapsed;
            InstallRing.IsActive = false;
            InstallStatusTitle.Text = "Logs exported";
            InstallStatusText.Text = zipPath;

            var folder = Path.GetDirectoryName(zipPath);
            if (!string.IsNullOrWhiteSpace(folder) && Directory.Exists(folder))
            {
                Process.Start(new ProcessStartInfo("explorer.exe", Quote(folder)) { UseShellExecute = true });
            }
        }
        catch (Exception ex)
        {
            InstallStatusPanel.Visibility = Visibility.Visible;
            InstallStatusTitle.Text = "Log export failed";
            InstallStatusText.Text = ex.Message;
        }
    }

    private string ExportLogs()
    {
        return InstallLogExporter.Export(
            _metadata,
            (CommandSelectionBox.SelectedIndex == 1 ? "Uninstall" : "Install") + " - " + _currentCommandSourceLabel,
            _currentOriginalCommand,
            EditableCommandBox.Text,
            WorkingDirectoryBox.Text,
            RunModeBox.SelectedIndex == 1 ? "SYSTEM" : "Current admin session",
            _lastResult,
            null);
    }

    private void OpenExtracted_Click(object sender, RoutedEventArgs e)
    {
        if (Directory.Exists(_metadata.ExtractedFolder))
        {
            Process.Start(new ProcessStartInfo("explorer.exe", Quote(_metadata.ExtractedFolder)) { UseShellExecute = true });
        }
    }

    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    private static void AddText(ZipArchive zip, HashSet<string> usedNames, string entryName, string content)
    {
        var safeEntryName = GetUniqueEntryName(usedNames, entryName.Replace('\\', '/'));
        var entry = zip.CreateEntry(safeEntryName, CompressionLevel.Optimal);
        using var writer = new StreamWriter(entry.Open(), Encoding.UTF8);
        writer.Write(content);
    }

    private static void AddFile(ZipArchive zip, HashSet<string> usedNames, string? path, string group)
    {
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return;
        var info = new FileInfo(path);
        if (info.Length > 50L * 1024 * 1024)
        {
            AddText(zip, usedNames, Path.Combine(group, Path.GetFileName(path) + ".skipped.txt"), "Skipped because the file is larger than 50 MB: " + path);
            return;
        }

        var entryName = GetUniqueEntryName(usedNames, Path.Combine(group, Path.GetFileName(path)).Replace('\\', '/'));
        zip.CreateEntryFromFile(path, entryName, CompressionLevel.Optimal);
    }

    private static string GetUniqueEntryName(HashSet<string> usedNames, string entryName)
    {
        if (usedNames.Add(entryName)) return entryName;
        var folder = Path.GetDirectoryName(entryName)?.Replace('\\', '/') ?? string.Empty;
        var file = Path.GetFileNameWithoutExtension(entryName);
        var extension = Path.GetExtension(entryName);
        for (var i = 2; ; i++)
        {
            var candidateFile = file + "_" + i + extension;
            var candidate = string.IsNullOrWhiteSpace(folder) ? candidateFile : folder + "/" + candidateFile;
            if (usedNames.Add(candidate)) return candidate;
        }
    }

    private static string MakeSafeFileName(string value)
    {
        foreach (var invalid in Path.GetInvalidFileNameChars()) value = value.Replace(invalid, '_');
        return string.IsNullOrWhiteSpace(value) ? "install" : value;
    }

    private static string FirstNotEmpty(params string[] values) => values.FirstOrDefault(v => !string.IsNullOrWhiteSpace(v)) ?? string.Empty;
    private static string Quote(string value) => "\"" + value.Replace("\"", "\\\"") + "\"";

    private sealed class CommandChoice
    {
        public CommandChoice(string command, string sourceLabel, bool usesPolicy, bool usesPackageMetadata)
        {
            Command = command ?? string.Empty;
            SourceLabel = sourceLabel ?? string.Empty;
            UsesPolicy = usesPolicy;
            UsesPackageMetadata = usesPackageMetadata;
        }

        public string Command { get; }
        public string SourceLabel { get; }
        public bool UsesPolicy { get; }
        public bool UsesPackageMetadata { get; }
    }
}
