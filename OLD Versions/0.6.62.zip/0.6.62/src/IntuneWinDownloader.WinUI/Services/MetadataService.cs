using System.Text.Json;
using System.Text.RegularExpressions;
using IntuneWinDownloader.WinUI.Models;

namespace IntuneWinDownloader.WinUI.Services;

public sealed class MetadataService
{
    public InstallMetadata LoadInstallMetadata(DownloadResult download)
    {
        if (string.IsNullOrWhiteSpace(download.WorkFolder))
        {
            throw new InvalidOperationException("No download result is available yet.");
        }

        var metadataFolder = string.IsNullOrWhiteSpace(download.MetadataFolder)
            ? Path.Combine(download.WorkFolder, "Metadata")
            : download.MetadataFolder;

        InstallMetadata packageMetadata;
        var packageMetadataPath = Path.Combine(metadataFolder, "06_package_metadata.json");
        if (File.Exists(packageMetadataPath))
        {
            packageMetadata = FromPackageMetadataJson(packageMetadataPath, download);
        }
        else
        {
            var packageXml = Path.Combine(download.ExtractedFolder, "Package.xml");
            if (!File.Exists(packageXml))
            {
                throw new FileNotFoundException("Could not find 06_package_metadata.json or Package.xml.", packageMetadataPath);
            }

            packageMetadata = FromPackageXml(packageXml, download);
        }

        packageMetadata.MetadataFolder = metadataFolder;
        packageMetadata.PackageCommand = FirstNotEmpty(packageMetadata.PackageCommand, packageMetadata.Command, packageMetadata.InstallCommand);
        packageMetadata.PackageInstallCommand = FirstNotEmpty(packageMetadata.PackageInstallCommand, packageMetadata.PackageCommand, packageMetadata.InstallCommand, packageMetadata.Command);
        packageMetadata.PackageUninstallCommand = FirstNotEmpty(packageMetadata.PackageUninstallCommand, packageMetadata.UninstallCommand);
        packageMetadata.InstallCommand = string.IsNullOrWhiteSpace(packageMetadata.InstallCommand) ? packageMetadata.Command : packageMetadata.InstallCommand;
        packageMetadata.CommandSource = string.IsNullOrWhiteSpace(packageMetadata.CommandSource) ? packageMetadata.Source : packageMetadata.CommandSource;

        var policyCommandsPath = Path.Combine(metadataFolder, "10_policy_commands.json");
        if (File.Exists(policyCommandsPath))
        {
            return ApplyPolicyCommands(policyCommandsPath, packageMetadata);
        }

        return packageMetadata;
    }

    public string RemoveSilentSwitches(string command, bool aggressive)
    {
        var output = command;
        var tokens = new[]
        {
            @"(?i)\s+/qn\b",
            @"(?i)\s+/qb!?\b",
            @"(?i)\s+/quiet\b",
            @"(?i)\s+/passive\b",
            @"(?i)\s+/silent\b",
            @"(?i)\s+/verysilent\b",
            @"(?i)\s+--quiet\b",
            @"(?i)\s+--silent\b",
            @"(?i)\s+-quiet\b",
            @"(?i)\s+-silent\b",
            @"(?i)\s+-NonInteractive\b",
            @"(?i)\s+-WindowStyle\s+Hidden\b"
        };

        foreach (var token in tokens)
        {
            output = Regex.Replace(output, token, " ");
        }

        if (aggressive)
        {
            var aggressiveTokens = new[]
            {
                @"(?i)\s+/S\b",
                @"(?i)\s+/s\b",
                @"(?i)\s+/norestart\b",
                @"(?i)\s+REBOOT=ReallySuppress\b"
            };

            foreach (var token in aggressiveTokens)
            {
                output = Regex.Replace(output, token, " ");
            }
        }

        return Regex.Replace(output, @"\s{2,}", " ").Trim();
    }

    private static InstallMetadata ApplyPolicyCommands(string path, InstallMetadata metadata)
    {
        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(path));
            var root = doc.RootElement;

            var policyInstall = GetString(root, "InstallCommandLine");
            var policyUninstall = GetString(root, "UninstallCommandLine");
            var scriptInstall = GetString(root, "InstallScriptCommandLine");
            var scriptUninstall = GetString(root, "UninstallScriptCommandLine");
            var installScriptId = GetString(root, "InstallScriptId");
            var uninstallScriptId = GetString(root, "UninstallScriptId");
            var source = GetString(root, "CommandSource");
            var note = GetString(root, "Note");
            var logPath = GetString(root, "ExpectedLogPath");
            var hasScript = GetBool(root, "HasPowerShellScriptInstaller");

            metadata.PolicyInstallCommand = policyInstall;
            metadata.PolicyUninstallCommand = policyUninstall;
            metadata.PolicyCommandSource = string.IsNullOrWhiteSpace(source) ? "IME SideCar app policy" : source;
            metadata.InstallScriptId = installScriptId;
            metadata.UninstallScriptId = uninstallScriptId;
            metadata.InstallScriptCommand = scriptInstall;
            metadata.UninstallScriptCommand = scriptUninstall;
            metadata.HasPowerShellScriptInstaller = hasScript;
            metadata.PolicyNote = note;

            var policyInstallIsRunnerPlaceholder = LooksLikePatchMyPcScriptRunner(policyInstall);
            var preferredInstall = policyInstallIsRunnerPlaceholder
                ? FirstNotEmpty(scriptInstall, metadata.PackageCommand, policyInstall, metadata.Command)
                : FirstNotEmpty(scriptInstall, policyInstall, metadata.PackageCommand, metadata.Command);
            var preferredUninstall = FirstNotEmpty(scriptUninstall, policyUninstall);

            if (!string.IsNullOrWhiteSpace(preferredInstall))
            {
                metadata.Command = preferredInstall;
                metadata.InstallCommand = preferredInstall;
                metadata.Source = string.IsNullOrWhiteSpace(source) ? "SideCar app policy" : source;
                metadata.CommandSource = metadata.Source;
            }

            metadata.UninstallCommand = preferredUninstall;
            if (!string.IsNullOrWhiteSpace(logPath)) metadata.LogPath = logPath;
            return metadata;
        }
        catch
        {
            return metadata;
        }
    }

    private InstallMetadata FromPackageMetadataJson(string path, DownloadResult download)
    {
        using var doc = JsonDocument.Parse(File.ReadAllText(path));
        var root = doc.RootElement;
        var extractedFolder = GetString(root, "ExtractedFolder") ?? download.ExtractedFolder;
        var content = FindPackageContent(root);
        if (content.ValueKind != JsonValueKind.Object)
        {
            throw new InvalidOperationException("Package metadata did not contain Package.xml content.");
        }

        var metadata = BuildMetadataFromContent(content, extractedFolder, download, "Downloaded package metadata");
        var rootInstall = FirstNotEmpty(GetString(root, "installCommandLine"), GetString(root, "InstallCommandLine"));
        var rootUninstall = FirstNotEmpty(GetString(root, "uninstallCommandLine"), GetString(root, "UninstallCommandLine"));
        if (!string.IsNullOrWhiteSpace(rootInstall))
        {
            metadata.PackageCommand = rootInstall;
            metadata.PackageInstallCommand = rootInstall;
        }

        if (!string.IsNullOrWhiteSpace(rootUninstall))
        {
            metadata.PackageUninstallCommand = rootUninstall;
        }

        return metadata;
    }

    private InstallMetadata FromPackageXml(string path, DownloadResult download)
    {
        var xml = new System.Xml.XmlDocument();
        xml.Load(path);
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (xml.DocumentElement is not null)
        {
            foreach (System.Xml.XmlNode node in xml.DocumentElement.ChildNodes)
            {
                if (node.NodeType == System.Xml.XmlNodeType.Element)
                {
                    map[node.Name] = node.InnerText;
                }
            }
        }

        return BuildMetadataFromMap(map, Path.GetDirectoryName(path) ?? download.ExtractedFolder, download, "Package.xml");
    }

    private InstallMetadata BuildMetadataFromContent(JsonElement content, string extractedFolder, DownloadResult download, string source)
    {
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var prop in content.EnumerateObject())
        {
            map[prop.Name] = prop.Value.ValueKind == JsonValueKind.String ? prop.Value.GetString() ?? string.Empty : prop.Value.ToString();
        }

        return BuildMetadataFromMap(map, extractedFolder, download, source);
    }

    private InstallMetadata BuildMetadataFromMap(Dictionary<string, string> content, string extractedFolder, DownloadResult download, string source)
    {
        var appName = Value(content, "ProductName") ?? download.AppName;
        var installBehavior = Value(content, "InstallationBehavior") ?? string.Empty;
        if (string.IsNullOrWhiteSpace(installBehavior)) installBehavior = Value(content, "InstallBehavior") ?? string.Empty;
        var commandLine = RepairMojibake(Value(content, "CommandLine") ?? string.Empty);
        var fields = ParsePatchMyPcCommandLine(commandLine);
        var mainFile = fields.TryGetValue("MainFile", out var mf) ? mf : string.Empty;
        var mainArg = fields.TryGetValue("MainArg", out var ma) ? ma : string.Empty;
        var loggingSwitch = fields.TryGetValue("LoggingSwitch", out var ls) ? ls : string.Empty;
        var loggingPath = fields.TryGetValue("LoggingPath", out var lp) ? lp : string.Empty;

        if (string.IsNullOrWhiteSpace(mainFile))
        {
            mainFile = FindSetupCandidate(extractedFolder);
        }

        var fullMainFile = string.IsNullOrWhiteSpace(mainFile)
            ? string.Empty
            : Path.Combine(extractedFolder, mainFile);

        var command = BuildCommand(fullMainFile, mainArg, loggingSwitch, loggingPath, appName);
        var logPath = ExpandLogPath(loggingPath, appName);

        return new InstallMetadata
        {
            AppName = string.IsNullOrWhiteSpace(appName) ? download.AppName : appName,
            WorkingDirectory = extractedFolder,
            ExtractedFolder = extractedFolder,
            MetadataFolder = download.MetadataFolder,
            SetupFile = mainFile,
            Command = command,
            InstallCommand = command,
            PackageCommand = command,
            PackageInstallCommand = command,
            PackageUninstallCommand = string.Empty,
            InstallBehavior = installBehavior,
            Source = source,
            CommandSource = source,
            LogPath = logPath
        };
    }

    private static JsonElement FindPackageContent(JsonElement root)
    {
        if (!root.TryGetProperty("ParsedMetadataFiles", out var parsed)) return default;

        if (parsed.ValueKind == JsonValueKind.Object)
        {
            if (parsed.TryGetProperty("Content", out var content)) return content;
            foreach (var item in parsed.EnumerateObject())
            {
                if (item.Value.ValueKind == JsonValueKind.Object && item.Value.TryGetProperty("Content", out var nested)) return nested;
            }
        }

        if (parsed.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in parsed.EnumerateArray())
            {
                if (item.ValueKind == JsonValueKind.Object && item.TryGetProperty("Content", out var content)) return content;
            }
        }

        return default;
    }

    private static Dictionary<string, string> ParsePatchMyPcCommandLine(string commandLine)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (string.IsNullOrWhiteSpace(commandLine)) return result;

        var parts = commandLine.Split('\u00FF', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        foreach (var rawPart in parts)
        {
            var part = rawPart.Trim().Trim('"');
            if (!part.StartsWith("/", StringComparison.Ordinal)) continue;
            var eq = part.IndexOf('=');
            if (eq < 2) continue;
            var key = part[1..eq];
            var value = part[(eq + 1)..].Trim().Trim('"');
            result[key] = value;
        }

        return result;
    }

    private static string BuildCommand(string fullMainFile, string mainArg, string loggingSwitch, string loggingPath, string appName)
    {
        if (string.IsNullOrWhiteSpace(fullMainFile)) return string.Empty;

        var extension = Path.GetExtension(fullMainFile);
        var expandedLogPath = ExpandLogPath(loggingPath, appName);
        var logArg = string.Empty;
        if (!string.IsNullOrWhiteSpace(loggingSwitch) && !string.IsNullOrWhiteSpace(expandedLogPath))
        {
            Directory.CreateDirectory(Path.GetDirectoryName(expandedLogPath) ?? loggingPath);
            logArg = loggingSwitch.Contains("{path}", StringComparison.OrdinalIgnoreCase)
                ? loggingSwitch.Replace("{path}", Quote(expandedLogPath), StringComparison.OrdinalIgnoreCase)
                : (loggingSwitch + " " + Quote(expandedLogPath));
        }

        if (extension.Equals(".msi", StringComparison.OrdinalIgnoreCase))
        {
            var args = string.Join(' ', new[] { Quote(fullMainFile), mainArg, "/qn", logArg }.Where(x => !string.IsNullOrWhiteSpace(x)));
            return "msiexec.exe /i " + args;
        }

        if (extension.Equals(".ps1", StringComparison.OrdinalIgnoreCase))
        {
            return string.Join(' ', new[] { "powershell.exe -NoProfile -ExecutionPolicy Bypass -File", Quote(fullMainFile), mainArg, logArg }.Where(x => !string.IsNullOrWhiteSpace(x)));
        }

        return string.Join(' ', new[] { Quote(fullMainFile), mainArg, logArg }.Where(x => !string.IsNullOrWhiteSpace(x)));
    }

    private static string FindSetupCandidate(string extractedFolder)
    {
        if (string.IsNullOrWhiteSpace(extractedFolder) || !Directory.Exists(extractedFolder)) return string.Empty;
        var msi = Directory.EnumerateFiles(extractedFolder, "*.msi", SearchOption.TopDirectoryOnly).FirstOrDefault();
        if (msi is not null) return Path.GetFileName(msi);
        var exe = Directory.EnumerateFiles(extractedFolder, "*.exe", SearchOption.TopDirectoryOnly)
            .OrderByDescending(f => Path.GetFileName(f).StartsWith("setup", StringComparison.OrdinalIgnoreCase) || Path.GetFileName(f).StartsWith("install", StringComparison.OrdinalIgnoreCase))
            .FirstOrDefault();
        return exe is null ? string.Empty : Path.GetFileName(exe);
    }

    private static string ExpandLogPath(string loggingPath, string appName)
    {
        if (string.IsNullOrWhiteSpace(loggingPath)) return string.Empty;
        var expanded = Environment.ExpandEnvironmentVariables(loggingPath);
        return Path.Combine(expanded, MakeSafeFileName(appName) + ".log");
    }

    private static string MakeSafeFileName(string value)
    {
        foreach (var invalid in Path.GetInvalidFileNameChars()) value = value.Replace(invalid, '_');
        return string.IsNullOrWhiteSpace(value) ? "install" : value;
    }

    private static string RepairMojibake(string value) => value.Replace("\u00C3\u00BF", "\u00FF", StringComparison.Ordinal);
    private static string? Value(Dictionary<string, string> map, string name) => map.TryGetValue(name, out var value) ? value : null;
    private static string Quote(string value) => "\"" + value.Replace("\"", "\\\"") + "\"";
    private static string FirstNotEmpty(params string[] values) => values.FirstOrDefault(v => !string.IsNullOrWhiteSpace(v)) ?? string.Empty;

    private static string GetString(JsonElement element, string name)
    {
        if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(name, out var value) || value.ValueKind == JsonValueKind.Null) return string.Empty;
        return value.ValueKind == JsonValueKind.String ? value.GetString() ?? string.Empty : value.ToString();
    }

    private static bool LooksLikePatchMyPcScriptRunner(string? command)
    {
        if (string.IsNullOrWhiteSpace(command)) return false;
        return command.Contains("PatchMyPC-ScriptRunner.exe", StringComparison.OrdinalIgnoreCase)
               && command.Contains("/InstallPackage", StringComparison.OrdinalIgnoreCase);
    }

    private static bool GetBool(JsonElement element, string name)
    {
        if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(name, out var value)) return false;
        if (value.ValueKind == JsonValueKind.True) return true;
        if (value.ValueKind == JsonValueKind.False) return false;
        return bool.TryParse(value.ToString(), out var result) && result;
    }
}
