using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;

namespace IntuneWinDownloader.WinUI.Services;

internal sealed class MdmCertificateInfo
{
    private const string MdmOid = "1.2.840.113556.5.6";
    private const string IssuerFragment = "Microsoft Intune MDM Device CA";

    public required X509Certificate2 Certificate { get; init; }
    public required string StorePath { get; init; }
    public required Guid DeviceId { get; init; }
    public required Guid AccountId { get; init; }
    public required string CertificateBlob { get; init; }

    public static MdmCertificateInfo Find()
    {
        var local = FindInStore(System.Security.Cryptography.X509Certificates.StoreLocation.LocalMachine, "LocalMachine\\My");
        if (local is not null) return local;

        var current = FindInStore(System.Security.Cryptography.X509Certificates.StoreLocation.CurrentUser, "CurrentUser\\My");
        if (current is not null) return current;

        throw new InvalidOperationException("No valid Intune MDM certificate found in LocalMachine\\My or CurrentUser\\My.");
    }

    private static MdmCertificateInfo? FindInStore(StoreLocation location, string displayLocation)
    {
        using var store = new X509Store(StoreName.My, location);
        store.Open(OpenFlags.ReadOnly);
        var matches = store.Certificates
            .OfType<X509Certificate2>()
            .Where(c => c.Issuer.Contains(IssuerFragment, StringComparison.OrdinalIgnoreCase) && c.Extensions.OfType<X509Extension>().Any(e => e.Oid?.Value == MdmOid))
            .OrderByDescending(c => c.HasPrivateKey)
            .ThenByDescending(c => c.NotAfter)
            .ToList();

        var cert = matches.FirstOrDefault();
        if (cert is null) return null;

        var subjectMatch = Regex.Match(cert.Subject, @"^CN=([\da-fA-F-]{36})");
        if (!subjectMatch.Success)
        {
            throw new InvalidOperationException("Could not parse DeviceId from certificate subject.");
        }

        var deviceId = Guid.Parse(subjectMatch.Groups[1].Value);
        var accountId = ExtractAccountId(cert);
        var certBlob = Convert.ToBase64String(cert.Export(X509ContentType.Cert));

        return new MdmCertificateInfo
        {
            Certificate = cert,
            StorePath = displayLocation,
            DeviceId = deviceId,
            AccountId = accountId,
            CertificateBlob = certBlob
        };
    }

    private static Guid ExtractAccountId(X509Certificate2 cert)
    {
        var ext = cert.Extensions.OfType<X509Extension>().FirstOrDefault(e => e.Oid?.Value == MdmOid);
        if (ext is null) return Guid.Empty;

        var raw = ext.RawData;
        byte[]? bytes = null;
        if (raw.Length == 16)
        {
            bytes = raw;
        }
        else if (raw.Length == 18 && raw[0] == 4 && raw[1] == 16)
        {
            bytes = raw.Skip(2).Take(16).ToArray();
        }

        return bytes is null ? Guid.Empty : new Guid(bytes);
    }
}
