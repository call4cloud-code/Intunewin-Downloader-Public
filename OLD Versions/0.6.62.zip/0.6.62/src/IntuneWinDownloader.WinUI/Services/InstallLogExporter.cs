using System.IO.Compression;
using System.Text;
using System.Text.Json;
using IntuneWinDownloader.WinUI.Models;

namespace IntuneWinDownloader.WinUI.Services;

internal static class InstallLogExporter
{
    public static string Export(
        InstallMetadata metadata,
        string commandType,
        string originalCommand,
        string editedCommand,
        string workingDirectory,
        string runMode,
        InstallResult? lastResult,
        string? toolLogText = null)
    {
        var workFolder = !string.IsNullOrWhiteSpace(metadata.MetadataFolder)
            ? Path.GetDirectoryName(metadata.MetadataFolder)
            : Path.GetDirectoryName(metadata.ExtractedFolder);
        if (string.IsNullOrWhiteSpace(workFolder)) workFolder = Path.GetTempPath();

        var exportFolder = Path.Combine(workFolder, "TestInstallLogs");
        Directory.CreateDirectory(exportFolder);
        var zipPath = Path.Combine(exportFolder, MakeSafeFileName(metadata.AppName) + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".zip");

        var usedNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using var zip = ZipFile.Open(zipPath, ZipArchiveMode.Create);

        AddText(zip, usedNames, "00_test_install_selection.json", JsonSerializer.Serialize(new
        {
            ExportedAt = DateTimeOffset.Now.ToString("o"),
            AppName = metadata.AppName,
            CommandType = commandType,
            CommandSource = metadata.CommandSource,
            OriginalCommand = originalCommand,
            EditedCommand = editedCommand,
            WorkingDirectory = workingDirectory,
            RunMode = runMode,
            ExpectedLogPath = metadata.LogPath,
            LastResult = lastResult
        }, new JsonSerializerOptions { WriteIndented = true }));

        if (!string.IsNullOrWhiteSpace(toolLogText))
        {
            AddText(zip, usedNames, "01_tool_log_panel.txt", toolLogText);
        }

        if (lastResult is not null)
        {
            AddFile(zip, usedNames, lastResult.WrapperPath, "runner");
            AddFile(zip, usedNames, lastResult.StdOutPath, "runner");
            AddFile(zip, usedNames, lastResult.StdErrPath, "runner");
            AddFile(zip, usedNames, lastResult.ExitCodePath, "runner");
        }

        if (!string.IsNullOrWhiteSpace(metadata.MetadataFolder) && Directory.Exists(metadata.MetadataFolder))
        {
            foreach (var file in Directory.EnumerateFiles(metadata.MetadataFolder, "*", SearchOption.TopDirectoryOnly))
            {
                AddFile(zip, usedNames, file, "metadata");
            }
        }

        AddFile(zip, usedNames, metadata.LogPath, "expected installer log");

        var scriptFolder = !string.IsNullOrWhiteSpace(workFolder) ? Path.Combine(workFolder, "Scripts") : string.Empty;
        if (!string.IsNullOrWhiteSpace(scriptFolder) && Directory.Exists(scriptFolder))
        {
            foreach (var file in Directory.EnumerateFiles(scriptFolder, "*", SearchOption.AllDirectories))
            {
                AddFile(zip, usedNames, file, "downloaded script content");
            }
        }

        if (!string.IsNullOrWhiteSpace(metadata.ExtractedFolder) && Directory.Exists(metadata.ExtractedFolder))
        {
            foreach (var file in Directory.EnumerateFiles(metadata.ExtractedFolder, "*.log", SearchOption.AllDirectories))
            {
                AddFile(zip, usedNames, file, "extracted logs");
            }
        }

        AddText(zip, usedNames, "99_export_notes.txt",
            "This export contains the IntuneWin Downloader log panel, metadata, runner files, expected installer log if available, and logs found inside the extracted package. IME service logs are not copied from ProgramData because those files are commonly locked by the running IME service and were not the logs shown in the UI.\r\n");

        return zipPath;
    }


    public static string ExportShownLogs(string outputFolder, string? toolLogText)
    {
        var baseFolder = string.IsNullOrWhiteSpace(outputFolder) ? Path.GetTempPath() : outputFolder.Trim();
        Directory.CreateDirectory(baseFolder);

        var exportFolder = Path.Combine(baseFolder, "ToolLogs");
        Directory.CreateDirectory(exportFolder);

        var logText = string.IsNullOrWhiteSpace(toolLogText)
            ? "The shown log panel was empty when the export was created." + Environment.NewLine
            : toolLogText;

        var latestTextPath = Path.Combine(exportFolder, "IntuneWinDownloader_LatestToolLog.txt");
        File.WriteAllText(latestTextPath, logText, Encoding.UTF8);

        var zipPath = Path.Combine(exportFolder, "IntuneWinDownloader_ToolLog_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".zip");

        var usedNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using var zip = ZipFile.Open(zipPath, ZipArchiveMode.Create);

        AddText(zip, usedNames, "00_export_info.json", JsonSerializer.Serialize(new
        {
            ExportedAt = DateTimeOffset.Now.ToString("o"),
            ExportType = "ShownLogPanel",
            Source = "MainWindow log panel",
            PlainTextCopy = latestTextPath
        }, new JsonSerializerOptions { WriteIndented = true }));

        AddText(zip, usedNames, "01_tool_log_panel.txt", logText);

        AddText(zip, usedNames, "99_export_notes.txt",
            "This export contains only the log text currently shown in the IntuneWin Downloader UI. It does not require an app download and it does not copy IME service logs from ProgramData." + Environment.NewLine);

        return zipPath;
    }


    private static void AddText(ZipArchive zip, HashSet<string> usedNames, string entryName, string content)
    {
        var safeEntryName = GetUniqueEntryName(usedNames, entryName.Replace('\\', '/'));
        var entry = zip.CreateEntry(safeEntryName, CompressionLevel.Optimal);
        using var writer = new StreamWriter(entry.Open(), Encoding.UTF8);
        writer.Write(content);
    }

    private static void AddFile(ZipArchive zip, HashSet<string> usedNames, string? path, string group)
    {
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return;

        try
        {
            var info = new FileInfo(path);
            if (info.Length > 50L * 1024 * 1024)
            {
                AddText(zip, usedNames, Path.Combine(group, Path.GetFileName(path) + ".skipped.txt"), "Skipped because the file is larger than 50 MB: " + path);
                return;
            }

            var entryName = GetUniqueEntryName(usedNames, Path.Combine(group, Path.GetFileName(path)).Replace('\\', '/'));
            var entry = zip.CreateEntry(entryName, CompressionLevel.Optimal);
            using var input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
            using var output = entry.Open();
            input.CopyTo(output);
        }
        catch (Exception ex)
        {
            AddText(zip, usedNames, Path.Combine(group, Path.GetFileName(path) + ".skipped.txt"),
                "Could not copy this file during log export.\r\nPath: " + path + "\r\nError: " + ex.Message);
        }
    }

    private static string GetUniqueEntryName(HashSet<string> usedNames, string entryName)
    {
        if (usedNames.Add(entryName)) return entryName;
        var folder = Path.GetDirectoryName(entryName)?.Replace('\\', '/') ?? string.Empty;
        var file = Path.GetFileNameWithoutExtension(entryName);
        var extension = Path.GetExtension(entryName);
        for (var i = 2; ; i++)
        {
            var candidateFile = file + "_" + i + extension;
            var candidate = string.IsNullOrWhiteSpace(folder) ? candidateFile : folder + "/" + candidateFile;
            if (usedNames.Add(candidate)) return candidate;
        }
    }

    private static string MakeSafeFileName(string value)
    {
        foreach (var invalid in Path.GetInvalidFileNameChars()) value = value.Replace(invalid, '_');
        return string.IsNullOrWhiteSpace(value) ? "install" : value;
    }
}
