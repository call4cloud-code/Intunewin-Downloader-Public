using System.Globalization;
using System.IO.Compression;
using System.Net;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Xml;
using IntuneWinDownloader.WinUI.Models;
using Microsoft.Win32;
using Windows.Security.Authentication.Web.Core;
using Windows.Security.Credentials;

namespace IntuneWinDownloader.WinUI.Services;

public sealed class NativeIntuneBackendService
{
    public event Action<int, string>? ProgressChanged;

    private const string SideCarClientId = "fc0f3af4-6835-4174-b806-f7db311fd2f3";
    private const string SideCarResource = "26a4ae64-5862-427f-a9b0-044e62572a4f";
    private const string CompanyPortalClientId = "9ba1a5c7-f17a-4de9-a1f1-6178c8d51223";
    private const string IwServiceResource = "b8066b99-6e67-41be-abfa-75db1a2c8809";
    private const string WamProviderUrl = "https://login.microsoft.com";

    private readonly StringBuilder _log = new();
    private readonly Dictionary<string, CatalogCacheItem> _catalogCache = new(StringComparer.OrdinalIgnoreCase);
    private DownloadContext? _context;
    private WebAccount? _cachedWebAccount;

    private sealed record SideCarPolicyPayloadResult(
        string? RawResponse,
        string? DecodedPayload,
        string Status,
        string Error,
        string SourceName,
        string MatchReason,
        JsonElement? SelectedPolicy);

    private sealed record SideCarPolicyRequest(string RequestContentType, string ScenarioType);

    public NativeIntuneBackendService CreateParallelDownloadChild()
    {
        return new NativeIntuneBackendService
        {
            _context = _context,
            _cachedWebAccount = _cachedWebAccount
        };
    }

    public async Task<(string Log, Dictionary<string, object?> Context)> InitializeAsync()
    {
        ResetLog();
        var ctx = await EnsureContextAsync();
        var result = new Dictionary<string, object?>
        {
            ["Endpoint"] = ctx.Endpoint,
            ["AccountId"] = ctx.AccountId,
            ["DeviceId"] = ctx.DeviceId,
            ["HasCertificate"] = ctx.Certificate is not null,
            ["CertificateSubject"] = ctx.Certificate?.Subject ?? string.Empty
        };
        return (FlushLog(), result);
    }

    public async Task<(string Log, List<AppRow> Apps)> LoadAppsAsync()
    {
        ResetLog();
        var ctx = await EnsureContextAsync();
        var token = await GetWamTokenAsync(CompanyPortalClientId, IwServiceResource, "AcquireIWServiceToken");
        var baseUrl = GetIwServiceBaseUrlFromSideCarEndpoint(ctx.Endpoint);
        Log($"IWService base URL: {baseUrl}");
        var url = BuildIwServiceCatalogUrl(baseUrl, ctx.DeviceId, 1000);
        Log($"Sending GET to IWService: {url}");

        using var client = new HttpClient { Timeout = TimeSpan.FromMinutes(2) };
        using var req = new HttpRequestMessage(HttpMethod.Get, url);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        req.Headers.TryAddWithoutValidation("client-request-id", Guid.NewGuid().ToString());
        req.Headers.UserAgent.ParseAdd("CompanyPortal/11.2 IntuneWinDownloader");
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        using var resp = await client.SendAsync(req);
        var body = await resp.Content.ReadAsStringAsync();
        if (!resp.IsSuccessStatusCode)
        {
            throw new InvalidOperationException($"IWService request failed: {(int)resp.StatusCode} {resp.ReasonPhrase}\r\n{body}");
        }

        using var doc = JsonDocument.Parse(body);
        var rows = await ConvertIwServiceCatalogToRowsAsync(doc.RootElement, token);
        _catalogCache.Clear();
        foreach (var row in rows)
        {
            if (!_catalogCache.ContainsKey(row.Id))
            {
                _catalogCache[row.Id] = new CatalogCacheItem(row, FindOriginalCatalogItem(doc.RootElement, row.Id));
            }
        }

        Log($"Loaded {rows.Count} app entries from the Company Portal IWService catalog.");
        Log("Company Portal IWService is used to load the app list and the local app id.");
        Log("Committed content version is resolved from the IME SideCar policy list. The policy field is named Version. GetContentInfo still expects that value in its ApplicationVersion request field.");
        return (FlushLog(), rows);
    }

    public async Task<ContentVersionResolveResult> ResolveContentVersionAsync(AppRow app, int maxVersion = 50)
    {
        if (app is null) throw new ArgumentNullException(nameof(app));
        if (string.IsNullOrWhiteSpace(app.Id))
        {
            return new ContentVersionResolveResult(string.Empty, false, "No AppId was available. No committed content version could be resolved.", string.Empty);
        }

        ResetLog();
        var ctx = await EnsureContextAsync();

        Log($"Resolving committed content version for {app.Name} [{app.Id}].");
        Log("First source: the decoded IME app policy list, the same data AppWorkload logs as Get policies. The policy field named Version is the committed content version.");

        var policyPayload = await TryRequestSideCarAppPolicyPayloadAsync(ctx, app.Id, app.Name);
        if (policyPayload.SelectedPolicy.HasValue)
        {
            var policy = policyPayload.SelectedPolicy.Value;
            var policyVersion = GetPolicyCommittedContentVersion(policy);
            var policyName = FirstNotEmpty(GetPolicyString(policy, "Name"), GetPolicyString(policy, "DisplayName"), app.Name);
            Log($"Matched app policy from {policyPayload.SourceName}: {policyName}. Match: {policyPayload.MatchReason}");

            if (!string.IsNullOrWhiteSpace(policyVersion))
            {
                Log($"Policy Version candidate found: {policyVersion}. Validating it with GetContentInfo for the Company Portal app id before using it.");
                var validationResponse = await SendGetContentInfoRequestAsync(ctx, app.Id, policyVersion, null, app.Name);
                if (ContentInfoResponseHasUsableContent(validationResponse, out var validationReason))
                {
                    Log($"Committed content version resolved from policy Version: {policyVersion}. {validationReason}");
                    return new ContentVersionResolveResult(policyVersion, true, $"Resolved from IME SideCar policy Version {policyVersion} and validated with GetContentInfo.", FlushLog());
                }

                Log($"Policy Version [{policyVersion}] was not accepted by GetContentInfo for the Company Portal app id. {validationReason}");
            }

            Log("The matching policy did not contain a usable Version field, or the policy Version was not accepted by GetContentInfo for this catalog app id.");
        }
        else
        {
            Log("No matching app policy was found in the decoded IME policy list. This can happen when Company Portal has loaded the catalog, but IME has not received an available-app request for that specific app yet.");
            if (!string.IsNullOrWhiteSpace(policyPayload.Error)) Log(policyPayload.Error);
        }

        Log("Fallback source: validate content versions with GetContentInfo, using the old working download path. This does not provide policy install commands, but it prevents the download from breaking when the app is not present in the current policy list.");
        var fallbackVersion = await TryResolveContentVersionByContentInfoProbeAsync(ctx, app.Id, app.Version, maxVersion);
        if (!string.IsNullOrWhiteSpace(fallbackVersion))
        {
            return new ContentVersionResolveResult(fallbackVersion, true, $"Policy Version was not available for this app in the current policy list. Content version {fallbackVersion} was validated by GetContentInfo.", FlushLog());
        }

        var log = FlushLog();
        return new ContentVersionResolveResult(string.Empty, false, "Could not resolve the committed content version from policy Version or from a validated GetContentInfo response.", log);
    }

    public Task<(string Log, DownloadResult Result)> DownloadAsync(AppRow app, string version, string outputRoot)
    {
        if (app is null) throw new ArgumentNullException(nameof(app));
        return DownloadAsync(app.Id, version, outputRoot, app.Name, null);
    }

    public Task<(string Log, DownloadResult Result)> DownloadAsync(string appId, string version, string outputRoot)
        => DownloadAsync(appId, version, outputRoot, null, null);

    private async Task<(string Log, DownloadResult Result)> DownloadAsync(string appId, string version, string outputRoot, string? displayNameOverride, JsonElement? rawItemOverride)
    {
        ResetLog();
        ReportProgress(0, "Starting download...");
        if (string.IsNullOrWhiteSpace(appId)) throw new ArgumentException("AppId is required.", nameof(appId));
        if (string.IsNullOrWhiteSpace(version)) version = "auto";
        if (string.IsNullOrWhiteSpace(outputRoot)) outputRoot = @"C:\Temp\IntuneWinDownloader";

        ReportProgress(5, "Resolving Intune device context...");
        var ctx = await EnsureContextAsync();
        var appName = !string.IsNullOrWhiteSpace(displayNameOverride)
            ? displayNameOverride
            : (_catalogCache.TryGetValue(appId, out var cache) ? cache.Row.Name : appId);
        var rawCatalogItem = rawItemOverride ?? (_catalogCache.TryGetValue(appId, out var cacheForRaw) ? cacheForRaw.RawItem : null);
        var safeName = MakeSafeFileName(appName);
        var workFolder = Path.Combine(outputRoot, safeName);
        var extractFolder = Path.Combine(workFolder, "Extracted");
        Directory.CreateDirectory(workFolder);
        Directory.CreateDirectory(extractFolder);

        var metadataFolderPreflight = Path.Combine(workFolder, "Metadata");
        Directory.CreateDirectory(metadataFolderPreflight);

        string? getPoliciesResponse = null;
        string? getPoliciesDecodedPayload = null;
        string getPoliciesStatus = "SideCar policy source was not attempted.";
        string getPoliciesError = string.Empty;
        JsonElement? selectedPolicy = null;

        ReportProgress(8, "Requesting SideCar app policy payload...");
        var policyPayload = await TryRequestSideCarAppPolicyPayloadAsync(ctx, appId, appName);
        getPoliciesResponse = policyPayload.RawResponse;
        getPoliciesDecodedPayload = policyPayload.DecodedPayload;
        getPoliciesStatus = policyPayload.Status;
        getPoliciesError = policyPayload.Error;
        selectedPolicy = policyPayload.SelectedPolicy;

        if (selectedPolicy.HasValue)
        {
            var policyVersion = GetPolicyCommittedContentVersion(selectedPolicy.Value);
            Log($"Selected matching app policy from {policyPayload.SourceName} for command extraction. This is the payload AppWorkload logs as Get policies.");
            if (!string.IsNullOrWhiteSpace(policyVersion))
            {
                var autoVersionRequested = string.IsNullOrWhiteSpace(version) || version.Equals("auto", StringComparison.OrdinalIgnoreCase);
                Log($"SideCar policy Version candidate for selected app: {policyVersion}.");
                if (autoVersionRequested || version.Equals(policyVersion, StringComparison.OrdinalIgnoreCase))
                {
                    var validationResponse = await SendGetContentInfoRequestAsync(ctx, appId, policyVersion, null, appName);
                    if (ContentInfoResponseHasUsableContent(validationResponse, out var validationReason))
                    {
                        version = policyVersion;
                        Log($"Using policy Version [{policyVersion}] because GetContentInfo accepted it for the Company Portal app id. {validationReason}");
                    }
                    else
                    {
                        Log($"Policy Version [{policyVersion}] was not accepted by GetContentInfo for the Company Portal app id. {validationReason}");
                    }
                }
                else
                {
                    Log($"Manual content version [{version}] differs from policy Version [{policyVersion}]. Keeping the manual value.");
                }
            }
            else
            {
                Log("The matching policy did not contain a usable Version field.");
            }
        }
        else
        {
            Log("No matching app policy was found in the decoded IME policy list. Policy install commands are not available for this app yet. Package metadata fallback will be used for the test install metadata after content is downloaded.");
        }

        if (string.IsNullOrWhiteSpace(version) || version.Equals("auto", StringComparison.OrdinalIgnoreCase))
        {
            Log("No policy Version is available for this app in the current IME policy list. Falling back to the old working GetContentInfo validation path so the content can still be downloaded.");
            var fallbackVersion = await TryResolveContentVersionByContentInfoProbeAsync(ctx, appId, _catalogCache.TryGetValue(appId, out var fallbackCache) ? fallbackCache.Row.Version : null, 50);
            if (!string.IsNullOrWhiteSpace(fallbackVersion))
            {
                version = fallbackVersion;
                Log($"Using content version [{version}] because GetContentInfo returned usable ContentInfo for that version. This is a validated fallback, not the policy command source.");
            }
        }

        if (string.IsNullOrWhiteSpace(version) || version.Equals("auto", StringComparison.OrdinalIgnoreCase))
        {
            SaveGetPoliciesMetadata(
                metadataFolderPreflight,
                appId,
                getPoliciesResponse,
                getPoliciesDecodedPayload,
                getPoliciesStatus,
                getPoliciesError,
                selectedPolicy,
                BuildPreContentPolicyCommandSummary(selectedPolicy, appId, appName, getPoliciesStatus, getPoliciesError));
            throw new InvalidOperationException("Could not resolve the content version from policy Version or from a validated GetContentInfo response.");
        }

        SaveGetPoliciesMetadata(
            metadataFolderPreflight,
            appId,
            getPoliciesResponse,
            getPoliciesDecodedPayload,
            getPoliciesStatus,
            getPoliciesError,
            selectedPolicy,
            BuildPreContentPolicyCommandSummary(selectedPolicy, appId, appName, getPoliciesStatus, getPoliciesError));

        ReportProgress(10, "Requesting SideCar ContentInfo...");
        Log($"Requesting ContentInfo for AppId [{appId}] using committed content version [{version}]. The SideCar request field is still named ApplicationVersion.");
        var contentResponse = await SendGetContentInfoRequestAsync(ctx, appId, version, selectedPolicy, appName);
        if (contentResponse is null)
        {
            throw new InvalidOperationException("No response from GetContentInfo. Confirm the app is assigned to this device or user and that the committed content version from policy Version is accepted by SideCar.");
        }

        var outer = JsonDocument.Parse(contentResponse).RootElement.Clone();
        if (!TryGetString(outer, "ResponsePayload", out var responsePayloadText))
        {
            throw new InvalidOperationException("GetContentInfo did not return a ResponsePayload.");
        }

        using var responsePayloadDoc = JsonDocument.Parse(responsePayloadText);
        var responsePayload = responsePayloadDoc.RootElement.Clone();
        if (!TryGetString(responsePayload, "ContentInfo", out var contentInfoText))
        {
            throw new InvalidOperationException("GetContentInfo did not return ContentInfo.");
        }

        using var contentInfoDoc = JsonDocument.Parse(contentInfoText);
        var contentInfo = contentInfoDoc.RootElement.Clone();
        var uploadLocation = GetStringRecursive(contentInfo, "UploadLocation");
        if (string.IsNullOrWhiteSpace(uploadLocation))
        {
            throw new InvalidOperationException("No UploadLocation found in ContentInfo.");
        }

        ReportProgress(18, "ContentInfo returned. Decrypting metadata...");
        Log("ContentInfo returned. DecryptInfo is available.");
        var decryptionInfo = DecryptDecryptInfo(responsePayload);
        var profileIdentifier = GetStringRecursive(decryptionInfo, "ProfileIdentifier") ?? string.Empty;
        Log(string.IsNullOrWhiteSpace(profileIdentifier)
            ? "DecryptInfo ProfileIdentifier: <not returned>"
            : $"DecryptInfo ProfileIdentifier: {profileIdentifier}");

        var binPath = Path.Combine(workFolder, safeName + ".intunewin.bin");
        var zipPath = Path.Combine(workFolder, safeName + ".decoded.zip");
        await DownloadFileAsync(uploadLocation, binPath, 20, 70);

        ReportProgress(75, "Preparing decoded package...");
        if (profileIdentifier.Equals("NoEncryption", StringComparison.OrdinalIgnoreCase))
        {
            Log("ProfileIdentifier is NoEncryption. Treating downloaded content as decoded zip.");
            File.Copy(binPath, zipPath, overwrite: true);
        }
        else
        {
            var key = GetStringRecursive(decryptionInfo, "EncryptionKey", "ContentEncryptionKey", "FileEncryptionKey", "AesKey", "AESKey", "Key", "Base64Key");
            var iv = GetStringRecursive(decryptionInfo, "IV", "InitializationVector", "InitVector", "AesIV", "AESIV", "FileIV", "Base64IV");
            if (string.IsNullOrWhiteSpace(key) || string.IsNullOrWhiteSpace(iv))
            {
                throw new InvalidOperationException("DecryptInfo was decrypted, but the AES key or IV could not be resolved.");
            }
            Log("DecryptInfo key and IV resolved using the original EncryptionKey and IV fields.");
            ReportProgress(80, "Decrypting IntuneWin package...");
            DecryptIntuneWinBin(binPath, zipPath, key, iv);
        }

        ReportProgress(88, "Extracting package...");
        if (Directory.Exists(extractFolder)) Directory.Delete(extractFolder, recursive: true);
        Directory.CreateDirectory(extractFolder);
        ZipFile.ExtractToDirectory(zipPath, extractFolder, overwriteFiles: true);
        Log($"Extracted content folder: {extractFolder}");

        ReportProgress(94, "Reading package metadata...");
        var packageMetadata = PackageMetadataReader.Read(extractFolder);
        var downloadedScripts = selectedPolicy.HasValue
            ? await TryDownloadPolicyScriptsAsync(ctx, selectedPolicy.Value, version, workFolder, extractFolder)
            : new Dictionary<string, PolicyScriptDownloadInfo>(StringComparer.OrdinalIgnoreCase);
        var policyCommands = selectedPolicy.HasValue
            ? BuildPolicyCommandSummary(selectedPolicy.Value, appId, appName, extractFolder, packageMetadata, downloadedScripts)
            : BuildPackageFallbackPolicyCommandSummary(appId, appName, extractFolder, packageMetadata, getPoliciesStatus, getPoliciesError);
        var metadataFolder = ExportMetadata(workFolder, appId, version, appName, rawCatalogItem, outer, responsePayload, contentInfo, decryptionInfo, packageMetadata, binPath, zipPath, extractFolder, profileIdentifier, getPoliciesResponse, getPoliciesDecodedPayload, getPoliciesStatus, getPoliciesError, selectedPolicy, policyCommands);
        Log($"Metadata exported: {metadataFolder}");
        Log($"Done. Output: {workFolder}");
        Log($"Extracted output: {extractFolder}");
        ReportProgress(100, "Download, decrypt, extract and metadata export complete.");

        var result = new DownloadResult
        {
            AppId = appId,
            ApplicationId = appId,
            ApplicationVersion = version,
            CommittedContentVersion = version,
            AppName = appName,
            WorkFolder = workFolder,
            BinFile = binPath,
            DecodedZip = zipPath,
            ExtractedFolder = extractFolder,
            MetadataFolder = metadataFolder,
            ProfileIdentifier = profileIdentifier
        };

        return (FlushLog(), result);
    }

    private async Task<DownloadContext> EnsureContextAsync()
    {
        if (_context is not null) return _context;

        Log("Searching for Intune MDM device certificate...");
        var mdm = MdmCertificateInfo.Find();
        Log($"Using Intune MDM certificate from: {mdm.StorePath}");
        if (!mdm.Certificate.HasPrivateKey)
        {
            Log("WARNING: The Intune MDM certificate was found, but it does not expose a private key in this context. The SideCar mTLS request can fail.");
        }
        Log($"DeviceId: {mdm.DeviceId}");
        Log($"AccountId: {mdm.AccountId}");

        var urls = GetIntuneLocationServiceUrls();
        var endpoint = await QueryLocationServiceAsync(urls, mdm.Certificate);
        if (string.IsNullOrWhiteSpace(endpoint))
        {
            throw new InvalidOperationException("No valid SideCarGatewayService URL could be discovered.");
        }
        Log($"Endpoint: {endpoint}");

        Log($"Requesting SideCar token with WAM. ClientId: {SideCarClientId} Resource: {SideCarResource}");
        var token = await GetWamTokenAsync(SideCarClientId, SideCarResource, "AcquireSideCarToken");
        Log("SideCar WAM token acquired.");

        _context = new DownloadContext(endpoint, mdm.AccountId.ToString(), mdm.DeviceId.ToString(), token, mdm.Certificate, mdm.CertificateBlob);
        return _context;
    }

    private async Task<string> GetWamTokenAsync(string clientId, string resource, string phase)
    {
        var provider = await GetWamProviderAsync();
        var requestCandidates = BuildWamTokenRequests(provider, clientId, resource);
        var errors = new List<string>();

        foreach (var candidate in requestCandidates)
        {
            Log($"WAM token attempt during {phase}: {candidate.Description}");

            var silentResult = await TryGetWamTokenSilentlyAsync(candidate.Request, phase, candidate.Description, errors);
            if (TryExtractWamToken(silentResult, phase, out var silentToken))
            {
                Log($"WAM silent token acquired during {phase} using: {candidate.Description}");
                return silentToken;
            }

            var interactiveResult = await TryGetWamTokenInteractivelyAsync(candidate.Request, phase, candidate.Description, errors);
            if (TryExtractWamToken(interactiveResult, phase, out var interactiveToken))
            {
                Log($"WAM interactive token acquired during {phase} using: {candidate.Description}");
                return interactiveToken;
            }
        }

        throw new InvalidOperationException($"WAM token request failed during {phase}. Attempts: " + string.Join(" | ", errors));
    }

    private async Task<WebAccountProvider> GetWamProviderAsync()
    {
        var authorities = new[]
        {
            "https://login.microsoftonline.com/common",
            "organizations",
            "common",
            string.Empty
        };

        foreach (var authority in authorities)
        {
            try
            {
                var provider = string.IsNullOrWhiteSpace(authority)
                    ? await WebAuthenticationCoreManager.FindAccountProviderAsync(WamProviderUrl)
                    : await WebAuthenticationCoreManager.FindAccountProviderAsync(WamProviderUrl, authority);

                if (provider is not null)
                {
                    Log(string.IsNullOrWhiteSpace(authority)
                        ? $"WAM provider found without explicit authority: {provider.DisplayName}"
                        : $"WAM provider found with authority [{authority}]: {provider.DisplayName}");
                    return provider;
                }
            }
            catch (Exception ex)
            {
                Log($"WAM provider lookup failed for authority [{authority}]: {ex.Message}");
            }
        }

        throw new InvalidOperationException("WAM provider not found. Is this device Entra joined or signed in with a work account?");
    }

    private static List<WamTokenRequestCandidate> BuildWamTokenRequests(WebAccountProvider provider, string clientId, string resource)
    {
        var candidates = new List<WamTokenRequestCandidate>();

        try
        {
            var request = new WebTokenRequest(provider, string.Empty, clientId);
            TrySetWamResourceProperty(request, resource);
            candidates.Add(new WamTokenRequestCandidate(request, "empty scope with resource property"));
        }
        catch
        {
            // Fall through to the resource-as-scope variant.
        }

        try
        {
            candidates.Add(new WamTokenRequestCandidate(new WebTokenRequest(provider, resource, clientId), "resource as scope"));
        }
        catch
        {
            // Fall through. The caller reports the collected WAM failures.
        }

        if (candidates.Count == 0)
        {
            throw new InvalidOperationException("Could not create a WebTokenRequest for WAM.");
        }

        return candidates;
    }

    private static void TrySetWamResourceProperty(WebTokenRequest request, string resource)
    {
        try
        {
            request.Properties["resource"] = resource;
        }
        catch
        {
            // Some projections do not expose a writable property bag. The caller also tries resource-as-scope.
        }
    }

    private async Task<WebTokenRequestResult?> TryGetWamTokenSilentlyAsync(WebTokenRequest request, string phase, string description, List<string> errors)
    {
        try
        {
            var result = _cachedWebAccount is not null
                ? await WebAuthenticationCoreManager.GetTokenSilentlyAsync(request, _cachedWebAccount)
                : await WebAuthenticationCoreManager.GetTokenSilentlyAsync(request);

            if (result.ResponseStatus != WebTokenRequestStatus.Success)
            {
                errors.Add($"silent {description}: {DescribeWamResult(result)}");
                return result;
            }

            return result;
        }
        catch (Exception ex)
        {
            errors.Add($"silent {description}: {ex.Message}");
            Log($"WAM silent token request failed during {phase} using {description}: {ex.Message}");
            return null;
        }
    }

    private async Task<WebTokenRequestResult?> TryGetWamTokenInteractivelyAsync(WebTokenRequest request, string phase, string description, List<string> errors)
    {
        try
        {
            var result = _cachedWebAccount is not null
                ? await WebAuthenticationCoreManager.RequestTokenAsync(request, _cachedWebAccount)
                : await WebAuthenticationCoreManager.RequestTokenAsync(request);

            if (result.ResponseStatus != WebTokenRequestStatus.Success)
            {
                errors.Add($"interactive {description}: {DescribeWamResult(result)}");
                return result;
            }

            return result;
        }
        catch (Exception ex)
        {
            errors.Add($"interactive {description}: {ex.Message}");
            Log($"WAM interactive token request failed during {phase} using {description}: {ex.Message}");
            return null;
        }
    }

    private bool TryExtractWamToken(WebTokenRequestResult? result, string phase, out string token)
    {
        token = string.Empty;
        if (result is null || result.ResponseStatus != WebTokenRequestStatus.Success || result.ResponseData is null || result.ResponseData.Count == 0)
        {
            return false;
        }

        var response = result.ResponseData[0];
        if (response.WebAccount is not null)
        {
            _cachedWebAccount = response.WebAccount;
        }

        if (string.IsNullOrWhiteSpace(response.Token))
        {
            Log($"WAM returned success but no token during {phase}.");
            return false;
        }

        token = response.Token;
        return true;
    }

    private static string DescribeWamResult(WebTokenRequestResult? result)
    {
        if (result is null)
        {
            return "no result";
        }

        var code = result.ResponseError is not null ? result.ResponseError.ErrorCode.ToString() : string.Empty;
        var message = result.ResponseError?.ErrorMessage ?? string.Empty;
        return $"{result.ResponseStatus} {code} {message}".Trim();
    }

    private static List<string> GetIntuneLocationServiceUrls()
    {
        var urls = new List<string>();
        using var accounts = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Provisioning\OMADM\Accounts");
        if (accounts is not null)
        {
            foreach (var name in accounts.GetSubKeyNames())
            {
                using var addr = accounts.OpenSubKey($@"{name}\Protected\AddrInfo");
                var raw = addr?.GetValue("Addr") as string;
                if (string.IsNullOrWhiteSpace(raw) || raw.Contains("checkin.dm.microsoft.com", StringComparison.OrdinalIgnoreCase)) continue;
                if (Uri.TryCreate(raw, UriKind.Absolute, out var uri))
                {
                    var fqdn = $"{uri.Scheme}://{uri.Host}";
                    if (!urls.Contains(fqdn, StringComparer.OrdinalIgnoreCase)) urls.Add(fqdn);
                }
            }
        }
        return urls.Count == 0 ? new List<string> { "https://manage.microsoft.com" } : urls;
    }

    private async Task<string> QueryLocationServiceAsync(IEnumerable<string> locationServiceUrls, X509Certificate2 cert)
    {
        foreach (var fqdn in locationServiceUrls)
        {
            var url = fqdn.TrimEnd('/') + "/RestUserAuthLocationService/RestUserAuthLocationService/Certificate/ServiceAddresses";
            Log($"Querying discovery endpoint: {url}");
            try
            {
                using var handler = new HttpClientHandler();
                handler.ClientCertificates.Add(cert);
                using var client = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(30) };
                using var req = new HttpRequestMessage(HttpMethod.Get, url);
                req.Headers.TryAddWithoutValidation("client-request-id", Guid.NewGuid().ToString());
                using var resp = await client.SendAsync(req);
                var json = await resp.Content.ReadAsStringAsync();
                if (!resp.IsSuccessStatusCode)
                {
                    Log($"Discovery request failed for {fqdn}: {(int)resp.StatusCode} {resp.ReasonPhrase}");
                    continue;
                }
                using var doc = JsonDocument.Parse(json);
                foreach (var entry in EnumerateArrayOrSingle(doc.RootElement))
                {
                    if (entry.TryGetProperty("IsPrimary", out var primary) && primary.ValueKind == JsonValueKind.True && entry.TryGetProperty("Services", out var services))
                    {
                        foreach (var service in EnumerateArrayOrSingle(services))
                        {
                            if (GetString(service, "ServiceName").Equals("SideCarGatewayService", StringComparison.OrdinalIgnoreCase))
                            {
                                var endpoint = GetString(service, "Url").Trim();
                                if (!string.IsNullOrWhiteSpace(endpoint))
                                {
                                    Log($"Found SideCarGatewayService URL: {endpoint}");
                                    return endpoint;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log($"Discovery request failed for {fqdn}: {ex.Message}");
            }
        }
        return string.Empty;
    }

    private static string BuildSideCarClientInfoJson(string imeVersion)
    {
        var osVersion = Environment.OSVersion.Version;
        var extendedInventory = new Dictionary<string, string?>
        {
            ["OperatingSystemRevisionNumber"] = osVersion.Revision >= 0 ? osVersion.Revision.ToString() : string.Empty,
            ["SKU"] = TryGetWindowsSkuValue(),
            ["DotNetFrameworkReleaseValue"] = TryGetDotNetReleaseValue()
        };

        var clientInfo = new Dictionary<string, object?>
        {
            ["DeviceName"] = Environment.MachineName,
            ["OperatingSystemVersion"] = $"{osVersion.Major}.{osVersion.Minor}.{osVersion.Build}",
            ["SideCarAgentVersion"] = imeVersion,
            ["Win10SMode"] = false,
            ["UnlockWin10SModeTenantId"] = null,
            ["UnlockWin10SModeDeviceId"] = null,
            ["ChannelUriInformation"] = null,
            ["AgentExecutionHistory"] = new Dictionary<string, object?>
            {
                ["LastAgentExecutionStartTime"] = null,
                ["LastAgentExecutionEndTime"] = null,
                ["AgentCrashCount"] = null
            },
            ["AgentExecutionStartTime"] = null,
            ["AgentExecutionEndTime"] = null,
            ["AgentCrashSeen"] = false,
            ["ExtendedInventoryMap"] = extendedInventory
        };

        return JsonSerializer.Serialize(clientInfo);
    }

    private static string TryGetWindowsSkuValue()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            return FirstNotEmpty(key?.GetValue("CompositionEditionID")?.ToString() ?? string.Empty,
                key?.GetValue("EditionID")?.ToString() ?? string.Empty,
                key?.GetValue("InstallationType")?.ToString() ?? string.Empty);
        }
        catch
        {
            return string.Empty;
        }
    }

    private static string TryGetDotNetReleaseValue()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full");
            return key?.GetValue("Release")?.ToString() ?? string.Empty;
        }
        catch
        {
            return string.Empty;
        }
    }

    private async Task<string> SendSideCarWorkloadRequestAsync(DownloadContext ctx, string requestContentType, string scenarioType)
    {
        var imeVersion = GetIntuneManagementExtensionVersion() ?? "1.91.102.0";
        var sessionId = Guid.NewGuid().ToString();
        var url = $"{ctx.Endpoint.TrimEnd('/')}/SideCarGatewaySessions('{sessionId}')?api-version=1.5";
        Log($"Sending PUT to {url} ({requestContentType})");

        var body = JsonSerializer.Serialize(new Dictionary<string, object?>
        {
            ["Key"] = sessionId,
            ["SessionId"] = sessionId,
            ["RequestContentType"] = requestContentType,
            ["RequestPayload"] = "[]",
            ["ResponseContentType"] = null,
            ["ClientInfo"] = BuildSideCarClientInfoJson(imeVersion),
            ["ResponsePayload"] = null,
            ["EnabledFlights"] = null,
            ["CheckinIntervalMinutes"] = null,
            ["GenericWorkloadRequests"] = null,
            ["GenericWorkloadResponse"] = null,
            ["CheckinReason"] = "OnDemand",
            ["CheckinReasonPayload"] = "{\"NotificationID\":\"00000000-0000-0000-0000-000000000000\",\"NotificationIntent\":\"\"}"
        });

        using var handler = new HttpClientHandler();
        handler.ClientCertificates.Add(ctx.Certificate);
        using var client = new HttpClient(handler) { Timeout = TimeSpan.FromMinutes(2) };
        using var req = new HttpRequestMessage(HttpMethod.Put, url);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", ctx.BearerToken);
        req.Headers.TryAddWithoutValidation("client-request-id", Guid.NewGuid().ToString());
        req.Headers.TryAddWithoutValidation("AccountId", ctx.AccountId);
        req.Headers.TryAddWithoutValidation("DeviceId", ctx.DeviceId);
        req.Headers.TryAddWithoutValidation("Prefer", "return-content");
        req.Headers.TryAddWithoutValidation("Request-Attempt-Count", "1");
        req.Headers.TryAddWithoutValidation("Scenario-Type", scenarioType);
        req.Content = new StringContent(body, Encoding.UTF8, "application/json");

        using var resp = await client.SendAsync(req);
        var respBody = await resp.Content.ReadAsStringAsync();
        if (!resp.IsSuccessStatusCode)
        {
            throw new InvalidOperationException($"{requestContentType} failed: {(int)resp.StatusCode} {resp.ReasonPhrase}\r\n{respBody}");
        }

        Log($"{requestContentType} completed with HTTP {(int)resp.StatusCode}.");
        return respBody;
    }

    private async Task<SideCarPolicyPayloadResult> TryRequestSideCarAppPolicyPayloadAsync(DownloadContext ctx, string appId, string appName)
    {
        var attempts = new[]
        {
            // This mirrors the Company Portal available app flow from the IME logs.
            // The decoded response is what AppWorkload logs as "Get policies = [...]".
            new SideCarPolicyRequest("GetAvailableApp", "Windows-GetAvailableApp"),
            // RequestApplication is what Company Portal calls through IWService when the user clicks Install.
            // SideCar can also return the broader app policy list for this path.
            new SideCarPolicyRequest("RequestApplication", "Windows-RequestApplication"),
            // GetSelectedApp is mostly ESP selected app flow. Keep it last because normal available installs do not need it.
            new SideCarPolicyRequest("GetSelectedApp", "Windows-GetSelectedApp")
        };

        string? bestRawResponse = null;
        string? bestDecodedPayload = null;
        string bestStatus = "No IME SideCar policy list returned a decodable response.";
        var bestPolicyCount = -1;
        var errors = new StringBuilder();

        foreach (var attempt in attempts)
        {
            try
            {
                var rawResponse = await SendSideCarWorkloadRequestAsync(ctx, attempt.RequestContentType, attempt.ScenarioType);
                var policyCount = TryGetPolicyCountFromSideCarResponse(rawResponse, out var decodedPayload, out var status);

                if ((policyCount > bestPolicyCount) || (bestDecodedPayload is null && !string.IsNullOrWhiteSpace(decodedPayload)))
                {
                    bestRawResponse = rawResponse;
                    bestDecodedPayload = decodedPayload;
                    bestStatus = $"{attempt.RequestContentType}: {status}";
                    bestPolicyCount = policyCount;
                }

                Log(policyCount >= 0
                    ? $"{attempt.RequestContentType} returned {policyCount} app policy objects. Decode status: {status}"
                    : $"{attempt.RequestContentType} returned a payload, but the app policy count could not be determined. Decode status: {status}");

                var selectedPolicy = TryFindPolicyByAppIdOrName(decodedPayload, appId, appName, out var matchReason);
                if (selectedPolicy.HasValue)
                {
                    return new SideCarPolicyPayloadResult(
                        rawResponse,
                        decodedPayload,
                        $"Matched app policy in {attempt.RequestContentType}. {status}",
                        string.Empty,
                        attempt.RequestContentType,
                        matchReason,
                        selectedPolicy);
                }

                Log($"{attempt.RequestContentType} policy list did not contain a usable match for selected app [{appName}] [{appId}]. Trying the next IME app policy source.");
            }
            catch (Exception ex)
            {
                var line = attempt.RequestContentType + " failed: " + ex.Message;
                if (errors.Length > 0) errors.AppendLine();
                errors.Append(line);
                Log("WARNING: " + line);
            }
        }

        return new SideCarPolicyPayloadResult(
            bestRawResponse,
            bestDecodedPayload,
            bestStatus,
            errors.ToString(),
            string.Empty,
            string.Empty,
            null);
    }

    private static int TryGetPolicyCountFromSideCarResponse(string responseBody, out string decodedPayload, out string status)
    {
        decodedPayload = string.Empty;
        status = "SideCar policy response could not be parsed.";
        try
        {
            using var outerDoc = JsonDocument.Parse(responseBody);
            if (!TryGetString(outerDoc.RootElement, "ResponsePayload", out var payload) || string.IsNullOrWhiteSpace(payload))
            {
                status = "SideCar policy response did not contain ResponsePayload.";
                return -1;
            }

            decodedPayload = DecodeSideCarPayload(payload, out status);
            if (string.IsNullOrWhiteSpace(decodedPayload))
            {
                return -1;
            }

            using var payloadDoc = JsonDocument.Parse(decodedPayload);
            return CountPolicyObjects(payloadDoc.RootElement);
        }
        catch (Exception ex)
        {
            status = ex.Message;
            return -1;
        }
    }

    private static string DecodeSideCarPayload(string payload, out string status)
    {
        status = "Empty payload.";
        if (string.IsNullOrWhiteSpace(payload)) return string.Empty;

        var trimmed = payload.Trim();
        if (trimmed.StartsWith("{", StringComparison.Ordinal) || trimmed.StartsWith("[", StringComparison.Ordinal))
        {
            status = "ResponsePayload was plain JSON.";
            return trimmed;
        }

        try
        {
            var allBytes = Convert.FromBase64String(trimmed);
            if (allBytes.Length > 4)
            {
                try
                {
                    var originalLength = BitConverter.ToInt32(allBytes, 0);
                    using var compressed = new MemoryStream(allBytes, 4, allBytes.Length - 4);
                    using var gzip = new GZipStream(compressed, CompressionMode.Decompress);
                    using var output = new MemoryStream(Math.Max(originalLength, 0));
                    gzip.CopyTo(output);
                    status = "ResponsePayload was base64 with a 4 byte length prefix and gzip content.";
                    return Encoding.UTF8.GetString(output.ToArray()).Trim();
                }
                catch
                {
                    // Some SideCar responses are not length-prefixed gzip. Try the other common shapes below.
                }
            }

            try
            {
                using var compressed = new MemoryStream(allBytes);
                using var gzip = new GZipStream(compressed, CompressionMode.Decompress);
                using var output = new MemoryStream();
                gzip.CopyTo(output);
                status = "ResponsePayload was base64 gzip content.";
                return Encoding.UTF8.GetString(output.ToArray()).Trim();
            }
            catch
            {
                // Fall through to UTF8 text.
            }

            var text = Encoding.UTF8.GetString(allBytes).Trim('\uFEFF', ' ', '\r', '\n', '\t');
            status = string.IsNullOrWhiteSpace(text)
                ? "ResponsePayload decoded from base64, but the result was empty."
                : "ResponsePayload was base64 encoded text.";
            return text;
        }
        catch (Exception ex)
        {
            status = "ResponsePayload could not be decoded: " + ex.Message;
            return string.Empty;
        }
    }

    private static int CountPolicyObjects(JsonElement root)
    {
        if (root.ValueKind == JsonValueKind.Array) return root.GetArrayLength();
        if (root.ValueKind == JsonValueKind.String)
        {
            var text = root.GetString();
            if (!string.IsNullOrWhiteSpace(text))
            {
                try
                {
                    using var nested = JsonDocument.Parse(text);
                    return CountPolicyObjects(nested.RootElement);
                }
                catch
                {
                    return -1;
                }
            }
        }
        if (root.ValueKind != JsonValueKind.Object) return -1;

        foreach (var name in new[] { "Policies", "policies", "Policy", "policy", "Apps", "apps", "ApplicationPolicies", "applicationPolicies", "Win32LobAppPolicies" })
        {
            if (root.TryGetProperty(name, out var value))
            {
                if (value.ValueKind == JsonValueKind.Array) return value.GetArrayLength();
                if (value.ValueKind == JsonValueKind.String)
                {
                    var text = value.GetString();
                    if (!string.IsNullOrWhiteSpace(text))
                    {
                        try
                        {
                            using var nested = JsonDocument.Parse(text);
                            return CountPolicyObjects(nested.RootElement);
                        }
                        catch
                        {
                            return 1;
                        }
                    }
                }
            }
        }

        return 1;
    }

    private static List<int> BuildContentVersionCandidates(string? knownVersion, int maxVersion)
    {
        var candidates = new List<int>();
        if (int.TryParse(knownVersion, out var known) && known > 0)
        {
            candidates.Add(known);
        }

        var safeMax = Math.Clamp(maxVersion, 1, 200);
        for (var i = 1; i <= safeMax; i++)
        {
            if (!candidates.Contains(i))
            {
                candidates.Add(i);
            }
        }

        return candidates;
    }

    private static bool ContentInfoResponseHasUsableContent(string? responseBody, out string reason)
    {
        reason = "No response body.";
        if (string.IsNullOrWhiteSpace(responseBody)) return false;

        try
        {
            using var outerDoc = JsonDocument.Parse(responseBody);
            if (!TryGetString(outerDoc.RootElement, "ResponsePayload", out var responsePayloadText) || string.IsNullOrWhiteSpace(responsePayloadText))
            {
                reason = "ResponsePayload was missing.";
                return false;
            }

            using var responsePayloadDoc = JsonDocument.Parse(responsePayloadText);
            var responsePayload = responsePayloadDoc.RootElement;
            if (!TryGetString(responsePayload, "ContentInfo", out var contentInfoText) || string.IsNullOrWhiteSpace(contentInfoText))
            {
                reason = "ContentInfo was missing.";
                return false;
            }

            using var contentInfoDoc = JsonDocument.Parse(contentInfoText);
            var contentInfo = contentInfoDoc.RootElement;
            var uploadLocation = GetStringRecursive(contentInfo, "UploadLocation");
            if (string.IsNullOrWhiteSpace(uploadLocation))
            {
                reason = "ContentInfo returned but UploadLocation was empty.";
                return false;
            }

            reason = "UploadLocation was returned.";
            return true;
        }
        catch (Exception ex)
        {
            reason = ex.Message;
            return false;
        }
    }

    private async Task<string?> TryResolveContentVersionByContentInfoProbeAsync(DownloadContext ctx, string appId, string? knownVersion, int maxVersion)
    {
        var candidates = BuildContentVersionCandidates(knownVersion, maxVersion);

        Log($"Validating content version through GetContentInfo for AppId [{appId}]. Candidate order: {string.Join(", ", candidates)}");
        foreach (var candidate in candidates)
        {
            var versionText = candidate.ToString(CultureInfo.InvariantCulture);
            try
            {
                Log($"Probing GetContentInfo with ApplicationVersion [{versionText}]...");
                var response = await SendGetContentInfoRequestAsync(ctx, appId, versionText, null, null, quietFailure: true);
                if (ContentInfoResponseHasUsableContent(response, out var reason))
                {
                    var echoedVersion = TryGetCommittedContentVersionEchoFromGetContentInfoResponse(response);
                    var selectedVersion = string.IsNullOrWhiteSpace(echoedVersion) ? versionText : echoedVersion.Trim();

                    if (!selectedVersion.Equals(versionText, StringComparison.OrdinalIgnoreCase))
                    {
                        Log($"GetContentInfo accepted probe version [{versionText}] but echoed committed content version [{selectedVersion}]. {reason}");
                    }
                    else
                    {
                        Log($"GetContentInfo accepted content version [{selectedVersion}]. {reason}");
                    }

                    Log($"Validated content version selected: {selectedVersion}");
                    return selectedVersion;
                }

                Log($"Content version [{versionText}] was not accepted by GetContentInfo. {reason}");
            }
            catch (Exception ex)
            {
                Log($"GetContentInfo probe failed for version [{versionText}]: {ex.Message}");
            }
        }

        Log("No content version produced usable ContentInfo.");
        return null;
    }

    private async Task<string?> SendGetContentInfoRequestAsync(DownloadContext ctx, string appId, string version, JsonElement? policy = null, string? appName = null, bool quietFailure = false)
    {
        var imeVersion = GetIntuneManagementExtensionVersion() ?? "1.91.102.0";
        var sessionId = Guid.NewGuid().ToString();
        var url = $"{ctx.Endpoint.TrimEnd('/')}/SideCarGatewaySessions('{sessionId}')?api-version=1.5";
        Log($"Sending PUT to {url} (GetContentInfo) for AppId [{appId}]");

        var requestPayload = BuildGetContentInfoRequestPayload(ctx, appId, version, policy, appName);
        Log("GetContentInfo request payload uses the small SideCar shape that the earlier working download path used. ApplicationVersion is populated from policy Version when available, or from a validated GetContentInfo probe: " + RedactCertificateBlob(requestPayload));

        var body = JsonSerializer.Serialize(new Dictionary<string, object?>
        {
            ["Key"] = sessionId,
            ["SessionId"] = sessionId,
            ["RequestContentType"] = "GetContentInfo",
            ["RequestPayload"] = requestPayload,
            ["ResponseContentType"] = null,
            ["ClientInfo"] = BuildSideCarClientInfoJson(imeVersion),
            ["ResponsePayload"] = null,
            ["EnabledFlights"] = null,
            ["CheckinIntervalMinutes"] = null,
            ["GenericWorkloadRequests"] = null,
            ["GenericWorkloadResponse"] = null,
            ["CheckinReason"] = "OnDemand",
            ["CheckinReasonPayload"] = "{\"NotificationID\":\"00000000-0000-0000-0000-000000000000\",\"NotificationIntent\":\"\"}"
        });

        using var handler = new HttpClientHandler();
        handler.ClientCertificates.Add(ctx.Certificate);
        using var client = new HttpClient(handler) { Timeout = TimeSpan.FromMinutes(1) };
        using var req = new HttpRequestMessage(HttpMethod.Put, url);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", ctx.BearerToken);
        req.Headers.TryAddWithoutValidation("client-request-id", Guid.NewGuid().ToString());
        req.Headers.TryAddWithoutValidation("AccountId", ctx.AccountId);
        req.Headers.TryAddWithoutValidation("DeviceId", ctx.DeviceId);
        req.Headers.TryAddWithoutValidation("Prefer", "return-content");
        req.Headers.TryAddWithoutValidation("Request-Attempt-Count", "1");
        req.Headers.TryAddWithoutValidation("Scenario-Type", "Windows-GetContentInfo");
        req.Content = new StringContent(body, Encoding.UTF8, "application/json");

        using var resp = await client.SendAsync(req);
        var respBody = await resp.Content.ReadAsStringAsync();
        if (!resp.IsSuccessStatusCode)
        {
            if (quietFailure)
            {
                Log($"GetContentInfo probe rejected AppId [{appId}] version [{version}]: {(int)resp.StatusCode} {resp.ReasonPhrase}");
            }
            else
            {
                Log($"GetContentInfo failed: {(int)resp.StatusCode} {resp.ReasonPhrase}");
                if (!string.IsNullOrWhiteSpace(respBody)) Log($"RESPONSE BODY: {respBody}");
            }
            return null;
        }
        return respBody;
    }


    private static string RedactCertificateBlob(string json)
    {
        if (string.IsNullOrWhiteSpace(json)) return string.Empty;
        try
        {
            using var doc = JsonDocument.Parse(json);
            var copy = new Dictionary<string, object?>();
            foreach (var property in doc.RootElement.EnumerateObject())
            {
                if (property.NameEquals("CertificateBlob"))
                {
                    copy[property.Name] = property.Value.ValueKind == JsonValueKind.Null ? null : "<redacted>";
                    continue;
                }

                copy[property.Name] = property.Value.ValueKind switch
                {
                    JsonValueKind.String => property.Value.GetString(),
                    JsonValueKind.Number => property.Value.GetRawText(),
                    JsonValueKind.True => true,
                    JsonValueKind.False => false,
                    JsonValueKind.Null => null,
                    _ => property.Value.GetRawText()
                };
            }
            return JsonSerializer.Serialize(copy);
        }
        catch
        {
            return json;
        }
    }

    private static string BuildGetContentInfoRequestPayload(DownloadContext ctx, string appId, string version, JsonElement? policy, string? appName)
    {
        // Important distinction:
        // The IME policy list field is Version. That value is the committed content version.
        // The SideCar GetContentInfo wire contract still calls that same value ApplicationVersion.
        //
        // Keep this payload intentionally small. The original working tool used this shape, and the
        // IME response echoes the full internal content object back after the service accepts it.
        if (string.IsNullOrWhiteSpace(version) || version.Equals("auto", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("GetContentInfo cannot be called without a content version.");
        }

        var payload = new Dictionary<string, object?>
        {
            ["ContentInfo"] = null,
            ["Intent"] = GetPolicyInt(policy, 1, "Intent", "intent"),
            ["CertificateBlob"] = ctx.CertificateBlob,
            ["DecryptInfo"] = null,
            ["UploadLocation"] = null,
            ["ApplicationVersion"] = version.Trim(),
            ["ApplicationId"] = appId
        };

        return JsonSerializer.Serialize(payload);
    }


    private static string? GetPolicyNullableString(JsonElement? policy, params string[] names)
    {
        if (!policy.HasValue) return null;
        foreach (var name in names)
        {
            if (!policy.Value.TryGetProperty(name, out var value)) continue;
            if (value.ValueKind == JsonValueKind.Null || value.ValueKind == JsonValueKind.Undefined) return null;
            if (value.ValueKind == JsonValueKind.String)
            {
                var text = value.GetString();
                return string.IsNullOrWhiteSpace(text) ? null : text;
            }

            var raw = value.GetRawText();
            return string.IsNullOrWhiteSpace(raw) ? null : raw;
        }
        return null;
    }

    private static int GetEffectiveInstallContextForContentInfo(JsonElement? policy, int targetType)
    {
        var policyInstallContext = GetPolicyInt(policy, 0, "InstallContext", "installContext", "RegisteredInstallContext", "registeredInstallContext");

        // In the captured available app flow, the policy object showed InstallContext 1, while the IME ContentInfo request used InstallContext "2".
        // For user targeted available apps, this effective context is what SideCar expects during ContentInfo lookup.
        if (targetType == 1 && policyInstallContext == 1)
        {
            return 2;
        }

        return policyInstallContext == 0 ? 2 : policyInstallContext;
    }

    private static string GetPolicyStringOrDefault(JsonElement? policy, string fallback, params string[] names)
    {
        var value = GetPolicyStringNullable(policy, names);
        return string.IsNullOrWhiteSpace(value) ? fallback : value.Trim();
    }

    private static string NormalizeAssignmentFilterIds(string? value)
    {
        return string.IsNullOrWhiteSpace(value) || value.Equals("null", StringComparison.OrdinalIgnoreCase)
            ? "[]"
            : value.Trim();
    }

    private static string NormalizeSupplementalString(string? value)
    {
        return string.IsNullOrWhiteSpace(value) || value.Equals("null", StringComparison.OrdinalIgnoreCase)
            ? string.Empty
            : value.Trim();
    }

    private static string? TryGetCommittedContentVersionEchoFromGetContentInfoResponse(string? responseBody)
    {
        if (string.IsNullOrWhiteSpace(responseBody)) return null;
        try
        {
            using var outerDoc = JsonDocument.Parse(responseBody);
            if (!TryGetString(outerDoc.RootElement, "ResponsePayload", out var responsePayloadText) || string.IsNullOrWhiteSpace(responsePayloadText)) return null;
            using var responsePayloadDoc = JsonDocument.Parse(responsePayloadText);
            return FirstNotEmpty(GetString(responsePayloadDoc.RootElement, "ApplicationVersion"), GetString(responsePayloadDoc.RootElement, "applicationVersion"));
        }
        catch
        {
            return null;
        }
    }

    private static string GetPolicyCommittedContentVersion(JsonElement policy)
        => FirstNotEmpty(
            // In the IME app policy payload this field is named Version.
            // It is the committed content version used later in GetContentInfo.
            GetPolicyString(policy, "Version"),
            GetPolicyString(policy, "version"),
            GetPolicyString(policy, "CommittedContentVersion"),
            GetPolicyString(policy, "committedContentVersion"),
            GetPolicyString(policy, "ContentVersion"),
            GetPolicyString(policy, "contentVersion"));

    private static int GetPolicyInt(JsonElement? policy, int fallback, params string[] names)
    {
        if (!policy.HasValue) return fallback;
        foreach (var name in names)
        {
            if (!policy.Value.TryGetProperty(name, out var value)) continue;
            if (value.ValueKind == JsonValueKind.Number && value.TryGetInt32(out var number)) return number;
            if (value.ValueKind == JsonValueKind.String && int.TryParse(value.GetString(), out var parsed)) return parsed;
        }
        return fallback;
    }

    private static string? GetPolicyStringNullable(JsonElement? policy, params string[] names)
    {
        if (!policy.HasValue) return null;
        foreach (var name in names)
        {
            var value = GetPolicyString(policy.Value, name);
            if (!string.IsNullOrWhiteSpace(value)) return value;
        }
        return null;
    }

    private JsonElement DecryptDecryptInfo(JsonElement responsePayload)
    {
        var decryptInfoXml = GetString(responsePayload, "DecryptInfo");
        if (string.IsNullOrWhiteSpace(decryptInfoXml))
        {
            throw new InvalidOperationException("No DecryptInfo in response.");
        }
        var xml = new XmlDocument();
        xml.LoadXml(decryptInfoXml);
        var encryptedContent = xml.SelectSingleNode("//*[local-name()='EncryptedContent']")?.InnerText;
        if (string.IsNullOrWhiteSpace(encryptedContent))
        {
            throw new InvalidOperationException("No EncryptedContent found in DecryptInfo XML.");
        }
        var cms = new EnvelopedCms();
        cms.Decode(Convert.FromBase64String(encryptedContent));
        cms.Decrypt();
        var json = Encoding.UTF8.GetString(cms.ContentInfo.Content);
        using var doc = JsonDocument.Parse(json);
        return doc.RootElement.Clone();
    }

    private async Task DownloadFileAsync(string url, string outputPath, int progressStart, int progressEnd)
    {
        Log($"Found UploadLocation. Downloading to: {outputPath}");
        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        var tempPath = outputPath + "." + Guid.NewGuid().ToString("N") + ".download";
        using var client = new HttpClient { Timeout = TimeSpan.FromMinutes(30) };
        using var resp = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
        resp.EnsureSuccessStatusCode();
        var total = resp.Content.Headers.ContentLength;
        if (total.HasValue) Log($"Download size: {FormatByteSize(total.Value)}"); else Log("Download size: unknown");
        ReportProgress(progressStart, total.HasValue ? $"Downloading package: 0% of {FormatByteSize(total.Value)}" : "Downloading package...");

        {
            await using var input = await resp.Content.ReadAsStreamAsync();
            await using var output = new FileStream(tempPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1024 * 1024, useAsync: true);
            var buffer = new byte[1024 * 1024];
            long readTotal = 0;
            int read;
            var lastLog = DateTime.UtcNow.AddSeconds(-10);
            var lastPercent = -1;
            while ((read = await input.ReadAsync(buffer)) > 0)
            {
                await output.WriteAsync(buffer.AsMemory(0, read));
                readTotal += read;
                if (total.HasValue && total.Value > 0)
                {
                    var rawPercent = (int)Math.Min(100, readTotal * 100 / total.Value);
                    var mappedPercent = progressStart + ((progressEnd - progressStart) * rawPercent / 100);
                    if (rawPercent != lastPercent)
                    {
                        ReportProgress(mappedPercent, $"Downloading package: {rawPercent}% ({FormatByteSize(readTotal)} / {FormatByteSize(total.Value)})");
                        lastPercent = rawPercent;
                    }
                    if (DateTime.UtcNow - lastLog > TimeSpan.FromSeconds(5))
                    {
                        Log($"Download progress: {rawPercent}% ({FormatByteSize(readTotal)} / {FormatByteSize(total.Value)})");
                        lastLog = DateTime.UtcNow;
                    }
                }
                else if (DateTime.UtcNow - lastLog > TimeSpan.FromSeconds(2))
                {
                    ReportProgress(progressStart, $"Downloading package: {FormatByteSize(readTotal)} downloaded");
                    Log($"Download progress: {FormatByteSize(readTotal)} downloaded");
                    lastLog = DateTime.UtcNow;
                }
            }
        }

        ReplaceFileWithRetry(tempPath, outputPath);
        ReportProgress(progressEnd, "Download complete.");
        Log("Download complete.");
    }

    private static void DecryptIntuneWinBin(string inputPath, string outputZip, string base64Key, string base64Iv)
    {
        var key = Convert.FromBase64String(base64Key);
        var iv = Convert.FromBase64String(base64Iv);
        using var input = File.OpenRead(inputPath);
        using var output = File.Create(outputZip);
        input.Seek(48, SeekOrigin.Begin);
        using var aes = Aes.Create();
        aes.Key = key;
        aes.IV = iv;
        aes.Mode = CipherMode.CBC;
        aes.Padding = PaddingMode.PKCS7;
        using var crypto = new CryptoStream(output, aes.CreateDecryptor(), CryptoStreamMode.Write);
        input.CopyTo(crypto, 2 * 1024 * 1024);
        crypto.FlushFinalBlock();
    }

    private string ExportMetadata(string workFolder, string appId, string version, string appName, JsonElement? rawApp, JsonElement outer, JsonElement responsePayload, JsonElement contentInfo, JsonElement decryptionInfo, PackageMetadata packageMetadata, string encryptedFile, string decodedZip, string extractedFolder, string profileIdentifier, string? getPoliciesRawResponse, string? getPoliciesDecodedPayload, string getPoliciesStatus, string getPoliciesError, JsonElement? selectedPolicy, object? policyCommands)
    {
        var metadataFolder = Path.Combine(workFolder, "Metadata");
        Directory.CreateDirectory(metadataFolder);

        SaveJson(Path.Combine(metadataFolder, "00_download_summary.json"), new
        {
            DisplayName = appName,
            ApplicationId = appId,
            AppId = appId,
            CommittedContentVersion = version,
            DownloadedAt = DateTimeOffset.Now.ToString("o"),
            WorkFolder = workFolder,
            EncryptedFile = encryptedFile,
            DecodedZip = decodedZip,
            ExtractedFolder = extractedFolder,
            ProfileIdentifier = profileIdentifier,
            MetadataMode = "Native C# backend. Package metadata exported locally. Sensitive download secrets are redacted."
        });
        if (rawApp.HasValue) SaveJsonElement(Path.Combine(metadataFolder, "01_catalog_app_metadata.json"), Redact(rawApp.Value));
        SaveJsonElement(Path.Combine(metadataFolder, "02_getcontentinfo_outer_redacted.json"), Redact(outer));
        SaveJsonElement(Path.Combine(metadataFolder, "03_responsepayload_redacted.json"), Redact(responsePayload));
        SaveJsonElement(Path.Combine(metadataFolder, "04_contentinfo_redacted.json"), Redact(contentInfo));
        SaveJsonElement(Path.Combine(metadataFolder, "05_decryptioninfo_redacted.json"), Redact(decryptionInfo));
        SaveJson(Path.Combine(metadataFolder, "06_package_metadata.json"), packageMetadata);
        if (packageMetadata.PatchMyPCCommandLine is not null)
        {
            SaveJson(Path.Combine(metadataFolder, "06a_patchmypc_commandline_decoded.json"), packageMetadata.PatchMyPCCommandLine);
        }
        SaveJson(Path.Combine(metadataFolder, "07_test_install_metadata_package_only.json"), PackageAppMetadataBuilder.Build(appId, appName, extractedFolder, packageMetadata));
        SaveGetPoliciesMetadata(metadataFolder, appId, getPoliciesRawResponse, getPoliciesDecodedPayload, getPoliciesStatus, getPoliciesError, selectedPolicy, policyCommands);
        File.WriteAllText(Path.Combine(metadataFolder, "README.txt"), "Metadata exported by the native C# backend. Secrets such as URLs, keys and IV values are redacted from the exported JSON files. Test install always reads 10_policy_commands.json. If no SideCar app policy payload returned a matching app policy, that file contains the package metadata fallback and explains why.\r\n", Encoding.UTF8);
        return metadataFolder;
    }


    private void SaveGetPoliciesMetadata(string metadataFolder, string appId, string? rawResponse, string? decodedPayload, string status, string error, JsonElement? selectedPolicy, object? policyCommands)
    {
        var payloadPath = Path.Combine(metadataFolder, "08_getpolicies_payload_redacted.json");
        var selectedPath = Path.Combine(metadataFolder, "09_getpolicies_selected_app_redacted.json");
        var commandsPath = Path.Combine(metadataFolder, "10_policy_commands.json");

        if (!string.IsNullOrWhiteSpace(decodedPayload))
        {
            try
            {
                using var payloadDoc = JsonDocument.Parse(decodedPayload);
                SaveJsonElement(payloadPath, Redact(payloadDoc.RootElement));
            }
            catch (Exception ex)
            {
                SaveJson(payloadPath, new
                {
                    Status = status,
                    ApplicationId = appId,
                    Message = "SideCar returned a policy payload, but it was not valid JSON after decoding.",
                    DecodeError = ex.Message,
                    PayloadPreview = decodedPayload.Length > 4000 ? decodedPayload[..4000] : decodedPayload
                });
            }
        }
        else
        {
            SaveJson(payloadPath, new
            {
                Status = string.IsNullOrWhiteSpace(status) ? "No SideCar policy source returned a decodable payload." : status,
                ApplicationId = appId,
                Error = error,
                RawResponseWasReturned = !string.IsNullOrWhiteSpace(rawResponse),
                RawResponsePreview = BuildPreview(rawResponse)
            });
        }

        if (selectedPolicy.HasValue)
        {
            SaveJsonElement(selectedPath, Redact(selectedPolicy.Value));
        }
        else
        {
            SaveJson(selectedPath, new
            {
                Matched = false,
                ApplicationId = appId,
                Status = status,
                Error = error,
                Message = "No matching app policy was found in the IME SideCar policy list. The test install command falls back to package metadata."
            });
        }

        SaveJson(commandsPath, policyCommands ?? new
        {
            CommandSource = "Package metadata fallback",
            ApplicationId = appId,
            InstallCommandLine = string.Empty,
            UninstallCommandLine = string.Empty,
            HasPowerShellScriptInstaller = false,
            Note = "No policy command data was available."
        });
    }

    private static JsonElement? TryFindPolicyByAppIdOrName(string? decodedPayload, string appId, string appName, out string matchReason)
    {
        matchReason = string.Empty;
        if (string.IsNullOrWhiteSpace(decodedPayload)) return null;

        try
        {
            using var doc = JsonDocument.Parse(decodedPayload);
            return FindPolicyByAppIdOrNameRecursive(doc.RootElement, appId, NormalizePolicyName(appName), GetArchitectureHint(appName), 0, out matchReason);
        }
        catch
        {
            matchReason = string.Empty;
            return null;
        }
    }

    private static JsonElement? FindPolicyByAppIdOrNameRecursive(JsonElement element, string appId, string normalizedAppName, string selectedArchitectureHint, int depth, out string matchReason)
    {
        matchReason = string.Empty;
        if (depth > 8) return null;

        if (element.ValueKind == JsonValueKind.Object)
        {
            if (PolicyMatchesAppId(element, appId))
            {
                matchReason = "policy id matched the Company Portal app id";
                return element.Clone();
            }

            if (!string.IsNullOrWhiteSpace(normalizedAppName) && PolicyMatchesAppName(element, normalizedAppName, selectedArchitectureHint, out var policyName))
            {
                matchReason = $"policy name matched the Company Portal app name ({policyName})";
                return element.Clone();
            }

            foreach (var property in element.EnumerateObject())
            {
                var child = property.Value;
                if (child.ValueKind == JsonValueKind.String)
                {
                    var text = child.GetString();
                    if (!string.IsNullOrWhiteSpace(text))
                    {
                        var trimmed = text.Trim();
                        if (trimmed.StartsWith("{", StringComparison.Ordinal) || trimmed.StartsWith("[", StringComparison.Ordinal))
                        {
                            try
                            {
                                using var nestedDoc = JsonDocument.Parse(trimmed);
                                var nestedMatch = FindPolicyByAppIdOrNameRecursive(nestedDoc.RootElement, appId, normalizedAppName, selectedArchitectureHint, depth + 1, out matchReason);
                                if (nestedMatch.HasValue) return nestedMatch;
                            }
                            catch
                            {
                                // Not embedded JSON.
                            }
                        }
                    }
                }
                else
                {
                    var match = FindPolicyByAppIdOrNameRecursive(child, appId, normalizedAppName, selectedArchitectureHint, depth + 1, out matchReason);
                    if (match.HasValue) return match;
                }
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
            {
                var match = FindPolicyByAppIdOrNameRecursive(item, appId, normalizedAppName, selectedArchitectureHint, depth + 1, out matchReason);
                if (match.HasValue) return match;
            }
        }
        else if (element.ValueKind == JsonValueKind.String)
        {
            var text = element.GetString();
            if (!string.IsNullOrWhiteSpace(text))
            {
                var trimmed = text.Trim();
                if (trimmed.StartsWith("{", StringComparison.Ordinal) || trimmed.StartsWith("[", StringComparison.Ordinal))
                {
                    try
                    {
                        using var nestedDoc = JsonDocument.Parse(trimmed);
                        return FindPolicyByAppIdOrNameRecursive(nestedDoc.RootElement, appId, normalizedAppName, selectedArchitectureHint, depth + 1, out matchReason);
                    }
                    catch
                    {
                        matchReason = string.Empty;
                        return null;
                    }
                }
            }
        }

        return null;
    }

    private static bool PolicyMatchesAppId(JsonElement policy, string appId)
    {
        if (string.IsNullOrWhiteSpace(appId)) return false;
        foreach (var name in new[] { "Id", "id", "ApplicationId", "applicationId", "AppId", "appId", "MobileAppId", "mobileAppId", "GuidKey", "guidKey", "MobileAppIdentifier", "mobileAppIdentifier", "AppIdentifier", "appIdentifier", "TargetId", "targetId" })
        {
            var value = GetPolicyString(policy, name);
            if (value.Equals(appId, StringComparison.OrdinalIgnoreCase)) return true;
        }

        return false;
    }

    private static bool PolicyMatchesAppName(JsonElement policy, string normalizedAppName, string selectedArchitectureHint, out string policyName)
    {
        policyName = string.Empty;
        if (string.IsNullOrWhiteSpace(normalizedAppName)) return false;

        foreach (var name in new[] { "Name", "name", "DisplayName", "displayName", "ApplicationName", "applicationName", "AppName", "appName", "Title", "title" })
        {
            var value = GetPolicyString(policy, name);
            if (string.IsNullOrWhiteSpace(value)) continue;

            var normalizedPolicyName = NormalizePolicyName(value);
            if (normalizedPolicyName.Equals(normalizedAppName, StringComparison.OrdinalIgnoreCase))
            {
                var policyArchitectureHint = GetArchitectureHint(value);
                if (!string.IsNullOrWhiteSpace(selectedArchitectureHint) &&
                    !string.IsNullOrWhiteSpace(policyArchitectureHint) &&
                    !selectedArchitectureHint.Equals(policyArchitectureHint, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                policyName = value;
                return true;
            }
        }

        return false;
    }


    private static string GetArchitectureHint(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        var text = " " + value.Replace('_', ' ').Replace('-', ' ').Replace('(', ' ').Replace(')', ' ').Replace('[', ' ').Replace(']', ' ') + " ";

        if (text.Contains(" arm64 ", StringComparison.OrdinalIgnoreCase) || text.Contains(" aarch64 ", StringComparison.OrdinalIgnoreCase)) return "arm64";
        if (text.Contains(" arm ", StringComparison.OrdinalIgnoreCase)) return "arm";
        if (text.Contains(" x64 ", StringComparison.OrdinalIgnoreCase) ||
            text.Contains(" amd64 ", StringComparison.OrdinalIgnoreCase) ||
            text.Contains(" 64 bit ", StringComparison.OrdinalIgnoreCase) ||
            text.Contains(" 64bit ", StringComparison.OrdinalIgnoreCase) ||
            text.Contains(" win64 ", StringComparison.OrdinalIgnoreCase)) return "x64";
        if (text.Contains(" x86 ", StringComparison.OrdinalIgnoreCase) ||
            text.Contains(" 32 bit ", StringComparison.OrdinalIgnoreCase) ||
            text.Contains(" 32bit ", StringComparison.OrdinalIgnoreCase) ||
            text.Contains(" win32 ", StringComparison.OrdinalIgnoreCase)) return "x86";

        return string.Empty;
    }

    private static string NormalizePolicyName(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        var text = value.Trim();

        foreach (var prefix in new[] { "Update for ", "Updates for ", "Install ", "Install for ", "Required app ", "Available app " })
        {
            if (text.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            {
                text = text[prefix.Length..].Trim();
                break;
            }
        }

        text = text.Replace("\u00A0", " ");
        while (text.Contains("  ", StringComparison.Ordinal)) text = text.Replace("  ", " ", StringComparison.Ordinal);
        return text.Trim().Trim('-', ':').Trim();
    }

    private static object BuildPreContentPolicyCommandSummary(JsonElement? selectedPolicy, string appId, string appName, string getPoliciesStatus, string getPoliciesError)
    {
        if (selectedPolicy.HasValue)
        {
            var policy = selectedPolicy.Value;
            var scripts = GetPolicyScripts(policy);
            var installScript = scripts.FirstOrDefault(s => s.Type == 1);
            var uninstallScript = scripts.FirstOrDefault(s => s.Type == 2);
            var hasScriptInstaller = installScript is not null || uninstallScript is not null;

            return new
            {
                CommandSource = "SideCar app policy preflight",
                ApplicationId = appId,
                PolicyId = FirstNotEmpty(GetPolicyString(policy, "Id"), appId),
                CommittedContentVersion = GetPolicyCommittedContentVersion(policy),
                DisplayName = FirstNotEmpty(GetPolicyString(policy, "Name"), GetPolicyString(policy, "DisplayName"), appName),
                InstallCommandLine = GetPolicyString(policy, "InstallCommandLine"),
                UninstallCommandLine = GetPolicyString(policy, "UninstallCommandLine"),
                SetupFilePath = FirstNotEmpty(GetPolicyString(policy, "SetUpFilePath"), GetPolicyString(policy, "SetupFilePath")),
                InstallContext = GetPolicyString(policy, "InstallContext"),
                InstallBehavior = string.Empty,
                InstallEx = GetPolicyString(policy, "InstallEx"),
                ReturnCodes = GetPolicyString(policy, "ReturnCodes"),
                HasPowerShellScriptInstaller = hasScriptInstaller,
                InstallScriptId = installScript?.Id ?? string.Empty,
                UninstallScriptId = uninstallScript?.Id ?? string.Empty,
                InstallScriptCommandLine = string.Empty,
                UninstallScriptCommandLine = string.Empty,
                InstallScriptPath = string.Empty,
                UninstallScriptPath = string.Empty,
                ExpectedLogPath = string.Empty,
                Note = hasScriptInstaller
                    ? "A decoded IME app policy payload matched before content download. This is the data AppWorkload logs as Get policies. Script ids are known, but script content is resolved after GetContentInfo returns and the app content is extracted. This file is overwritten after extraction."
                    : "A decoded IME app policy payload matched before content download. This is the data AppWorkload logs as Get policies. The real policy command lines and policy Version are already visible here. This file is overwritten after extraction.",
                PolicyListMatched = true,
                DownloadedScripts = Array.Empty<PolicyScriptDownloadInfo>(),
                Scripts = scripts
            };
        }

        return new
        {
            CommandSource = "SideCar app policy preflight",
            ApplicationId = appId,
            PolicyId = string.Empty,
            CommittedContentVersion = string.Empty,
            DisplayName = appName,
            InstallCommandLine = string.Empty,
            UninstallCommandLine = string.Empty,
            SetupFilePath = string.Empty,
            InstallContext = string.Empty,
            InstallBehavior = string.Empty,
            InstallEx = string.Empty,
            ReturnCodes = string.Empty,
            HasPowerShellScriptInstaller = false,
            InstallScriptId = string.Empty,
            UninstallScriptId = string.Empty,
            InstallScriptCommandLine = string.Empty,
            UninstallScriptCommandLine = string.Empty,
            InstallScriptPath = string.Empty,
            UninstallScriptPath = string.Empty,
            ExpectedLogPath = string.Empty,
            Note = FirstNotEmpty(getPoliciesError, getPoliciesStatus, "No IME SideCar policy source returned a matching policy. Package fallback is only available after the content is extracted."),
            PolicyListMatched = false,
            DownloadedScripts = Array.Empty<PolicyScriptDownloadInfo>(),
            Scripts = Array.Empty<PolicyScriptInfo>()
        };
    }

    private static object BuildPackageFallbackPolicyCommandSummary(string appId, string appName, string extractedFolder, PackageMetadata packageMetadata, string getPoliciesStatus, string getPoliciesError)
    {
        var packageFallback = PackageAppMetadataBuilder.Build(appId, appName, extractedFolder, packageMetadata);
        var command = FirstNotEmpty(GetObjectString(packageFallback, "installCommandLine"), GetObjectString(packageFallback, "InstallCommandLine"), GetObjectString(packageFallback, "Command"));
        var installBehavior = packageMetadata.InstallationBehavior.Contains("system", StringComparison.OrdinalIgnoreCase) ? "system" : "user";
        var expectedLogPath = BuildExpectedLogPath(packageMetadata, appName);

        return new
        {
            CommandSource = "Package metadata fallback",
            ApplicationId = appId,
            PolicyId = string.Empty,
            CommittedContentVersion = string.Empty,
            DisplayName = appName,
            InstallCommandLine = command,
            UninstallCommandLine = string.Empty,
            SetupFilePath = packageMetadata.SetupFileFromMetadata,
            InstallContext = string.Empty,
            InstallBehavior = installBehavior,
            InstallEx = string.Empty,
            ReturnCodes = string.Empty,
            HasPowerShellScriptInstaller = false,
            InstallScriptId = string.Empty,
            UninstallScriptId = string.Empty,
            InstallScriptCommandLine = string.Empty,
            UninstallScriptCommandLine = string.Empty,
            InstallScriptPath = string.Empty,
            UninstallScriptPath = string.Empty,
            ExpectedLogPath = expectedLogPath,
            Note = FirstNotEmpty(getPoliciesError,
                getPoliciesStatus,
                "No matching app policy was found in the IME SideCar policy list. Test install is using the command rebuilt from the extracted package metadata."),
            PolicyListMatched = false,
            PackageFallback = packageFallback,
            DownloadedScripts = Array.Empty<PolicyScriptDownloadInfo>(),
            Scripts = Array.Empty<PolicyScriptInfo>()
        };
    }

    private static object BuildPolicyCommandSummary(JsonElement policy, string appId, string appName, string extractedFolder, PackageMetadata packageMetadata, IReadOnlyDictionary<string, PolicyScriptDownloadInfo> downloadedScripts)
    {
        var scripts = GetPolicyScripts(policy);
        var installScript = scripts.FirstOrDefault(s => s.Type == 1);
        var uninstallScript = scripts.FirstOrDefault(s => s.Type == 2);

        downloadedScripts.TryGetValue(installScript?.Id ?? string.Empty, out var downloadedInstallScript);
        downloadedScripts.TryGetValue(uninstallScript?.Id ?? string.Empty, out var downloadedUninstallScript);

        var installScriptPath = FirstNotEmpty(downloadedInstallScript?.ScriptPath ?? string.Empty, FindScriptFile(extractedFolder, installScript?.Id ?? string.Empty));
        var uninstallScriptPath = FirstNotEmpty(downloadedUninstallScript?.ScriptPath ?? string.Empty, FindScriptFile(extractedFolder, uninstallScript?.Id ?? string.Empty));
        var installScriptCommand = FirstNotEmpty(downloadedInstallScript?.CommandLine ?? string.Empty, BuildPowerShellScriptCommand(installScriptPath));
        var uninstallScriptCommand = FirstNotEmpty(downloadedUninstallScript?.CommandLine ?? string.Empty, BuildPowerShellScriptCommand(uninstallScriptPath));
        var installCommand = GetPolicyString(policy, "InstallCommandLine");
        var uninstallCommand = GetPolicyString(policy, "UninstallCommandLine");
        var expectedLogPath = BuildExpectedLogPath(packageMetadata, appName);
        var hasScriptInstaller = installScript is not null || uninstallScript is not null;

        var note = hasScriptInstaller
            ? (!string.IsNullOrWhiteSpace(installScriptCommand) || !string.IsNullOrWhiteSpace(uninstallScriptCommand)
                ? "PowerShell script installer metadata was found in the SideCar app policy payload and the script content was downloaded with SideCar GetContentInfo. Test install uses the downloaded script instead of the placeholder command."
                : "PowerShell script installer metadata was found in the SideCar app policy payload, but the script content could not be downloaded. The exported command keeps the policy command line and records the script IDs.")
            : "Install and uninstall command lines were extracted from the matching SideCar app policy payload.";

        var commandSource = hasScriptInstaller && (!string.IsNullOrWhiteSpace(installScriptCommand) || !string.IsNullOrWhiteSpace(uninstallScriptCommand))
            ? "SideCar app policy + GetContentInfo script content"
            : "SideCar app policy";

        return new
        {
            CommandSource = commandSource,
            ApplicationId = appId,
            PolicyId = FirstNotEmpty(GetPolicyString(policy, "Id"), appId),
            CommittedContentVersion = GetPolicyCommittedContentVersion(policy),
            DisplayName = FirstNotEmpty(GetPolicyString(policy, "Name"), GetPolicyString(policy, "DisplayName"), appName),
            InstallCommandLine = installCommand,
            UninstallCommandLine = uninstallCommand,
            SetupFilePath = FirstNotEmpty(GetPolicyString(policy, "SetUpFilePath"), GetPolicyString(policy, "SetupFilePath"), packageMetadata.SetupFileFromMetadata),
            InstallContext = GetPolicyString(policy, "InstallContext"),
            InstallBehavior = packageMetadata.InstallationBehavior,
            InstallEx = GetPolicyString(policy, "InstallEx"),
            ReturnCodes = GetPolicyString(policy, "ReturnCodes"),
            HasPowerShellScriptInstaller = hasScriptInstaller,
            InstallScriptId = installScript?.Id ?? string.Empty,
            UninstallScriptId = uninstallScript?.Id ?? string.Empty,
            InstallScriptCommandLine = installScriptCommand,
            UninstallScriptCommandLine = uninstallScriptCommand,
            InstallScriptPath = installScriptPath,
            UninstallScriptPath = uninstallScriptPath,
            ExpectedLogPath = expectedLogPath,
            Note = note,
            DownloadedScripts = downloadedScripts.Values,
            Scripts = scripts
        };
    }

    private async Task<Dictionary<string, PolicyScriptDownloadInfo>> TryDownloadPolicyScriptsAsync(DownloadContext ctx, JsonElement policy, string version, string workFolder, string extractedFolder)
    {
        var result = new Dictionary<string, PolicyScriptDownloadInfo>(StringComparer.OrdinalIgnoreCase);
        var scripts = GetPolicyScripts(policy).Where(s => !string.IsNullOrWhiteSpace(s.Id)).ToList();
        if (scripts.Count == 0) return result;

        var scriptRoot = Path.Combine(workFolder, "Scripts");
        Directory.CreateDirectory(scriptRoot);

        foreach (var script in scripts)
        {
            try
            {
                var label = script.Type == 1 ? "install" : script.Type == 2 ? "uninstall" : "script";
                Log($"Detected PowerShell {label} script id from policy: {script.Id}");

                if (!string.IsNullOrWhiteSpace(script.Data) && !script.Data.Equals("null", StringComparison.OrdinalIgnoreCase))
                {
                    var dataScript = SavePolicyScriptData(script, scriptRoot, extractedFolder);
                    if (!string.IsNullOrWhiteSpace(dataScript))
                    {
                        result[script.Id] = new PolicyScriptDownloadInfo(script.Id, script.Type, dataScript, BuildPowerShellScriptCommand(dataScript), Path.GetDirectoryName(dataScript) ?? string.Empty, "Script content was decoded from the policy Data field.");
                        continue;
                    }
                }

                var scriptContentResponse = await SendGetContentInfoRequestAsync(ctx, script.Id, "1");
                if (scriptContentResponse is null && !string.Equals(version, "1", StringComparison.OrdinalIgnoreCase))
                {
                    scriptContentResponse = await SendGetContentInfoRequestAsync(ctx, script.Id, version);
                }

                if (scriptContentResponse is null)
                {
                    Log($"PowerShell script content could not be resolved with GetContentInfo for script id {script.Id}.");
                    continue;
                }

                var scriptPath = await DownloadAndExtractPolicyScriptAsync(scriptContentResponse, script, scriptRoot, extractedFolder);
                if (string.IsNullOrWhiteSpace(scriptPath))
                {
                    Log($"PowerShell script content was downloaded for {script.Id}, but no .ps1 file could be extracted.");
                    continue;
                }

                result[script.Id] = new PolicyScriptDownloadInfo(script.Id, script.Type, scriptPath, BuildPowerShellScriptCommand(scriptPath), Path.GetDirectoryName(scriptPath) ?? string.Empty, "Script content was downloaded through SideCar GetContentInfo.");
                Log($"PowerShell script content ready for test install: {scriptPath}");
            }
            catch (Exception ex)
            {
                Log($"WARNING: Could not download PowerShell script content for script id {script.Id}: {ex.Message}");
            }
        }

        return result;
    }

    private async Task<string> DownloadAndExtractPolicyScriptAsync(string contentResponse, PolicyScriptInfo script, string scriptRoot, string extractedFolder)
    {
        using var outerDoc = JsonDocument.Parse(contentResponse);
        if (!TryGetString(outerDoc.RootElement, "ResponsePayload", out var responsePayloadText)) return string.Empty;

        using var responsePayloadDoc = JsonDocument.Parse(responsePayloadText);
        var responsePayload = responsePayloadDoc.RootElement.Clone();
        if (!TryGetString(responsePayload, "ContentInfo", out var contentInfoText)) return string.Empty;

        using var contentInfoDoc = JsonDocument.Parse(contentInfoText);
        var contentInfo = contentInfoDoc.RootElement.Clone();
        var uploadLocation = GetStringRecursive(contentInfo, "UploadLocation");
        if (string.IsNullOrWhiteSpace(uploadLocation)) return string.Empty;

        var decryptionInfo = DecryptDecryptInfo(responsePayload);
        var profileIdentifier = GetStringRecursive(decryptionInfo, "ProfileIdentifier") ?? string.Empty;
        var scriptFolder = Path.Combine(scriptRoot, MakeSafeFileName(script.Id));
        Directory.CreateDirectory(scriptFolder);

        var encryptedPath = Path.Combine(scriptFolder, script.Id + ".bin");
        var decodedPath = Path.Combine(scriptFolder, script.Id + ".decoded");
        await DownloadFileAsync(uploadLocation, encryptedPath, 94, 96);

        if (profileIdentifier.Equals("NoEncryption", StringComparison.OrdinalIgnoreCase))
        {
            File.Copy(encryptedPath, decodedPath, overwrite: true);
        }
        else
        {
            var key = GetStringRecursive(decryptionInfo, "EncryptionKey", "ContentEncryptionKey", "FileEncryptionKey", "AesKey", "AESKey", "Key", "Base64Key");
            var iv = GetStringRecursive(decryptionInfo, "IV", "InitializationVector", "InitVector", "AesIV", "AESIV", "FileIV", "Base64IV");
            if (string.IsNullOrWhiteSpace(key) || string.IsNullOrWhiteSpace(iv)) return string.Empty;
            DecryptIntuneWinBin(encryptedPath, decodedPath, key, iv);
        }

        return ExtractPolicyScriptFile(decodedPath, script, scriptFolder, extractedFolder);
    }

    private static string ExtractPolicyScriptFile(string decodedPath, PolicyScriptInfo script, string scriptFolder, string extractedFolder)
    {
        var extractFolder = Path.Combine(scriptFolder, "Decoded");
        if (Directory.Exists(extractFolder)) Directory.Delete(extractFolder, recursive: true);
        Directory.CreateDirectory(extractFolder);

        if (IsZipFile(decodedPath))
        {
            ZipFile.ExtractToDirectory(decodedPath, extractFolder, overwriteFiles: true);
            var ps1 = Directory.EnumerateFiles(extractFolder, "*.ps1", SearchOption.AllDirectories).FirstOrDefault();
            return !string.IsNullOrWhiteSpace(ps1) ? CopyPolicyScriptToAppRoot(ps1, script, extractedFolder) : string.Empty;
        }

        var decodedBytes = File.ReadAllBytes(decodedPath);
        if (decodedBytes.Length >= 2 && decodedBytes[0] == 0x1F && decodedBytes[1] == 0x8B)
        {
            var gzipTarget = Path.Combine(extractFolder, BuildPolicyScriptFileName(script));
            using (var input = File.OpenRead(decodedPath))
            using (var gzip = new GZipStream(input, CompressionMode.Decompress))
            using (var output = File.Create(gzipTarget))
            {
                gzip.CopyTo(output);
            }
            return CopyPolicyScriptToAppRoot(gzipTarget, script, extractedFolder);
        }

        var target = Path.Combine(extractFolder, BuildPolicyScriptFileName(script));
        File.Copy(decodedPath, target, overwrite: true);
        return CopyPolicyScriptToAppRoot(target, script, extractedFolder);
    }

    private static string SavePolicyScriptData(PolicyScriptInfo script, string scriptRoot, string extractedFolder)
    {
        try
        {
            var scriptFolder = Path.Combine(scriptRoot, MakeSafeFileName(script.Id));
            Directory.CreateDirectory(scriptFolder);
            var bytes = Convert.FromBase64String(script.Data);
            var path = Path.Combine(scriptFolder, BuildPolicyScriptFileName(script));
            File.WriteAllBytes(path, bytes);
            return CopyPolicyScriptToAppRoot(path, script, extractedFolder);
        }
        catch
        {
            return string.Empty;
        }
    }

    private static string CopyPolicyScriptToAppRoot(string sourcePath, PolicyScriptInfo script, string extractedFolder)
    {
        if (string.IsNullOrWhiteSpace(sourcePath) || !File.Exists(sourcePath) || string.IsNullOrWhiteSpace(extractedFolder)) return string.Empty;
        Directory.CreateDirectory(extractedFolder);
        var target = Path.Combine(extractedFolder, BuildPolicyScriptFileName(script));
        File.Copy(sourcePath, target, overwrite: true);
        return target;
    }

    private static string BuildPolicyScriptFileName(PolicyScriptInfo script)
    {
        var prefix = script.Type == 1 ? "install" : script.Type == 2 ? "uninstall" : "script";
        var id = string.IsNullOrWhiteSpace(script.Id) ? Guid.NewGuid().ToString("N") : script.Id;
        return "IntuneWinDownloader_" + prefix + "_" + MakeSafeFileName(id) + ".ps1";
    }

    private static bool IsZipFile(string path)
    {
        if (!File.Exists(path)) return false;
        using var stream = File.OpenRead(path);
        if (stream.Length < 4) return false;
        return stream.ReadByte() == 'P' && stream.ReadByte() == 'K';
    }

    private static List<PolicyScriptInfo> GetPolicyScripts(JsonElement policy)
    {
        var result = new List<PolicyScriptInfo>();
        if (policy.ValueKind != JsonValueKind.Object || !policy.TryGetProperty("Scripts", out var scriptsElement) || scriptsElement.ValueKind == JsonValueKind.Null)
        {
            return result;
        }

        if (scriptsElement.ValueKind == JsonValueKind.String)
        {
            var text = scriptsElement.GetString();
            if (string.IsNullOrWhiteSpace(text)) return result;
            try
            {
                using var scriptDoc = JsonDocument.Parse(text);
                AddPolicyScripts(scriptDoc.RootElement, result);
            }
            catch
            {
                return result;
            }
        }
        else
        {
            AddPolicyScripts(scriptsElement, result);
        }

        return result;
    }

    private static void AddPolicyScripts(JsonElement root, List<PolicyScriptInfo> result)
    {
        foreach (var item in EnumerateArrayOrSingle(root))
        {
            if (item.ValueKind != JsonValueKind.Object) continue;
            var id = GetPolicyString(item, "Id");
            var typeText = GetPolicyString(item, "Type");
            _ = int.TryParse(typeText, out var type);
            var data = GetPolicyString(item, "Data");
            var enforce = GetPolicyBool(item, "EnforceSignatureCheck");
            result.Add(new PolicyScriptInfo(id, type, data, enforce));
        }
    }

    private static string FindScriptFile(string extractedFolder, string scriptId)
    {
        if (string.IsNullOrWhiteSpace(extractedFolder) || !Directory.Exists(extractedFolder) || string.IsNullOrWhiteSpace(scriptId)) return string.Empty;
        return Directory.EnumerateFiles(extractedFolder, "*.ps1", SearchOption.AllDirectories)
                   .FirstOrDefault(path => Path.GetFileNameWithoutExtension(path).Contains(scriptId, StringComparison.OrdinalIgnoreCase)
                                           || Path.GetFileName(path).Contains(scriptId, StringComparison.OrdinalIgnoreCase))
               ?? string.Empty;
    }

    private static string BuildPowerShellScriptCommand(string scriptPath)
    {
        return string.IsNullOrWhiteSpace(scriptPath)
            ? string.Empty
            : "powershell.exe -NoProfile -ExecutionPolicy Bypass -File " + Quote(scriptPath);
    }

    private static string BuildExpectedLogPath(PackageMetadata packageMetadata, string appName)
    {
        var patch = packageMetadata.PatchMyPCCommandLine;
        if (patch is null || string.IsNullOrWhiteSpace(patch.LoggingPath)) return string.Empty;
        var name = FirstNotEmpty(patch.ApplicationName, appName, "install");
        return Path.Combine(Environment.ExpandEnvironmentVariables(patch.LoggingPath), MakeSafeFileName(name) + ".log");
    }

    private static string GetPolicyString(JsonElement element, string name)
    {
        if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(name, out var value) || value.ValueKind == JsonValueKind.Null) return string.Empty;
        return value.ValueKind == JsonValueKind.String ? value.GetString() ?? string.Empty : value.ToString();
    }

    private static bool GetPolicyBool(JsonElement element, string name)
    {
        if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(name, out var value)) return false;
        if (value.ValueKind == JsonValueKind.True) return true;
        if (value.ValueKind == JsonValueKind.False) return false;
        return bool.TryParse(value.ToString(), out var result) && result;
    }

    private static string FirstNotEmpty(params string?[] values) => values.FirstOrDefault(v => !string.IsNullOrWhiteSpace(v)) ?? string.Empty;

    private static string GetObjectString(object value, string propertyName)
    {
        var property = value.GetType().GetProperty(propertyName);
        var propertyValue = property?.GetValue(value);
        return propertyValue?.ToString() ?? string.Empty;
    }

    private static string BuildPreview(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        return value.Length > 4000 ? value[..4000] : value;
    }

    private static string Quote(string value) => "\"" + value.Replace("\"", "\\\"") + "\"";


    private async Task<List<AppRow>> ConvertIwServiceCatalogToRowsAsync(JsonElement root, string bearerToken)
    {
        var rows = new List<AppRow>();
        using var iconClient = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
        var iconCount = 0;
        foreach (var item in GetCatalogItems(root))
        {
            if (!IwServiceAppShouldBeShown(item)) continue;
            var id = GetIwServiceValue(item, "GuidKey", "guidKey", "ApplicationId", "applicationId", "MobileAppId", "mobileAppId", "AppId", "appId", "Id", "id");
            if (!Guid.TryParse(id, out _)) continue;
            var name = GetIwServiceValue(item, "Name", "name", "DisplayName", "displayName", "Title", "title");
            if (string.IsNullOrWhiteSpace(name)) name = "(name not returned)";
            var publisher = GetIwServiceValue(item, "Publisher", "publisher", "Developer", "developer", "PublisherName", "publisherName");
            var appVersion = GetIwServiceValue(item, "AppVersion", "appVersion", "DisplayVersion", "displayVersion", "Version", "version");
            var relevance = GetIwServiceValue(item, "Relevance", "relevance");
            var datePublished = GetIwServiceValue(item, "DatePublished", "datePublished", "PublishedDate", "publishedDate", "ReleaseDate", "releaseDate", "CreatedDateTime", "createdDateTime", "LastModifiedDateTime", "lastModifiedDateTime");
            var status = GetIwServiceValue(item, "Status", "status", "InstallState", "installState", "Availability", "availability", "State", "state");
            var contentSizeBytes = GetIwServiceContentSizeBytes(item);
            var contentSizeDisplay = contentSizeBytes > 0 ? FormatByteSize(contentSizeBytes) : string.Empty;
            var iconSource = FindIconSource(item);
            var iconPath = await ResolveIconPathAsync(iconSource, id, bearerToken, iconClient);
            if (!string.IsNullOrWhiteSpace(iconPath)) iconCount++;

            var details = new List<string>();
            if (!string.IsNullOrWhiteSpace(appVersion)) details.Add($"AppVersion {appVersion}");
            if (!string.IsNullOrWhiteSpace(publisher)) details.Add($"Publisher {publisher}");
            if (!string.IsNullOrWhiteSpace(relevance)) details.Add($"Relevance {relevance}");
            if (!string.IsNullOrWhiteSpace(contentSizeDisplay)) details.Add($"Size {contentSizeDisplay}");
            rows.Add(new AppRow
            {
                Name = name,
                Id = id,
                Version = string.Empty,
                Source = "Company Portal catalog",
                Details = string.Join(", ", details),
                DisplayVersion = appVersion ?? string.Empty,
                PackageSize = contentSizeDisplay,
                PackageSizeBytes = contentSizeBytes,
                Publisher = publisher ?? string.Empty,
                DatePublished = NormalizeDateForDisplay(datePublished),
                Status = NormalizeCatalogStatus(status),
                IconPath = iconPath ?? string.Empty
            });
        }
        Log($"Resolved {iconCount} app icons from the Company Portal catalog.");
        return rows.OrderBy(r => r.Name).ThenBy(r => r.Source).ToList();
    }

    private static string NormalizeCatalogStatus(string? status)
    {
        if (string.IsNullOrWhiteSpace(status)) return "Available";
        var clean = status.Trim();
        if (clean.Equals("0", StringComparison.OrdinalIgnoreCase)) return "Available";
        if (clean.Equals("1", StringComparison.OrdinalIgnoreCase)) return "Installed";
        return clean;
    }

    private static string NormalizeDateForDisplay(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        if (DateTimeOffset.TryParse(value, out var dto)) return dto.LocalDateTime.ToString("M/d/yyyy");
        if (DateTime.TryParse(value, out var dt)) return dt.ToString("M/d/yyyy");
        return value.Trim();
    }

    private static string? FindIconSource(JsonElement element)
    {
        var iconNames = new[]
        {
            "Icon", "icon", "IconUrl", "iconUrl", "IconUri", "iconUri",
            "LargeIcon", "largeIcon", "LargeIconUrl", "largeIconUrl", "LargeIconUri", "largeIconUri",
            "SmallIcon", "smallIcon", "Logo", "logo", "LogoUrl", "logoUrl", "DisplayLogo", "displayLogo",
            "TileIcon", "tileIcon", "ImageUrl", "imageUrl", "PictureUrl", "pictureUrl", "AppIcon", "appIcon"
        };

        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var prop in element.EnumerateObject())
            {
                if (iconNames.Contains(prop.Name, StringComparer.OrdinalIgnoreCase) || IsIconPropertyName(prop.Name))
                {
                    var direct = FindFirstLikelyIconString(prop.Value);
                    if (!string.IsNullOrWhiteSpace(direct)) return direct;
                }
            }

            foreach (var prop in element.EnumerateObject())
            {
                var nested = FindIconSource(prop.Value);
                if (!string.IsNullOrWhiteSpace(nested)) return nested;
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
            {
                var nested = FindIconSource(item);
                if (!string.IsNullOrWhiteSpace(nested)) return nested;
            }
        }

        return null;
    }

    private static bool IsIconPropertyName(string name)
    {
        return name.Contains("icon", StringComparison.OrdinalIgnoreCase)
               || name.Contains("logo", StringComparison.OrdinalIgnoreCase)
               || name.Contains("image", StringComparison.OrdinalIgnoreCase)
               || name.Contains("picture", StringComparison.OrdinalIgnoreCase);
    }

    private static string? FindFirstLikelyIconString(JsonElement element)
    {
        if (element.ValueKind == JsonValueKind.String)
        {
            var value = element.GetString();
            return IsLikelyIconSource(value) ? value : null;
        }

        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var prop in element.EnumerateObject())
            {
                var found = FindFirstLikelyIconString(prop.Value);
                if (!string.IsNullOrWhiteSpace(found)) return found;
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
            {
                var found = FindFirstLikelyIconString(item);
                if (!string.IsNullOrWhiteSpace(found)) return found;
            }
        }

        return null;
    }

    private static bool IsLikelyIconSource(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        var text = value.Trim();
        if (text.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || text.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) return true;
        if (text.StartsWith("data:image/", StringComparison.OrdinalIgnoreCase)) return true;
        if (text.EndsWith(".png", StringComparison.OrdinalIgnoreCase)
            || text.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase)
            || text.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase)
            || text.EndsWith(".ico", StringComparison.OrdinalIgnoreCase)
            || text.EndsWith(".bmp", StringComparison.OrdinalIgnoreCase)
            || text.EndsWith(".gif", StringComparison.OrdinalIgnoreCase)
            || text.EndsWith(".webp", StringComparison.OrdinalIgnoreCase)
            || text.EndsWith(".svg", StringComparison.OrdinalIgnoreCase)) return true;
        if (text.Length < 120) return false;
        return TryDecodeImageBytes(text, out _);
    }

    private static async Task<string?> ResolveIconPathAsync(string? iconSource, string appId, string bearerToken, HttpClient client)
    {
        if (string.IsNullOrWhiteSpace(iconSource)) return null;
        var source = iconSource.Trim();

        try
        {
            if (source.StartsWith("data:image/", StringComparison.OrdinalIgnoreCase))
            {
                var comma = source.IndexOf(',');
                if (comma > 0 && TryDecodeImageBytes(source[(comma + 1)..], out var bytes))
                {
                    return SaveIconBytes(appId, bytes);
                }
            }

            if (TryDecodeImageBytes(source, out var inlineBytes))
            {
                return SaveIconBytes(appId, inlineBytes);
            }

            if (Uri.TryCreate(source, UriKind.Absolute, out var uri) && (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps))
            {
                using var request = new HttpRequestMessage(HttpMethod.Get, uri);
                if (!string.IsNullOrWhiteSpace(bearerToken))
                {
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
                }

                using var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
                if (response.IsSuccessStatusCode)
                {
                    var mediaType = response.Content.Headers.ContentType?.MediaType ?? string.Empty;
                    if (mediaType.StartsWith("image/", StringComparison.OrdinalIgnoreCase) || LooksLikeImageUrl(source))
                    {
                        var bytes = await response.Content.ReadAsByteArrayAsync();
                        if (bytes.Length > 0) return SaveIconBytes(appId, bytes, mediaType);
                    }
                }

                return source;
            }
        }
        catch
        {
            return null;
        }

        return null;
    }

    private static bool LooksLikeImageUrl(string source)
    {
        var path = source.Split('?', '#')[0];
        return path.EndsWith(".png", StringComparison.OrdinalIgnoreCase)
               || path.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase)
               || path.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase)
               || path.EndsWith(".ico", StringComparison.OrdinalIgnoreCase)
               || path.EndsWith(".bmp", StringComparison.OrdinalIgnoreCase)
               || path.EndsWith(".gif", StringComparison.OrdinalIgnoreCase)
               || path.EndsWith(".webp", StringComparison.OrdinalIgnoreCase)
               || path.EndsWith(".svg", StringComparison.OrdinalIgnoreCase);
    }

    private static bool TryDecodeImageBytes(string value, out byte[] bytes)
    {
        bytes = Array.Empty<byte>();
        try
        {
            var cleaned = value.Trim().Replace("\r", string.Empty).Replace("\n", string.Empty).Replace(" ", string.Empty);
            bytes = Convert.FromBase64String(cleaned);
            return bytes.Length > 8 && IsKnownImageHeader(bytes);
        }
        catch
        {
            bytes = Array.Empty<byte>();
            return false;
        }
    }

    private static bool IsKnownImageHeader(byte[] bytes)
    {
        return bytes.Length > 8
               && ((bytes[0] == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4E && bytes[3] == 0x47)
                   || (bytes[0] == 0xFF && bytes[1] == 0xD8)
                   || (bytes[0] == 0x00 && bytes[1] == 0x00 && bytes[2] == 0x01 && bytes[3] == 0x00)
                   || (bytes[0] == 0x47 && bytes[1] == 0x49 && bytes[2] == 0x46)
                   || (bytes[0] == 0x42 && bytes[1] == 0x4D)
                   || (bytes[0] == 0x52 && bytes[1] == 0x49 && bytes[2] == 0x46 && bytes[3] == 0x46)
                   || (bytes[0] == 0x3C && bytes[1] == 0x73 && bytes[2] == 0x76 && bytes[3] == 0x67));
    }

    private static string SaveIconBytes(string appId, byte[] bytes, string? mediaType = null)
    {
        var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "IntuneWinDownloader", "IconCache");
        Directory.CreateDirectory(folder);
        var extension = GetImageExtension(bytes, mediaType);
        var safeAppId = MakeSafeFileName(appId);
        var path = Path.Combine(folder, safeAppId + extension);
        File.WriteAllBytes(path, bytes);
        return path;
    }

    private static string GetImageExtension(byte[] bytes, string? mediaType)
    {
        if (!string.IsNullOrWhiteSpace(mediaType))
        {
            if (mediaType.Contains("png", StringComparison.OrdinalIgnoreCase)) return ".png";
            if (mediaType.Contains("jpeg", StringComparison.OrdinalIgnoreCase) || mediaType.Contains("jpg", StringComparison.OrdinalIgnoreCase)) return ".jpg";
            if (mediaType.Contains("icon", StringComparison.OrdinalIgnoreCase) || mediaType.Contains("ico", StringComparison.OrdinalIgnoreCase)) return ".ico";
            if (mediaType.Contains("gif", StringComparison.OrdinalIgnoreCase)) return ".gif";
            if (mediaType.Contains("bmp", StringComparison.OrdinalIgnoreCase)) return ".bmp";
            if (mediaType.Contains("webp", StringComparison.OrdinalIgnoreCase)) return ".webp";
            if (mediaType.Contains("svg", StringComparison.OrdinalIgnoreCase)) return ".svg";
        }

        if (bytes.Length > 4 && bytes[0] == 0x89 && bytes[1] == 0x50) return ".png";
        if (bytes.Length > 2 && bytes[0] == 0xFF && bytes[1] == 0xD8) return ".jpg";
        if (bytes.Length > 4 && bytes[0] == 0x00 && bytes[1] == 0x00 && bytes[2] == 0x01 && bytes[3] == 0x00) return ".ico";
        if (bytes.Length > 3 && bytes[0] == 0x47 && bytes[1] == 0x49 && bytes[2] == 0x46) return ".gif";
        if (bytes.Length > 2 && bytes[0] == 0x42 && bytes[1] == 0x4D) return ".bmp";
        if (bytes.Length > 4 && bytes[0] == 0x52 && bytes[1] == 0x49 && bytes[2] == 0x46 && bytes[3] == 0x46) return ".webp";
        if (bytes.Length > 4 && bytes[0] == 0x3C && bytes[1] == 0x73 && bytes[2] == 0x76 && bytes[3] == 0x67) return ".svg";
        return ".png";
    }

    private static IEnumerable<JsonElement> GetCatalogItems(JsonElement root)
    {
        foreach (var name in new[] { "value", "Value", "Items", "items" })
        {
            if (root.ValueKind == JsonValueKind.Object && root.TryGetProperty(name, out var array))
            {
                return EnumerateArrayOrSingle(array).Select(x => x.Clone()).ToList();
            }
        }
        return EnumerateArrayOrSingle(root).Select(x => x.Clone()).ToList();
    }

    private static JsonElement? FindOriginalCatalogItem(JsonElement root, string appId)
    {
        foreach (var item in GetCatalogItems(root))
        {
            var id = GetIwServiceValue(item, "GuidKey", "guidKey", "ApplicationId", "applicationId", "MobileAppId", "mobileAppId", "AppId", "appId", "Id", "id");
            if (!string.IsNullOrWhiteSpace(id) && id.Equals(appId, StringComparison.OrdinalIgnoreCase)) return item.Clone();
        }
        return null;
    }

    private static bool IwServiceAppShouldBeShown(JsonElement app)
    {
        var deploymentTechnology = GetStringRecursive(app, "DeploymentTechnology", "deploymentTechnology");
        if (!string.IsNullOrWhiteSpace(deploymentTechnology))
        {
            return deploymentTechnology.Equals("Win32App", StringComparison.OrdinalIgnoreCase)
                   || deploymentTechnology.Equals("Win32LobApp", StringComparison.OrdinalIgnoreCase);
        }

        var explicitType = FirstNotEmpty(
            GetStringRecursive(app, "ApplicationType", "applicationType", "AppType", "appType", "Type", "type"),
            GetStringRecursive(app, "ODataType", "odata.type", "@odata.type"));

        if (!string.IsNullOrWhiteSpace(explicitType))
        {
            if (explicitType.Contains("Win32", StringComparison.OrdinalIgnoreCase)) return true;
            if (explicitType.Contains("Store", StringComparison.OrdinalIgnoreCase)
                || explicitType.Contains("Winget", StringComparison.OrdinalIgnoreCase)
                || explicitType.Contains("AppX", StringComparison.OrdinalIgnoreCase)
                || explicitType.Contains("UWP", StringComparison.OrdinalIgnoreCase)) return false;
        }

        var channel = GetStringRecursive(app, "DistributionChannel", "distributionChannel", "Source", "source");
        if (!string.IsNullOrWhiteSpace(channel)
            && (channel.Contains("Store", StringComparison.OrdinalIgnoreCase)
                || channel.Contains("Winget", StringComparison.OrdinalIgnoreCase)))
        {
            return false;
        }

        // Some IWService entries do not expose a clean top-level type. Do not scan the full raw JSON for words like appx or store,
        // because those can appear in unrelated fields and hide valid Win32 apps.
        return true;
    }

    private static long GetIwServiceContentSizeBytes(JsonElement app)
    {
        var value = FirstNotEmpty(
            GetStringRecursive(app, "ContentSize", "contentSize", "Size", "size", "OriginalSize", "originalSize"),
            GetStringRecursive(app, "SizeInBytes", "sizeInBytes", "ContentSizeInBytes", "contentSizeInBytes"));

        if (!long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var number) || number <= 0) return 0;

        // IWService Win32AppInstallProperties.ContentSize is normally KB in the Company Portal catalog.
        // GetContentInfo.OriginalSize is bytes. Small catalog numbers are treated as KB so VLC 68569 becomes about 67 MB.
        return number < 10_000_000 ? number * 1024 : number;
    }

    private static string? GetIwServiceValue(JsonElement element, params string[] names) => GetStringRecursive(element, names);

    private static string GetIwServiceBaseUrlFromSideCarEndpoint(string endpoint)
    {
        var uri = new Uri(endpoint);
        var host = uri.Host;
        if (host.StartsWith("fef.", StringComparison.OrdinalIgnoreCase)) return $"https://{host}";
        if (host.StartsWith("agents.", StringComparison.OrdinalIgnoreCase)) return "https://fef." + host[7..];
        if (host.EndsWith("manage.microsoft.com", StringComparison.OrdinalIgnoreCase))
        {
            var parts = host.Split('.', 2);
            return parts.Length == 2 ? "https://fef." + parts[1] : "https://fef.manage.microsoft.com";
        }
        if (host.Equals("manage.microsoft.com", StringComparison.OrdinalIgnoreCase)) return "https://fef.manage.microsoft.com";
        return $"https://{host}";
    }

    private static string BuildIwServiceCatalogUrl(string baseUrl, string deviceId, int top)
    {
        var osVersion = Environment.OSVersion.Version.ToString();
        var arch = Environment.Is64BitOperatingSystem ? "x64" : "x86";
        var query = string.Join('&', new[]
        {
            "api-version=18.2",
            "ssp=WindowsUCP",
            "ssp-version=11.2.1787.0",
            "os=Windows",
            "os-version=" + Uri.EscapeDataString(osVersion),
            "os-sub=None",
            "arch=" + arch,
            "mgmt-agent=MicrosoftManagementPlatformCloudMdm",
            "device-id=" + Uri.EscapeDataString(deviceId),
            "$orderby=Name",
            "$top=" + top
        });
        return baseUrl.TrimEnd('/') + "/TrafficGateway/TrafficRoutingService/IWService/StatelessIWService/Applications?" + query;
    }


    private static string GetImeServiceStatusText()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\IntuneManagementExtension");
            var imagePath = key?.GetValue("ImagePath")?.ToString() ?? string.Empty;
            return string.IsNullOrWhiteSpace(imagePath)
                ? "IntuneManagementExtension service registry key was found, but ImagePath is empty."
                : "IntuneManagementExtension service ImagePath: " + imagePath;
        }
        catch (Exception ex)
        {
            return "Could not read IntuneManagementExtension service registry key: " + ex.Message;
        }
    }

    private static string? GetIntuneManagementExtensionVersion()
    {
        using var inventory = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\IntuneManagementExtension\Inventories");
        if (inventory is not null)
        {
            foreach (var name in inventory.GetSubKeyNames())
            {
                using var sub = inventory.OpenSubKey(name);
                if (sub is null) continue;
                if ((sub.GetValue("Name") as string)?.Equals("Microsoft Intune Management Extension", StringComparison.OrdinalIgnoreCase) == true)
                {
                    return sub.GetValue("Version")?.ToString();
                }
            }
        }
        return null;
    }

    private static string? GetStringRecursive(JsonElement element, params string[] names)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var prop in element.EnumerateObject())
            {
                if (names.Contains(prop.Name, StringComparer.OrdinalIgnoreCase) && prop.Value.ValueKind != JsonValueKind.Null)
                {
                    return prop.Value.ValueKind == JsonValueKind.String ? prop.Value.GetString() : prop.Value.ToString();
                }
            }
            foreach (var prop in element.EnumerateObject())
            {
                var found = GetStringRecursive(prop.Value, names);
                if (!string.IsNullOrWhiteSpace(found)) return found;
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
            {
                var found = GetStringRecursive(item, names);
                if (!string.IsNullOrWhiteSpace(found)) return found;
            }
        }
        return null;
    }

    private static JsonElement Redact(JsonElement input)
    {
        using var doc = JsonDocument.Parse(input.GetRawText());
        var redacted = RedactElement(doc.RootElement);
        return JsonSerializer.SerializeToElement(redacted);
    }

    private static object? RedactElement(JsonElement element)
    {
        return element.ValueKind switch
        {
            JsonValueKind.Object => element.EnumerateObject().ToDictionary(p => p.Name, p => IsSensitiveName(p.Name) ? "<redacted>" : RedactElement(p.Value), StringComparer.OrdinalIgnoreCase),
            JsonValueKind.Array => element.EnumerateArray().Select(RedactElement).ToArray(),
            JsonValueKind.String => element.GetString(),
            JsonValueKind.Number => element.TryGetInt64(out var l) ? l : element.GetDouble(),
            JsonValueKind.True => true,
            JsonValueKind.False => false,
            _ => null
        };
    }

    private static bool IsSensitiveName(string name)
    {
        return name.Contains("EncryptionKey", StringComparison.OrdinalIgnoreCase)
               || name.Equals("Key", StringComparison.OrdinalIgnoreCase)
               || name.Equals("IV", StringComparison.OrdinalIgnoreCase)
               || name.Contains("DecryptInfo", StringComparison.OrdinalIgnoreCase)
               || name.Contains("Token", StringComparison.OrdinalIgnoreCase)
               || name.Contains("UploadLocation", StringComparison.OrdinalIgnoreCase)
               || name.Contains("Sas", StringComparison.OrdinalIgnoreCase)
               || name.Contains("Uri", StringComparison.OrdinalIgnoreCase);
    }

    private static void SaveJson(string path, object value)
    {
        var json = JsonSerializer.Serialize(value, JsonOptions);
        File.WriteAllText(path, json, Encoding.UTF8);
    }

    private static void SaveJsonElement(string path, JsonElement value)
    {
        using var stream = File.Create(path);
        using var writer = new Utf8JsonWriter(stream, new JsonWriterOptions { Indented = true });
        value.WriteTo(writer);
    }

    private static IEnumerable<JsonElement> EnumerateArrayOrSingle(JsonElement element)
    {
        if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray()) yield return item;
        }
        else if (element.ValueKind != JsonValueKind.Undefined && element.ValueKind != JsonValueKind.Null)
        {
            yield return element;
        }
    }

    private void Log(string message) => _log.AppendLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss}\t{message}");
    private void ResetLog() => _log.Clear();
    private string FlushLog() => _log.ToString().TrimEnd();

    private static string GetString(JsonElement element, string name)
        => element.ValueKind == JsonValueKind.Object && element.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() ?? string.Empty : string.Empty;

    private static bool TryGetString(JsonElement element, string name, out string value)
    {
        value = GetString(element, name);
        return !string.IsNullOrWhiteSpace(value);
    }

    private static string MakeSafeFileName(string name)
    {
        foreach (var invalid in Path.GetInvalidFileNameChars()) name = name.Replace(invalid, '_');
        return string.IsNullOrWhiteSpace(name) ? "IntuneWinApp" : name.Trim();
    }


    private void ReportProgress(int percent, string message)
    {
        var safePercent = Math.Clamp(percent, 0, 100);
        ProgressChanged?.Invoke(safePercent, message);
    }

    private static void ReplaceFileWithRetry(string sourcePath, string destinationPath)
    {
        Exception? lastException = null;
        for (var attempt = 1; attempt <= 10; attempt++)
        {
            try
            {
                if (File.Exists(destinationPath)) File.Delete(destinationPath);
                File.Move(sourcePath, destinationPath);
                return;
            }
            catch (IOException ex)
            {
                lastException = ex;
                Thread.Sleep(250 * attempt);
            }
            catch (UnauthorizedAccessException ex)
            {
                lastException = ex;
                Thread.Sleep(250 * attempt);
            }
        }

        throw new IOException($"Could not replace '{destinationPath}' because it is locked or unavailable.", lastException);
    }
    private static string FormatByteSize(long bytes)
    {
        if (bytes >= 1024L * 1024 * 1024) return $"{bytes / (1024d * 1024 * 1024):N2} GB";
        if (bytes >= 1024L * 1024) return $"{bytes / (1024d * 1024):N1} MB";
        if (bytes >= 1024L) return $"{bytes / 1024d:N1} KB";
        return bytes + " bytes";
    }

    private static JsonSerializerOptions JsonOptions => new() { WriteIndented = true };

    private sealed record WamTokenRequestCandidate(WebTokenRequest Request, string Description);

    private sealed record DownloadContext(string Endpoint, string AccountId, string DeviceId, string BearerToken, X509Certificate2 Certificate, string CertificateBlob);
    private sealed record CatalogCacheItem(AppRow Row, JsonElement? RawItem);
    private sealed record PolicyScriptInfo(string Id, int Type, string Data, bool EnforceSignatureCheck);
    private sealed record PolicyScriptDownloadInfo(string Id, int Type, string ScriptPath, string CommandLine, string SourceFolder, string Note);
}
