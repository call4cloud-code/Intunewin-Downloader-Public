using System.Diagnostics;
using System.Text;
using IntuneWinDownloader.WinUI.Models;

namespace IntuneWinDownloader.WinUI.Services;

public sealed class InstallRunner
{
    public async Task<InstallResult> RunAsync(string command, string workingDirectory, bool runAsSystem, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(command)) throw new InvalidOperationException("The install command is empty.");
        if (string.IsNullOrWhiteSpace(workingDirectory) || !Directory.Exists(workingDirectory)) throw new DirectoryNotFoundException(workingDirectory);

        var runnerFolder = CreateRunnerFolder();
        var stdout = Path.Combine(runnerFolder, "stdout.txt");
        var stderr = Path.Combine(runnerFolder, "stderr.txt");
        var exitCodeFile = Path.Combine(runnerFolder, "exitcode.txt");
        var wrapper = Path.Combine(runnerFolder, "run-install.cmd");
        CreateWrapper(wrapper, command, workingDirectory, stdout, stderr, exitCodeFile);

        if (runAsSystem)
        {
            var exit = await RunWrapperAsSystemAsync(wrapper, exitCodeFile, cancellationToken);
            return BuildResult(exit, "SYSTEM scheduled task", wrapper, stdout, stderr, exitCodeFile);
        }
        else
        {
            var exit = await RunWrapperCurrentAsync(wrapper, cancellationToken);
            if (File.Exists(exitCodeFile) && int.TryParse((await File.ReadAllTextAsync(exitCodeFile, cancellationToken)).Trim(), out var fileExit))
            {
                exit = fileExit;
            }
            return BuildResult(exit, "Current elevated process", wrapper, stdout, stderr, exitCodeFile);
        }
    }

    private static InstallResult BuildResult(int exitCode, string context, string wrapper, string stdout, string stderr, string exitCodeFile)
    {
        return new InstallResult
        {
            ExitCode = exitCode,
            MappedResult = MapReturnCode(exitCode),
            ExecutionContext = context,
            WrapperPath = wrapper,
            StdOutPath = stdout,
            StdErrPath = stderr,
            ExitCodePath = exitCodeFile
        };
    }

    private static async Task<int> RunWrapperCurrentAsync(string wrapperPath, CancellationToken cancellationToken)
    {
        var psi = new ProcessStartInfo
        {
            FileName = "cmd.exe",
            Arguments = "/d /c " + Quote(wrapperPath),
            UseShellExecute = false,
            CreateNoWindow = true
        };

        using var process = Process.Start(psi) ?? throw new InvalidOperationException("Could not start install wrapper.");
        await process.WaitForExitAsync(cancellationToken);
        return process.ExitCode;
    }

    private static async Task<int> RunWrapperAsSystemAsync(string wrapperPath, string exitCodeFile, CancellationToken cancellationToken)
    {
        var taskName = "IntuneWinDownloader_TestInstall_" + Guid.NewGuid().ToString("N");
        try
        {
            var startTime = DateTime.Now.AddMinutes(1).ToString("HH:mm");
            var taskRun = "cmd.exe /d /c " + Quote(wrapperPath);
            await RunProcessAsync("schtasks.exe", $"/Create /F /TN {Quote(taskName)} /SC ONCE /ST {startTime} /RL HIGHEST /RU SYSTEM /TR {Quote(taskRun)}", cancellationToken);
            await RunProcessAsync("schtasks.exe", $"/Run /TN {Quote(taskName)}", cancellationToken);

            var started = DateTime.UtcNow;
            while (!cancellationToken.IsCancellationRequested)
            {
                if (File.Exists(exitCodeFile))
                {
                    var text = await File.ReadAllTextAsync(exitCodeFile, cancellationToken);
                    if (int.TryParse(text.Trim(), out var exit)) return exit;
                }

                if (DateTime.UtcNow - started > TimeSpan.FromHours(3))
                {
                    throw new TimeoutException("The SYSTEM install task did not write an exit code within 3 hours.");
                }

                await Task.Delay(1500, cancellationToken);
            }

            cancellationToken.ThrowIfCancellationRequested();
            return -1;
        }
        finally
        {
            try { await RunProcessAsync("schtasks.exe", $"/Delete /F /TN {Quote(taskName)}", CancellationToken.None); } catch { }
        }
    }

    private static async Task RunProcessAsync(string fileName, string arguments, CancellationToken cancellationToken)
    {
        var psi = new ProcessStartInfo
        {
            FileName = fileName,
            Arguments = arguments,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };
        using var process = Process.Start(psi) ?? throw new InvalidOperationException($"Could not start {fileName}.");
        await process.WaitForExitAsync(cancellationToken);
        if (process.ExitCode != 0)
        {
            var stdout = await process.StandardOutput.ReadToEndAsync(cancellationToken);
            var stderr = await process.StandardError.ReadToEndAsync(cancellationToken);
            throw new InvalidOperationException($"{fileName} exited with {process.ExitCode}. {stdout} {stderr}".Trim());
        }
    }

    private static void CreateWrapper(string wrapperPath, string command, string workingDirectory, string stdout, string stderr, string exitCodeFile)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(wrapperPath)!);
        Directory.CreateDirectory(workingDirectory);
        foreach (var path in new[] { stdout, stderr, exitCodeFile })
        {
            var folder = Path.GetDirectoryName(path);
            if (!string.IsNullOrWhiteSpace(folder)) Directory.CreateDirectory(folder);
        }

        var content = new StringBuilder();
        content.AppendLine("@echo off");
        content.AppendLine("setlocal EnableExtensions");
        content.AppendLine("cd /d " + Quote(workingDirectory));
        content.AppendLine(command + " 1>" + Quote(stdout) + " 2>" + Quote(stderr));
        content.AppendLine("set EC=%ERRORLEVEL%");
        content.AppendLine("echo %EC%>" + Quote(exitCodeFile));
        content.AppendLine("exit /b %EC%");
        File.WriteAllText(wrapperPath, content.ToString(), Encoding.ASCII);
    }

    private static string CreateRunnerFolder()
    {
        var root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "IntuneWinDownloader", "TestInstall", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        return root;
    }

    private static string MapReturnCode(int exitCode) => exitCode switch
    {
        0 => "success",
        1707 => "success",
        3010 => "soft reboot",
        1641 => "hard reboot",
        1618 => "retry",
        _ => "failed"
    };

    private static string Quote(string value) => "\"" + value.Replace("\"", "\\\"") + "\"";
}
