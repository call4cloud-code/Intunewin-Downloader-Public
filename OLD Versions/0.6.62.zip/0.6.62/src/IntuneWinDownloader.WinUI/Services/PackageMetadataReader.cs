using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Xml;

namespace IntuneWinDownloader.WinUI.Services;

public sealed class PackageMetadata
{
    public string ExtractedFolder { get; set; } = string.Empty;
    public int MetadataFileCount { get; set; }
    public object? ParsedMetadataFiles { get; set; }
    public string SetupFileFromMetadata { get; set; } = string.Empty;
    public string OriginalFileName { get; set; } = string.Empty;
    public string UnencryptedContentSize { get; set; } = string.Empty;
    public string MsiProductCode { get; set; } = string.Empty;
    public string MsiProductVersion { get; set; } = string.Empty;
    public string MsiPackageCode { get; set; } = string.Empty;
    public string InstallationBehavior { get; set; } = string.Empty;
    public PatchMyPcCommandLine? PatchMyPCCommandLine { get; set; }
}

public sealed class PatchMyPcCommandLine
{
    public string MainFile { get; set; } = string.Empty;
    public string MainArg { get; set; } = string.Empty;
    public string LoggingSwitch { get; set; } = string.Empty;
    public string LoggingPath { get; set; } = string.Empty;
    public string BlockingProcessPolicy { get; set; } = string.Empty;
    public string UserNotificationTimeout { get; set; } = string.Empty;
    public string NotificationPolicy { get; set; } = string.Empty;
    public string ApplicationName { get; set; } = string.Empty;
    public string ApplicationID { get; set; } = string.Empty;
    public string KillProcessList { get; set; } = string.Empty;
    public string SkipProcessList { get; set; } = string.Empty;
    public Dictionary<string, string> RawFields { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

internal static class PackageMetadataReader
{
    public static PackageMetadata Read(string extractedFolder)
    {
        var packageXml = Path.Combine(extractedFolder, "Package.xml");
        if (!File.Exists(packageXml))
        {
            return new PackageMetadata { ExtractedFolder = extractedFolder, MetadataFileCount = 0 };
        }

        var xml = LoadPackageXml(packageXml);
        var content = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (xml.DocumentElement is not null)
        {
            foreach (XmlNode node in xml.DocumentElement.ChildNodes)
            {
                if (node.NodeType == XmlNodeType.Element)
                {
                    content[node.Name] = node.InnerText;
                }
            }
        }

        content.TryGetValue("CommandLine", out var commandLine);
        var patch = ParsePatchMyPcCommandLine(RepairMojibake(commandLine ?? string.Empty));
        content.TryGetValue("SetupFile", out var setupFile);
        content.TryGetValue("OriginalFileName", out var originalFileName);
        content.TryGetValue("UnencryptedContentSize", out var unencryptedSize);
        content.TryGetValue("MsiProductCode", out var msiProductCode);
        content.TryGetValue("MsiProductVersion", out var msiProductVersion);
        content.TryGetValue("MsiPackageCode", out var msiPackageCode);
        content.TryGetValue("InstallationBehavior", out var installBehavior);

        if (string.IsNullOrWhiteSpace(setupFile) && patch is not null) setupFile = patch.MainFile;
        if (string.IsNullOrWhiteSpace(installBehavior)) content.TryGetValue("InstallBehavior", out installBehavior);

        return new PackageMetadata
        {
            ExtractedFolder = extractedFolder,
            MetadataFileCount = 1,
            ParsedMetadataFiles = new
            {
                FileName = "Package.xml",
                FullName = packageXml,
                RelativePath = "Package.xml",
                RootName = xml.DocumentElement?.Name ?? "Package",
                Content = content
            },
            SetupFileFromMetadata = setupFile ?? string.Empty,
            OriginalFileName = originalFileName ?? string.Empty,
            UnencryptedContentSize = unencryptedSize ?? string.Empty,
            MsiProductCode = msiProductCode ?? string.Empty,
            MsiProductVersion = msiProductVersion ?? string.Empty,
            MsiPackageCode = msiPackageCode ?? string.Empty,
            InstallationBehavior = installBehavior ?? string.Empty,
            PatchMyPCCommandLine = patch
        };
    }

    private static XmlDocument LoadPackageXml(string packageXml)
    {
        var bytes = File.ReadAllBytes(packageXml);
        var xml = new XmlDocument { PreserveWhitespace = false };

        try
        {
            using var ms = new MemoryStream(bytes);
            xml.Load(ms);
            return xml;
        }
        catch (XmlException ex) when (IsEncodingMismatch(ex))
        {
            var text = DecodePackageXmlText(bytes);
            text = StripXmlEncodingDeclaration(text);
            xml.LoadXml(text);
            return xml;
        }
    }

    private static bool IsEncodingMismatch(XmlException ex)
    {
        var message = ex.Message ?? string.Empty;
        return message.Contains("byte order mark", StringComparison.OrdinalIgnoreCase)
               || message.Contains("Cannot switch to Unicode", StringComparison.OrdinalIgnoreCase)
               || message.Contains("switch from current encoding", StringComparison.OrdinalIgnoreCase);
    }

    private static string DecodePackageXmlText(byte[] bytes)
    {
        if (bytes.Length >= 2)
        {
            if (bytes[0] == 0xFF && bytes[1] == 0xFE) return Encoding.Unicode.GetString(bytes);
            if (bytes[0] == 0xFE && bytes[1] == 0xFF) return Encoding.BigEndianUnicode.GetString(bytes);
        }

        if (bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF)
        {
            return Encoding.UTF8.GetString(bytes);
        }

        var sampleLength = Math.Min(bytes.Length, 512);
        var oddNulls = 0;
        var evenNulls = 0;
        for (var i = 0; i < sampleLength; i++)
        {
            if (bytes[i] != 0) continue;
            if ((i & 1) == 0) evenNulls++; else oddNulls++;
        }

        if (oddNulls > sampleLength / 8 && evenNulls == 0) return Encoding.Unicode.GetString(bytes);
        if (evenNulls > sampleLength / 8 && oddNulls == 0) return Encoding.BigEndianUnicode.GetString(bytes);

        return Encoding.UTF8.GetString(bytes);
    }

    private static string StripXmlEncodingDeclaration(string text)
    {
        text = text.TrimStart('\uFEFF', '\u0000', ' ', '\t', '\r', '\n');
        return Regex.Replace(
            text,
            @"encoding\s*=\s*[""'][^""']+[""']",
            string.Empty,
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant,
            TimeSpan.FromSeconds(1));
    }


    private static PatchMyPcCommandLine? ParsePatchMyPcCommandLine(string commandLine)
    {
        if (string.IsNullOrWhiteSpace(commandLine)) return null;
        var fields = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var rawPart in commandLine.Split('\u00FF', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            var part = rawPart.Trim().Trim('"');
            if (!part.StartsWith('/')) continue;
            var eq = part.IndexOf('=');
            if (eq < 2) continue;
            var key = part[1..eq];
            var value = part[(eq + 1)..].Trim().Trim('"');
            fields[key] = value;
        }
        if (fields.Count == 0) return null;
        return new PatchMyPcCommandLine
        {
            MainFile = Value(fields, "MainFile"),
            MainArg = Value(fields, "MainArg"),
            LoggingSwitch = Value(fields, "LoggingSwitch"),
            LoggingPath = Value(fields, "LoggingPath"),
            BlockingProcessPolicy = Value(fields, "BlockingProcessPolicy"),
            UserNotificationTimeout = Value(fields, "UserNotificationTimeout"),
            NotificationPolicy = Value(fields, "NotificationPolicy"),
            ApplicationName = Value(fields, "ApplicationName"),
            ApplicationID = Value(fields, "ApplicationID"),
            KillProcessList = Value(fields, "KillProcessList"),
            SkipProcessList = Value(fields, "SkipProcessList"),
            RawFields = fields
        };
    }

    private static string Value(Dictionary<string, string> fields, string name) => fields.TryGetValue(name, out var value) ? value : string.Empty;
    private static string RepairMojibake(string value) => value.Replace("\u00C3\u00BF", "\u00FF", StringComparison.Ordinal);
}

internal static class PackageAppMetadataBuilder
{
    public static object Build(string applicationId, string displayName, string extractedFolder, PackageMetadata packageMetadata)
    {
        var candidate = GetSetupCandidate(extractedFolder, packageMetadata);
        var installBehavior = packageMetadata.InstallationBehavior.Contains("system", StringComparison.OrdinalIgnoreCase) ? "system" : "user";
        return new
        {
            ODataType = "#local.packageMetadataOnly.nativeCSharp",
            id = applicationId,
            displayName,
            installCommandLine = candidate.Command,
            uninstallCommandLine = string.Empty,
            setupFilePath = candidate.RelativePath,
            installExperience = new { runAsAccount = installBehavior },
            rules = Array.Empty<object>(),
            returnCodes = new[]
            {
                new { returnCode = 0, type = "success" },
                new { returnCode = 1707, type = "success" },
                new { returnCode = 3010, type = "softReboot" },
                new { returnCode = 1641, type = "hardReboot" },
                new { returnCode = 1618, type = "retry" }
            },
            metadataSource = "Downloaded package metadata only. Native C# backend. Graph was not used.",
            packageMetadata,
            setupCandidate = candidate
        };
    }

    private static SetupCandidate GetSetupCandidate(string extractedFolder, PackageMetadata metadata)
    {
        var mainFile = metadata.SetupFileFromMetadata;
        if (string.IsNullOrWhiteSpace(mainFile) && metadata.PatchMyPCCommandLine is not null) mainFile = metadata.PatchMyPCCommandLine.MainFile;
        var full = string.IsNullOrWhiteSpace(mainFile) ? FindSetupFile(extractedFolder) : Path.Combine(extractedFolder, mainFile);
        if (!File.Exists(full)) full = FindSetupFile(extractedFolder);
        var relative = string.IsNullOrWhiteSpace(full) ? string.Empty : Path.GetRelativePath(extractedFolder, full);
        var command = BuildCommand(full, metadata.PatchMyPCCommandLine);
        return new SetupCandidate(Path.GetFileName(full), full, relative, command);
    }

    private static string FindSetupFile(string extractedFolder)
    {
        if (!Directory.Exists(extractedFolder)) return string.Empty;
        return Directory.EnumerateFiles(extractedFolder, "*.msi", SearchOption.TopDirectoryOnly).FirstOrDefault()
               ?? Directory.EnumerateFiles(extractedFolder, "*.exe", SearchOption.TopDirectoryOnly).OrderByDescending(p => Path.GetFileName(p).StartsWith("setup", StringComparison.OrdinalIgnoreCase) || Path.GetFileName(p).StartsWith("install", StringComparison.OrdinalIgnoreCase)).FirstOrDefault()
               ?? Directory.EnumerateFiles(extractedFolder, "*.ps1", SearchOption.TopDirectoryOnly).FirstOrDefault()
               ?? string.Empty;
    }

    private static string BuildCommand(string fullPath, PatchMyPcCommandLine? patch)
    {
        if (string.IsNullOrWhiteSpace(fullPath)) return string.Empty;
        var ext = Path.GetExtension(fullPath);
        if (ext.Equals(".msi", StringComparison.OrdinalIgnoreCase))
        {
            var args = patch?.MainArg ?? string.Empty;
            var log = BuildLogArgument(patch, patch?.ApplicationName ?? Path.GetFileNameWithoutExtension(fullPath));
            return string.Join(' ', new[] { "msiexec.exe", "/i", Quote(fullPath), args, "/qn", log }.Where(s => !string.IsNullOrWhiteSpace(s)));
        }
        if (ext.Equals(".ps1", StringComparison.OrdinalIgnoreCase)) return $"powershell.exe -NoProfile -ExecutionPolicy Bypass -File {Quote(fullPath)}";
        if (ext.Equals(".cmd", StringComparison.OrdinalIgnoreCase) || ext.Equals(".bat", StringComparison.OrdinalIgnoreCase)) return $"cmd.exe /c {Quote(fullPath)}";
        return string.Join(' ', new[] { Quote(fullPath), patch?.MainArg ?? string.Empty }.Where(s => !string.IsNullOrWhiteSpace(s)));
    }

    private static string BuildLogArgument(PatchMyPcCommandLine? patch, string appName)
    {
        if (patch is null || string.IsNullOrWhiteSpace(patch.LoggingSwitch) || string.IsNullOrWhiteSpace(patch.LoggingPath)) return string.Empty;
        var path = Path.Combine(Environment.ExpandEnvironmentVariables(patch.LoggingPath), MakeSafeFileName(appName) + ".log");
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        return patch.LoggingSwitch.Contains("{path}", StringComparison.OrdinalIgnoreCase)
            ? patch.LoggingSwitch.Replace("{path}", Quote(path), StringComparison.OrdinalIgnoreCase)
            : patch.LoggingSwitch + " " + Quote(path);
    }

    private static string MakeSafeFileName(string value)
    {
        foreach (var invalid in Path.GetInvalidFileNameChars()) value = value.Replace(invalid, '_');
        return string.IsNullOrWhiteSpace(value) ? "install" : value;
    }

    private static string Quote(string value) => "\"" + value.Replace("\"", "\\\"") + "\"";
    private sealed record SetupCandidate(string FileName, string FullPath, string RelativePath, string Command);
}
