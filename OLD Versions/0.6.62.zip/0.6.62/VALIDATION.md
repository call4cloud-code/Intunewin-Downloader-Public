# Validation

This source was checked in the sandbox with static checks only. The sandbox does not have the .NET SDK or Visual Studio, so a real WinUI build cannot be executed here.

Checked items:

- XAML files parse as XML.
- C# braces are balanced outside strings and comments.
- Invalid WinUI Window MinWidth and MinHeight members are not present.
- Main log export no longer copies locked IME log files.
- The committed content version resolver no longer brute force probes a range. It reads the IME SideCar app policy Version field first.
- GetContentInfo request payload now includes the IME style fields visible in the uploaded IME log: ApplicationId, ApplicationVersion (wire field carrying committed content version), Intent, CertificateBlob, ContentInfo, SecondaryContentInfo, SupplementalContentInfos, SupplementalContentIds, DecryptInfo, UploadLocation, TargetingMethod, ErrorCode, TargetType, InstallContext, EspPhase, ApplicationName, AssignmentFilterIds, ManagedInstallerStatus, ApplicationEnforcement, AppTypeSpecificProperties, and AppTypeSpecificPropertiesFormat.

Runtime validation still needs to be done on a managed Windows device because SideCar calls require WAM, the local Intune MDM certificate, and the tenant/device context.


## 0.6.57 validation

XAML files parsed successfully with Python XML parser. The sandbox does not contain the .NET SDK, so a real Visual Studio build could not be executed here.

## 0.6.58 validation

This was patched from the uploaded `Directory.Build.zip` source tree.

Static checks completed in the sandbox:

- `App.xaml`, `MainWindow.xaml`, and `InstallTestWindow.xaml` parse as XML.
- C# brace balance was checked outside strings and comments.
- The row and header grids both have eight columns after adding the package size column.
- The project metadata was updated to 0.6.58.

Runtime build validation was not possible in this sandbox because it does not have the Windows App SDK build chain or a managed Windows device context for SideCar calls.

## 0.6.60 validation

This version was patched from the previous 0.6.59 source package.

Static checks completed in the sandbox:

- `App.xaml`, `MainWindow.xaml`, and `InstallTestWindow.xaml` parse as XML.
- C# brace balance was checked outside strings and comments.
- GetContentInfo fallback probing now stops after the first usable response.
- Quiet probe mode prevents expected 404 probe misses from being logged as full failure bodies.
- Selection based content version resolving no longer appends stale logs after a download has started.

Runtime build validation was not possible in this sandbox because it does not have the Windows App SDK build chain or a managed Windows device context for SideCar calls.
