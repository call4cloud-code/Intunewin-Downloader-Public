# IntuneWin Downloader WinUI 0.6.60

This build is based on the uploaded `Directory.Build.zip`, not the older 0.6.40 or 0.6.41 source package.

## What changed in 0.6.60

Paint.NET was not really failing ContentInfo. Version 1 returned usable ContentInfo, but the fallback resolver kept probing later versions afterwards. Those rejected probes made the log look like ContentInfo was broken even though the download completed.

The fallback resolver now stops at the first usable ContentInfo response and uses the committed content version echoed by SideCar when it is present. Probe failures are logged as short rejections instead of dumping the full SideCar 404 body.

The selection resolver is also cancelled from the UI perspective when a download starts, so an older background selection probe no longer appends stale ContentInfo noise into the live download log.

## What changed in 0.6.58

The VLC path worked because the IME policy object returned by `GetAvailableApp` used the same id as the Company Portal app id. Patch My PC update apps can be different. The Company Portal catalog can expose `Snagit Latest x64`, while the IME policy list can expose a related policy object like `Update for Snagit Latest x64` with another id.

The tool now handles that split.

The download path still uses the Company Portal app id for `GetContentInfo`, because that is the id accepted by the content service.

The policy metadata path now matches by Company Portal app id first, then by normalized app name. Prefixes like `Update for` are stripped before comparing names.

The committed content version is no longer trusted just because a policy object has a `Version` value. The tool validates that candidate with `GetContentInfo` for the selected Company Portal app id before using it.

The decoded SideCar policy export now keeps the best payload it saw instead of locking onto the first tiny `GetAvailableApp` response. That makes `09_getpolicies_selected_app_redacted.json` and `10_policy_commands.json` more useful when `RequestApplication` returns the larger policy list.

The install test window still lets you compare command sources. Auto now prefers the rebuilt package metadata command when the IME policy command is only the Patch My PC script runner placeholder. That means Patch My PC packages should show the actual MSI or EXE command line with parameters again.

The app list now shows package size from the IWService `ContentSize` field, and content version resolution has an in flight guard to avoid repeated duplicate SideCar calls for the same selected app.

## Build

Run this on Windows with Visual Studio 2022 build tools, .NET 8 SDK and Windows App SDK support available.

```powershell
.\Build-Release.ps1
```

Output:

```text
artifacts\IntuneWinDownloader.WinUI-0.6.58
```

## Metadata

After download, the metadata folder still exports these files:

```text
08_getpolicies_payload_redacted.json
09_getpolicies_selected_app_redacted.json
10_policy_commands.json
```

The names are kept for continuity. The content now comes from the IME SideCar app policy list, with better selection of the decoded payload and better selected app matching.

## 0.6.57 command source selector

The install test window now has a command source selector. Auto prefers the IME policy command from `10_policy_commands.json`, but you can switch to the rebuilt package metadata command from the extracted Package.xml or `06_package_metadata.json` when the policy command was not available or when you want to compare both.

## 0.6.55 log panel cleanup

The visible log panel is now handled from the right side action panel only. The duplicate export and clear buttons were removed from the left action panel.

The main export button now exports the shown log panel by default, even when no app was downloaded. A live plain text mirror is also written to `ToolLogs\IntuneWinDownloader_CurrentToolLog.txt` under the selected download folder. Clearing the shown logs also clears that mirror file.

## 0.6.54 log export and clear

The app list, friendly version, publisher and icon still come from the Company Portal IWService catalog.

The committed content version now comes only from the IME SideCar app policy payload. The field in that policy is `Version`. For example, when the policy says `Version: 1`, the tool stores that as `CommittedContentVersion = 1`.

`GetContentInfo` still requires that same value in a request field called `ApplicationVersion`. That name is part of the SideCar contract and does not mean the friendly Company Portal app version.

The GetContentInfo request was reverted to the smaller native SideCar payload that worked before. The richer AppWorkload log line is useful for understanding the internal model, but it is not the exact request shape this tool should send.


## 0.6.54 log export and clear

The main log panel can be exported before any app has been downloaded. In 0.6.55 those log actions were moved to the right side panel only, so the left action panel stays focused on loading and downloading apps.
