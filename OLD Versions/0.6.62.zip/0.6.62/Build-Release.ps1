$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Project = Join-Path $Root 'src\IntuneWinDownloader.WinUI\IntuneWinDownloader.WinUI.csproj'
$Output = Join-Path $Root 'artifacts\IntuneWinDownloader.WinUI-0.6.54'

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'dotnet was not found. Install the .NET 8 SDK and the Visual Studio 2022 Windows desktop build tools.'
}

if (Test-Path $Output) {
    Remove-Item $Output -Recurse -Force
}

New-Item -ItemType Directory -Path $Output -Force | Out-Null

dotnet restore $Project
dotnet publish $Project `
    -c Release `
    -r win-x64 `
    -p:Platform=x64 `
    -p:WindowsPackageType=None `
    -p:SelfContained=false `
    -o $Output

Write-Host "Build output: $Output"
