<#
    Get Company Portal IWService catalog details
    This only reads the Company Portal catalog that the signed in user and device are allowed to see.
    It does not bypass assignment or targeting.

    Run in Windows PowerShell 5.1 as admin on an Intune enrolled device.
#>

[CmdletBinding()]
param(
    [string]$OutputFolder = "C:\Temp\CompanyPortalCatalogDump",
    [int]$Top = 1000,
    [switch]$InteractiveWam
)

$ErrorActionPreference = 'Stop'

$CompanyPortalClientId = '9ba1a5c7-f17a-4de9-a1f1-6178c8d51223'
$IwServiceResource     = 'b8066b99-6e67-41be-abfa-75db1a2c8809'
$WamProviderUrl        = 'https://login.microsoft.com'

function Wait-WinRtAsync {
    param(
        [Parameter(Mandatory)]
        $Operation
    )

    $null = [System.Reflection.Assembly]::LoadWithPartialName('System.Runtime.WindowsRuntime')
    $task = [System.WindowsRuntimeSystemExtensions]::AsTask($Operation)
    $task.Wait()
    return $task.Result
}

function New-WamRequest {
    param(
        [Parameter(Mandatory)] $Provider,
        [Parameter(Mandatory)] [string] $ClientId,
        [Parameter(Mandatory)] [string] $Resource,
        [switch] $ResourceAsScope
    )

    if ($ResourceAsScope) {
        return [Windows.Security.Authentication.Web.Core.WebTokenRequest]::new($Provider, $Resource, $ClientId)
    }

    $request = [Windows.Security.Authentication.Web.Core.WebTokenRequest]::new($Provider, '', $ClientId)
    $request.Properties.Add('resource', $Resource)
    return $request
}

function Get-WamBearerToken {
    param(
        [Parameter(Mandatory)] [string] $ClientId,
        [Parameter(Mandatory)] [string] $Resource,
        [switch] $Interactive
    )

    [Windows.Security.Authentication.Web.Core.WebAuthenticationCoreManager, Windows.Security.Authentication.Web.Core, ContentType = WindowsRuntime] | Out-Null
    [Windows.Security.Authentication.Web.Core.WebTokenRequest, Windows.Security.Authentication.Web.Core, ContentType = WindowsRuntime] | Out-Null
    [Windows.Security.Credentials.WebAccountProvider, Windows.Security.Credentials, ContentType = WindowsRuntime] | Out-Null

    $provider = Wait-WinRtAsync ([Windows.Security.Authentication.Web.Core.WebAuthenticationCoreManager]::FindAccountProviderAsync($WamProviderUrl, 'common'))
    if (-not $provider) {
        throw 'WAM provider was not found. Make sure the device is Entra joined or has a work account connected.'
    }

    $requests = @(
        (New-WamRequest -Provider $provider -ClientId $ClientId -Resource $Resource),
        (New-WamRequest -Provider $provider -ClientId $ClientId -Resource $Resource -ResourceAsScope)
    )

    foreach ($request in $requests) {
        try {
            $result = Wait-WinRtAsync ([Windows.Security.Authentication.Web.Core.WebAuthenticationCoreManager]::GetTokenSilentlyAsync($request))
            if ($result.ResponseStatus -eq 'Success' -and $result.ResponseData.Count -gt 0 -and $result.ResponseData[0].Token) {
                return $result.ResponseData[0].Token
            }
        }
        catch {
            Write-Verbose "Silent WAM attempt failed: $($_.Exception.Message)"
        }
    }

    if (-not $Interactive) {
        throw 'Silent WAM token acquisition failed. Run again with -InteractiveWam if a prompt is needed.'
    }

    foreach ($request in $requests) {
        try {
            $result = Wait-WinRtAsync ([Windows.Security.Authentication.Web.Core.WebAuthenticationCoreManager]::RequestTokenAsync($request))
            if ($result.ResponseStatus -eq 'Success' -and $result.ResponseData.Count -gt 0 -and $result.ResponseData[0].Token) {
                return $result.ResponseData[0].Token
            }
        }
        catch {
            Write-Verbose "Interactive WAM attempt failed: $($_.Exception.Message)"
        }
    }

    throw 'WAM did not return a token for IWService.'
}

function Find-IntuneMdmCertificate {
    $locations = @(
        @{ Store = 'My'; Location = 'LocalMachine'; Path = 'LocalMachine\My' },
        @{ Store = 'My'; Location = 'CurrentUser';  Path = 'CurrentUser\My'  }
    )

    foreach ($location in $locations) {
        $store = [System.Security.Cryptography.X509Certificates.X509Store]::new(
            $location.Store,
            [System.Security.Cryptography.X509Certificates.StoreLocation]::$($location.Location)
        )

        try {
            $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadOnly)

            $candidate = $store.Certificates |
                Where-Object {
                    $_.Issuer -like '*Microsoft Intune MDM Device CA*' -and
                    $_.Extensions | Where-Object { $_.Oid.Value -eq '1.2.840.113556.5.6' }
                } |
                Sort-Object HasPrivateKey -Descending, NotAfter -Descending |
                Select-Object -First 1

            if ($candidate) {
                return [pscustomobject]@{
                    Certificate = $candidate
                    StorePath   = $location.Path
                }
            }
        }
        finally {
            $store.Close()
        }
    }

    throw 'No Microsoft Intune MDM Device CA certificate was found in LocalMachine\My or CurrentUser\My.'
}

function Get-DeviceIdFromCertificate {
    param([Parameter(Mandatory)] [System.Security.Cryptography.X509Certificates.X509Certificate2] $Certificate)

    $match = [regex]::Match($Certificate.Subject, '^CN=([\da-fA-F-]{36})')
    if (-not $match.Success) {
        throw "Could not parse DeviceId from certificate subject: $($Certificate.Subject)"
    }

    return $match.Groups[1].Value
}

function Get-LocationServiceUrls {
    $urls = New-Object System.Collections.Generic.List[string]
    $accountsPath = 'HKLM:\SOFTWARE\Microsoft\Provisioning\OMADM\Accounts'

    if (Test-Path $accountsPath) {
        foreach ($account in Get-ChildItem $accountsPath -ErrorAction SilentlyContinue) {
            $addrInfoPath = Join-Path $account.PSPath 'Protected\AddrInfo'
            if (-not (Test-Path $addrInfoPath)) {
                continue
            }

            $addr = (Get-ItemProperty -Path $addrInfoPath -Name Addr -ErrorAction SilentlyContinue).Addr
            if ([string]::IsNullOrWhiteSpace($addr)) {
                continue
            }

            if ($addr -like '*checkin.dm.microsoft.com*') {
                continue
            }

            try {
                $uri = [Uri]$addr
                $base = "$($uri.Scheme)://$($uri.Host)"
                if (-not $urls.Contains($base)) {
                    $urls.Add($base)
                }
            }
            catch {}
        }
    }

    if ($urls.Count -eq 0) {
        $urls.Add('https://manage.microsoft.com')
    }

    return $urls.ToArray()
}

function Get-SideCarGatewayUrl {
    param(
        [Parameter(Mandatory)] [string[]] $LocationServiceUrls,
        [Parameter(Mandatory)] [System.Security.Cryptography.X509Certificates.X509Certificate2] $Certificate
    )

    $path = '/RestUserAuthLocationService/RestUserAuthLocationService/Certificate/ServiceAddresses'

    foreach ($baseUrl in $LocationServiceUrls) {
        $url = $baseUrl.TrimEnd('/') + $path
        Write-Host "Querying discovery endpoint: $url"

        try {
            $response = Invoke-RestMethod -Method Get -Uri $url -Certificate $Certificate -Headers @{ 'client-request-id' = [guid]::NewGuid().ToString() }
        }
        catch {
            Write-Warning "Discovery failed for $baseUrl : $($_.Exception.Message)"
            continue
        }

        $regions = @()
        if ($response -is [System.Array]) {
            $regions = $response
        }
        else {
            $regions = @($response)
        }

        foreach ($region in $regions) {
            if (-not $region.IsPrimary -or -not $region.Services) {
                continue
            }

            foreach ($service in @($region.Services)) {
                if ($service.ServiceName -eq 'SideCarGatewayService' -and -not [string]::IsNullOrWhiteSpace($service.Url)) {
                    return $service.Url.Trim()
                }
            }
        }
    }

    throw 'No SideCarGatewayService URL was returned by the location service.'
}

function Get-IwServiceBaseUrlFromSideCarEndpoint {
    param([Parameter(Mandatory)] [string] $Endpoint)

    $uri = [Uri]$Endpoint
    $hostName = $uri.Host

    if ($hostName.StartsWith('fef.', [System.StringComparison]::OrdinalIgnoreCase)) {
        return "https://$hostName"
    }

    if ($hostName.StartsWith('agents.', [System.StringComparison]::OrdinalIgnoreCase)) {
        return 'https://fef.' + $hostName.Substring(7)
    }

    if ($hostName.EndsWith('manage.microsoft.com', [System.StringComparison]::OrdinalIgnoreCase)) {
        $parts = $hostName.Split('.')
        if ($parts.Count -eq 2) {
            return 'https://fef.manage.microsoft.com'
        }

        return 'https://fef.' + ($parts[1..($parts.Count - 1)] -join '.')
    }

    if ($hostName.Equals('manage.microsoft.com', [System.StringComparison]::OrdinalIgnoreCase)) {
        return 'https://fef.manage.microsoft.com'
    }

    return "https://$hostName"
}

function New-IwServiceCatalogUrl {
    param(
        [Parameter(Mandatory)] [string] $BaseUrl,
        [Parameter(Mandatory)] [string] $DeviceId,
        [int] $Top = 1000
    )

    $osVersion = [System.Environment]::OSVersion.Version.ToString()
    $arch = if ([Environment]::Is64BitOperatingSystem) { 'x64' } else { 'x86' }

    $query = @(
        'api-version=18.2'
        'ssp=WindowsUCP'
        'ssp-version=11.2.1787.0'
        'os=Windows'
        'os-version=' + [Uri]::EscapeDataString($osVersion)
        'os-sub=None'
        'arch=' + $arch
        'mgmt-agent=MicrosoftManagementPlatformCloudMdm'
        'device-id=' + [Uri]::EscapeDataString($DeviceId)
        '$orderby=Name'
        '$top=' + $Top
    ) -join '&'

    return $BaseUrl.TrimEnd('/') + '/TrafficGateway/TrafficRoutingService/IWService/StatelessIWService/Applications?' + $query
}

function Get-FirstPropertyValue {
    param(
        [Parameter(Mandatory)] $Object,
        [Parameter(Mandatory)] [string[]] $Names
    )

    foreach ($name in $Names) {
        $prop = $Object.PSObject.Properties[$name]
        if ($prop -and $null -ne $prop.Value -and -not [string]::IsNullOrWhiteSpace([string]$prop.Value)) {
            return [string]$prop.Value
        }
    }

    return ''
}

function Get-CatalogItems {
    param($Node)

    if ($null -eq $Node) {
        return @()
    }

    if ($Node -is [System.Array]) {
        return @($Node)
    }

    foreach ($containerName in @('value', 'Value', 'items', 'Items', 'applications', 'Applications', 'apps', 'Apps', 'data', 'Data')) {
        $prop = $Node.PSObject.Properties[$containerName]
        if ($prop -and $null -ne $prop.Value) {
            if ($prop.Value -is [System.Array]) {
                return @($prop.Value)
            }
        }
    }

    return @($Node)
}

function Convert-CatalogItemToRow {
    param([Parameter(Mandatory)] $Item)

    [pscustomobject]@{
        DisplayName       = Get-FirstPropertyValue $Item @('DisplayName', 'displayName', 'Name', 'name', 'Title', 'title')
        ApplicationId     = Get-FirstPropertyValue $Item @('ApplicationId', 'applicationId', 'MobileAppId', 'mobileAppId', 'AppId', 'appId', 'Id', 'id', 'GuidKey', 'guidKey')
        AppVersion        = Get-FirstPropertyValue $Item @('AppVersion', 'appVersion')
        DisplayVersion    = Get-FirstPropertyValue $Item @('DisplayVersion', 'displayVersion')
        Version           = Get-FirstPropertyValue $Item @('Version', 'version')
        Publisher         = Get-FirstPropertyValue $Item @('Publisher', 'publisher', 'Developer', 'developer', 'PublisherName', 'publisherName')
        Status            = Get-FirstPropertyValue $Item @('Status', 'status', 'InstallState', 'installState', 'Availability', 'availability', 'State', 'state')
        DatePublished     = Get-FirstPropertyValue $Item @('DatePublished', 'datePublished', 'PublishedDate', 'publishedDate', 'ReleaseDate', 'releaseDate', 'CreatedDateTime', 'createdDateTime', 'LastModifiedDateTime', 'lastModifiedDateTime')
        RawPropertyNames  = ($Item.PSObject.Properties.Name -join ',')
    }
}

New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null

$certInfo = Find-IntuneMdmCertificate
$cert = $certInfo.Certificate
$deviceId = Get-DeviceIdFromCertificate -Certificate $cert

Write-Host "Using certificate: $($certInfo.StorePath)"
Write-Host "DeviceId: $deviceId"

$locationUrls = Get-LocationServiceUrls
$sideCarEndpoint = Get-SideCarGatewayUrl -LocationServiceUrls $locationUrls -Certificate $cert
$iwServiceBaseUrl = Get-IwServiceBaseUrlFromSideCarEndpoint -Endpoint $sideCarEndpoint
$catalogUrl = New-IwServiceCatalogUrl -BaseUrl $iwServiceBaseUrl -DeviceId $deviceId -Top $Top

Write-Host "SideCar endpoint: $sideCarEndpoint"
Write-Host "IWService base URL: $iwServiceBaseUrl"
Write-Host "IWService catalog URL: $catalogUrl"
Write-Host 'Requesting IWService WAM token...'

$token = Get-WamBearerToken -ClientId $CompanyPortalClientId -Resource $IwServiceResource -Interactive:$InteractiveWam

$headers = @{
    Authorization       = "Bearer $token"
    'client-request-id' = [guid]::NewGuid().ToString()
    'User-Agent'        = 'CompanyPortal/11.2 IntuneWinDownloader'
    Accept              = 'application/json'
}

Write-Host 'Downloading Company Portal catalog...'
$response = Invoke-WebRequest -Method Get -Uri $catalogUrl -Headers $headers -UseBasicParsing
$rawJson = $response.Content

$rawPath = Join-Path $OutputFolder 'companyportal_iwservice_catalog_raw.json'
$flatJsonPath = Join-Path $OutputFolder 'companyportal_iwservice_catalog_flat.json'
$csvPath = Join-Path $OutputFolder 'companyportal_iwservice_catalog_flat.csv'
$metaPath = Join-Path $OutputFolder 'companyportal_iwservice_catalog_request.txt'

$rawJson | Out-File -FilePath $rawPath -Encoding utf8

$parsed = $rawJson | ConvertFrom-Json
$items = Get-CatalogItems -Node $parsed
$rows = foreach ($item in $items) { Convert-CatalogItemToRow -Item $item }

$rows | ConvertTo-Json -Depth 20 | Out-File -FilePath $flatJsonPath -Encoding utf8
$rows | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8

@"
DeviceId: $deviceId
CertificateStore: $($certInfo.StorePath)
CertificateSubject: $($cert.Subject)
SideCarEndpoint: $sideCarEndpoint
IWServiceBaseUrl: $iwServiceBaseUrl
CatalogUrl: $catalogUrl
ReturnedItems: $($rows.Count)
RawCatalog: $rawPath
FlatJson: $flatJsonPath
Csv: $csvPath
"@ | Out-File -FilePath $metaPath -Encoding utf8

Write-Host "Done. Returned $($rows.Count) catalog rows."
Write-Host "Raw JSON: $rawPath"
Write-Host "Flat CSV: $csvPath"
Write-Host ''
Write-Host 'Version fields to check:'
$rows | Select-Object DisplayName, ApplicationId, AppVersion, DisplayVersion, Version, Publisher | Format-Table -AutoSize
