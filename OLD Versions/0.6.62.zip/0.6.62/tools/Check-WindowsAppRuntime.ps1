$ErrorActionPreference = 'Stop'
Write-Host 'Windows App Runtime packages:' -ForegroundColor Cyan
$packages = Get-AppxPackage -AllUsers Microsoft.WindowsAppRuntime* | Sort-Object Name, Version
if (-not $packages) {
    Write-Host 'No Microsoft.WindowsAppRuntime packages found.' -ForegroundColor Yellow
    Write-Host 'Install the Windows App Runtime matching the Microsoft.WindowsAppSDK NuGet version used by this project.' -ForegroundColor Yellow
    exit 1
}
$packages | Select-Object Name, Version, PackageFullName | Format-Table -AutoSize
